import { users, userChatData, type User, type InsertUser, type UserChatData, type InsertUserChatData } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStripeInfo(userId: number, stripeCustomerId: string, stripeSubscriptionId: string): Promise<User | undefined>;
  updateUserSubscriptionStatus(userId: number, status: string): Promise<User | undefined>;
  makeUserAdmin(userId: number): Promise<User | undefined>;
  
  // Chat data methods
  getUserChatData(userId: number): Promise<UserChatData | undefined>;
  saveUserChatData(data: InsertUserChatData): Promise<UserChatData>;
  updateUserChatData(userId: number, chatData: any): Promise<UserChatData | undefined>;
  
  sessionStore: session.SessionStore;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.SessionStore;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Set trial end date to 30 days from now
    const trialEndsAt = new Date();
    trialEndsAt.setDate(trialEndsAt.getDate() + 30);

    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        trialEndsAt,
        subscriptionStatus: "trial"
      })
      .returning();
    return user;
  }

  async updateUserStripeInfo(userId: number, stripeCustomerId: string, stripeSubscriptionId: string): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ 
        stripeCustomerId, 
        stripeSubscriptionId,
        subscriptionStatus: "active",
        updatedAt: new Date()
      })
      .where(eq(users.id, userId))
      .returning();
    return user || undefined;
  }

  async updateUserSubscriptionStatus(userId: number, status: string): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ 
        subscriptionStatus: status,
        updatedAt: new Date()
      })
      .where(eq(users.id, userId))
      .returning();
    return user || undefined;
  }

  async makeUserAdmin(userId: number): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ 
        isAdmin: true,
        subscriptionStatus: "active", // Admins get free access
        updatedAt: new Date()
      })
      .where(eq(users.id, userId))
      .returning();
    return user || undefined;
  }

  // Chat data methods
  async getUserChatData(userId: number): Promise<UserChatData | undefined> {
    const [data] = await db.select().from(userChatData).where(eq(userChatData.userId, userId));
    return data || undefined;
  }

  async saveUserChatData(data: InsertUserChatData): Promise<UserChatData> {
    const [savedData] = await db
      .insert(userChatData)
      .values(data)
      .returning();
    return savedData;
  }

  async updateUserChatData(userId: number, chatData: any): Promise<UserChatData | undefined> {
    const [updatedData] = await db
      .update(userChatData)
      .set({ 
        chatData,
        updatedAt: new Date()
      })
      .where(eq(userChatData.userId, userId))
      .returning();
    return updatedData || undefined;
  }
}

export const storage = new DatabaseStorage();
