import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import express from "express";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  setupAuth(app);

  // API route for health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', message: 'Chat Tool API is running' });
  });

  // Chat data endpoints
  app.get("/api/chat-data", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    try {
      const chatData = await storage.getUserChatData(req.user!.id);
      if (!chatData) {
        // Return empty default structure if no data exists
        return res.json({
          greeting: [],
          waiting: [],
          cases: [],
          closing: [],
          customTabs: []
        });
      }
      res.json(chatData.chatData);
    } catch (error) {
      console.error("Get chat data error:", error);
      res.status(500).json({ error: "Failed to get chat data" });
    }
  });

  app.post("/api/chat-data", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    try {
      const userId = req.user!.id;
      const chatData = req.body;

      // Check if user data already exists
      const existingData = await storage.getUserChatData(userId);
      
      if (existingData) {
        // Update existing data
        const updatedData = await storage.updateUserChatData(userId, chatData);
        res.json(updatedData);
      } else {
        // Create new data
        const newData = await storage.saveUserChatData({
          userId,
          chatData
        });
        res.json(newData);
      }
    } catch (error) {
      console.error("Save chat data error:", error);
      res.status(500).json({ error: "Failed to save chat data" });
    }
  });

  // Stripe routes will be added when keys are provided
  if (process.env.STRIPE_SECRET_KEY) {
    const Stripe = require("stripe");
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
      apiVersion: "2023-10-16",
    });

    // Create subscription
    app.post('/api/create-subscription', async (req, res) => {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      try {
        const { priceId } = req.body;
        const user = req.user!;

        let customerId = user.stripeCustomerId;

        // Create customer if doesn't exist
        if (!customerId) {
          const customer = await stripe.customers.create({
            email: user.email,
            name: user.username,
          });
          customerId = customer.id;
        }

        // Create subscription
        const subscription = await stripe.subscriptions.create({
          customer: customerId,
          items: [{ price: priceId }],
          payment_behavior: 'default_incomplete',
          expand: ['latest_invoice.payment_intent'],
        });

        // Update user with stripe info
        await storage.updateUserStripeInfo(user.id, customerId, subscription.id);

        res.json({
          subscriptionId: subscription.id,
          clientSecret: subscription.latest_invoice?.payment_intent?.client_secret,
        });
      } catch (error: any) {
        console.error("Create subscription error:", error);
        res.status(400).json({ error: error.message });
      }
    });

    // Handle Stripe webhooks
    app.post('/api/webhooks/stripe', express.raw({type: 'application/json'}), async (req, res) => {
      const sig = req.headers['stripe-signature'];
      let event;

      try {
        event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
      } catch (err: any) {
        console.log(`Webhook signature verification failed.`, err.message);
        return res.status(400).send(`Webhook Error: ${err.message}`);
      }

      // Handle the event
      switch (event.type) {
        case 'customer.subscription.updated':
        case 'customer.subscription.deleted':
          const subscription = event.data.object;
          // Update user subscription status based on subscription status
          // This would need to find user by stripe customer ID and update status
          break;
        default:
          console.log(`Unhandled event type ${event.type}`);
      }

      res.json({received: true});
    });
  }

  const httpServer = createServer(app);
  return httpServer;
}
