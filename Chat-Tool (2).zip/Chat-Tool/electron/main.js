const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs-extra');
const isDev = require('electron-is-dev');

// Data file path - stored in the user's app data directory
const userDataPath = app.getPath('userData');
const dataFilePath = path.join(userDataPath, 'chatAppData.json');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
  });

  const startUrl = isDev
    ? 'http://localhost:5000' // Development server
    : `file://${path.join(__dirname, '../build/index.html')}`; // Production build

  mainWindow.loadURL(startUrl);

  // Remove menu bar in production
  if (!isDev) {
    mainWindow.setMenu(null);
  }

  if (isDev) {
    mainWindow.webContents.openDevTools();
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// Initialize the app
app.whenReady().then(() => {
  createWindow();

  // Check if data file exists, if not create it with default data
  if (!fs.existsSync(dataFilePath)) {
    console.log('Creating initial data file...');
    const defaultData = {
      greeting: [],
      waiting: [],
      cases: [],
      closing: [],
      comments: []
    };
    fs.writeJsonSync(dataFilePath, defaultData);
  }
});

// Quit when all windows are closed
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (mainWindow === null) {
    createWindow();
  }
});

// IPC handlers for file operations
ipcMain.handle('save-data', async (event, data) => {
  try {
    await fs.writeJson(dataFilePath, data, { spaces: 2 });
    return { success: true };
  } catch (error) {
    console.error('Error saving data:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('load-data', async () => {
  try {
    if (fs.existsSync(dataFilePath)) {
      const data = await fs.readJson(dataFilePath);
      return { success: true, data };
    } else {
      // Return empty data structure if file doesn't exist yet
      const defaultData = {
        greeting: [],
        waiting: [],
        cases: [],
        closing: [],
        comments: []
      };
      return { success: true, data: defaultData };
    }
  } catch (error) {
    console.error('Error loading data:', error);
    return { success: false, error: error.message };
  }
});