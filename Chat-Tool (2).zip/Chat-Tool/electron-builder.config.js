/**
 * @type {import('electron-builder').Configuration}
 * @see https://www.electron.build/configuration/configuration
 */
module.exports = {
  appId: "com.chat-tool.app",
  productName: "Chat Tool App",
  directories: {
    output: "release"
  },
  files: [
    "dist/**/*",
    "electron/**/*"
  ],
  win: {
    target: [
      {
        target: "portable",
        arch: ["x64"]
      },
      {
        target: "nsis",
        arch: ["x64"]
      }
    ],
    icon: "assets/icon.ico" // Μπορείτε να μετατρέψετε το SVG σε ICO για Windows
  },
  mac: {
    target: ["dmg"],
    icon: "assets/icon.icns" // Μπορείτε να μετατρέψετε το SVG σε ICNS για Mac
  },
  linux: {
    target: ["AppImage"],
    icon: "assets/icon.png"
  },
  nsis: {
    oneClick: false,
    allowToChangeInstallationDirectory: true,
    createDesktopShortcut: true
  }
};