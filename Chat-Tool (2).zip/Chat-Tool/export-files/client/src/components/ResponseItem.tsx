import { useState } from 'react';
import { Response } from '@/types';
import { useChatTool } from '@/contexts/ChatToolContext';
import { useCopyToClipboard } from '@/hooks/useCopyToClipboard';
import { replaceGreetingPlaceholders } from '@/lib/utils';

interface ResponseItemProps {
  response: Response;
  onShowNotification: (text?: string) => void;
  onOpenEditModal: (response: Response) => void;
  onOpenTitleModal: (response: Response) => void;
}

const ResponseItem = ({ 
  response, 
  onShowNotification,
  onOpenEditModal,
  onOpenTitleModal
}: ResponseItemProps) => {
  const { deleteResponse } = useChatTool();
  const { copyText, copyBasedOnTime } = useCopyToClipboard(onShowNotification);
  
  // Handle delete
  const handleDelete = () => {
    if (window.confirm(`Are you sure you want to delete "${response.title}"?`)) {
      deleteResponse(response.id, response.category);
      onShowNotification('Response deleted successfully!');
    }
  };

  return (
    <div className="message-container bg-white rounded border border-gray-200 mb-2 overflow-hidden" data-id={response.id}>
      <div className="py-0 px-1 border-b border-gray-100 flex justify-between items-center bg-secondary-50 h-5">
        <div className="flex items-center">
          <h4 className="font-normal text-xs editable-title truncate max-w-[150px]">{response.title}</h4>
          <button 
            className="ml-0.5 text-gray-500 hover:text-primary-600 edit-title-btn"
            onClick={() => onOpenTitleModal(response)}
          >
            <i className="fas fa-pencil-alt text-[10px]"></i>
          </button>
        </div>
        <div className="flex items-center gap-0">
          <button 
            className="text-gray-500 hover:text-primary-600 message-edit-btn py-0 px-1"
            onClick={() => onOpenEditModal(response)}
          >
            <i className="fas fa-edit text-[10px]"></i>
          </button>
          <button 
            className="text-gray-500 hover:text-alert-500 message-delete-btn py-0 px-1"
            onClick={handleDelete}
          >
            <i className="fas fa-trash text-[10px]"></i>
          </button>
        </div>
      </div>
      <div className="p-2">
        <button 
          className="w-full text-left bg-secondary-100 hover:bg-secondary-200 active:bg-primary-600 active:text-white transition-colors duration-150 p-2 rounded border border-secondary-300 relative pr-10 text-sm"
          onClick={() => {
            // Check if the content contains greeting pattern
            if (response.content.includes('Καλημέρα/Καλησπέρα')) {
              // Apply the replacement and copy the content
              const processedContent = replaceGreetingPlaceholders(response.content, true);
              copyText(processedContent);
            } else {
              copyText(response.content);
            }
          }}
          onDoubleClick={() => {
            if (response.contentEN) {
              // Check if the English content contains greeting pattern
              if (response.contentEN.includes('Good Morning/Good Evening')) {
                // Apply the replacement and copy the content
                const processedContent = replaceGreetingPlaceholders(response.contentEN, false);
                copyText(processedContent);
              } else {
                copyText(response.contentEN);
              }
            }
          }}
        >
          {response.content}
          <span className="absolute right-1 top-1/2 transform -translate-y-1/2 text-xs text-gray-500">
            <i className="fas fa-copy"></i>
          </span>
        </button>
      </div>
    </div>
  );
};

export default ResponseItem;
