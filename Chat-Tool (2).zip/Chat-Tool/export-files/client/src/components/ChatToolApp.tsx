import { useState, useEffect } from 'react';
import { Link } from 'wouter';
import { useChatTool } from '@/contexts/ChatToolContext';
import TabNavigation from '@/components/TabNavigation';
import Header from '@/components/Header';
import EditModal from '@/components/EditModal';
import EditTitleModal from '@/components/EditTitleModal';
import CopyAlert from '@/components/CopyAlert';
import { TabNames } from '@/types';
import ResponseItem from '@/components/ResponseItem';
import CaseItem from '@/components/CaseItem';
import CategoryItem from '@/components/CategoryItem';
import { copyToClipboard } from '@/lib/utils';

// Import Font Awesome
import '@fortawesome/fontawesome-free/css/all.min.css';

const ChatToolApp = () => {
  const { 
    state, 
    addResponse, 
    updateResponse, 
    deleteResponse, 
    updateResponseTitle,
    addCase, 
    updateCase, 
    deleteCase, 
    addCategory,
    updateCategory,
    deleteCategory,
    addResponseToCase,
    deleteResponseFromCase
  } = useChatTool();
  
  // Get the active tab from localStorage (if exists) or use the default GREETING tab
  const savedTab = localStorage.getItem('activeTab');
  const initialTab = savedTab ? (savedTab as TabNames) : TabNames.GREETING;
  const [activeTab, setActiveTab] = useState<TabNames>(initialTab);
  
  // Update localStorage when tab changes
  const handleTabChange = (tab: TabNames) => {
    localStorage.setItem('activeTab', tab);
    setActiveTab(tab);
  };
  const [showCopyAlert, setShowCopyAlert] = useState(false);
  const [alertText, setAlertText] = useState('Text copied to clipboard!');
  
  // Edit modal state
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState({
    id: '',
    title: '',
    content: '',
    contentEN: '',
    type: '',
    category: ''
  });
  
  // Edit title modal state
  const [editTitleModalOpen, setEditTitleModalOpen] = useState(false);
  const [editingTitle, setEditingTitle] = useState({
    id: '',
    title: '',
    type: ''
  });

  // Handle copy notification
  const showCopyNotification = (customText?: string) => {
    setAlertText(customText || 'Text copied to clipboard!');
    setShowCopyAlert(true);
    setTimeout(() => setShowCopyAlert(false), 2000);
  };
  
  // Function to copy text to clipboard
  const copyText = async (text: string) => {
    try {
      await copyToClipboard(text);
      showCopyNotification();
    } catch (error) {
      console.error('Failed to copy text:', error);
      showCopyNotification('Failed to copy text to clipboard');
    }
  };

  // Handle adding new items
  const handleAddNewItem = (type: string) => {
    switch (type) {
      case 'greeting':
      case 'waiting':
      case 'closing':
        setEditingItem({
          id: '',
          title: `New ${type} response`,
          content: '',
          contentEN: '',
          type: type,
          category: type
        });
        setEditModalOpen(true);
        break;
      case 'cases':
        setEditingTitle({
          id: '',
          title: 'New Case',
          type: 'case'
        });
        setEditTitleModalOpen(true);
        break;
      case 'comments':
        setEditingTitle({
          id: '',
          title: 'New Category',
          type: 'category'
        });
        setEditTitleModalOpen(true);
        break;
    }
  };

  // Handle save from edit modal
  const handleSaveEdit = (title: string, content: string, contentEN: string) => {
    const { id, type, category } = editingItem;
    
    if (type === 'case-response') {
      // Adding new response to a case
      addResponseToCase(category, {
        id: Date.now().toString(),
        content, 
        contentEN
      });
      showCopyNotification('New response added to case successfully!');
    } else if (type === 'edit-case-response') {
      // Edit existing response in a case
      // Find the case
      const caseToUpdate = state.cases.find(c => c.id === category);
      if (caseToUpdate) {
        // Find the response
        const updatedResponses = caseToUpdate.responses.map(response => 
          response.id === id ? { ...response, content, contentEN } : response
        );
        
        // Update the case
        updateCase({
          ...caseToUpdate,
          responses: updatedResponses
        });
        showCopyNotification('Case response updated successfully!');
      }
    } else if (!id) {
      // Adding new regular response
      addResponse({
        id: Date.now().toString(),
        title,
        content,
        contentEN,
        category: type
      });
      showCopyNotification('New response added successfully!');
    } else {
      // Update existing regular response
      updateResponse({
        id,
        title,
        content,
        contentEN: contentEN || '',
        category
      });
      showCopyNotification('Response updated successfully!');
    }
    
    setEditModalOpen(false);
  };
  
  // Handle save from title modal
  const handleSaveTitleEdit = (title: string) => {
    const { id, type } = editingTitle;
    
    if (!id) {
      // Adding new item
      if (type === 'case') {
        addCase({
          id: Date.now().toString(),
          title,
          responses: []
        });
        showCopyNotification('New case added successfully!');
      } else if (type === 'category') {
        addCategory({
          id: Date.now().toString(),
          title,
          subcategories: []
        });
        showCopyNotification('New category added successfully!');
      }
    } else {
      // Update existing item title
      if (type === 'response-title') {
        updateResponseTitle(id, title, editingItem.category || 'greeting');
        showCopyNotification('Response title updated successfully!');
      } else if (type === 'case-title') {
        const caseToUpdate = state.cases.find(c => c.id === id);
        if (caseToUpdate) {
          updateCase({
            ...caseToUpdate,
            title
          });
          showCopyNotification('Case title updated successfully!');
        }
      } else if (type === 'category-title') {
        const categoryToUpdate = state.comments.find(c => c.id === id);
        if (categoryToUpdate) {
          updateCategory({
            ...categoryToUpdate,
            title
          });
          showCopyNotification('Category title updated successfully!');
        }
      }
    }
    
    setEditTitleModalOpen(false);
  };

  return (
    <div className="min-h-screen pb-16">
      <Header onSaveAll={() => showCopyNotification('All changes saved successfully!')} />
      
      <div className="max-w-4xl mx-auto p-2">
        {/* Tab Content Area */}
        <div className="mb-14">
          {/* Greeting Tab Content */}
          {activeTab === TabNames.GREETING && (
            <div>
              <div className="flex justify-between mb-2">
                <h2 className="text-base font-semibold text-primary-700">Άνοιγμα Responses</h2>
                <button 
                  className="bg-primary-500 hover:bg-primary-600 text-white py-1 px-2 rounded text-xs flex items-center gap-1"
                  onClick={() => handleAddNewItem('greeting')}
                >
                  <i className="fas fa-plus"></i> Add New
                </button>
              </div>
              
              {state.greeting && state.greeting.length > 0 ? state.greeting.map(response => (
                <ResponseItem 
                  key={response.id} 
                  response={response} 
                  onShowNotification={showCopyNotification}
                  onOpenEditModal={(item) => {
                    setEditingItem({
                      id: item.id,
                      title: item.title,
                      content: item.content,
                      contentEN: item.contentEN || '',
                      type: 'edit',
                      category: 'greeting'
                    });
                    setEditModalOpen(true);
                  }}
                  onOpenTitleModal={(item) => {
                    setEditingTitle({
                      id: item.id,
                      title: item.title,
                      type: 'response-title'
                    });
                    setEditTitleModalOpen(true);
                  }}
                />
              )) : (
                <div className="bg-gray-100 p-4 rounded text-center">
                  No greeting responses found. Add new ones with the button above.
                </div>
              )}
            </div>
          )}

          {/* Waiting Tab Content */}
          {activeTab === TabNames.WAITING && (
            <div>
              <div className="flex justify-between mb-2">
                <h2 className="text-base font-semibold text-primary-700">Αναμονή Responses</h2>
                <button 
                  className="bg-primary-500 hover:bg-primary-600 text-white py-1 px-2 rounded text-xs flex items-center gap-1"
                  onClick={() => handleAddNewItem('waiting')}
                >
                  <i className="fas fa-plus"></i> Add New
                </button>
              </div>
              
              {state.waiting && state.waiting.length > 0 ? state.waiting.map(response => (
                <ResponseItem 
                  key={response.id} 
                  response={response} 
                  onShowNotification={showCopyNotification}
                  onOpenEditModal={(item) => {
                    setEditingItem({
                      id: item.id,
                      title: item.title,
                      content: item.content,
                      contentEN: item.contentEN || '',
                      type: 'edit',
                      category: 'waiting'
                    });
                    setEditModalOpen(true);
                  }}
                  onOpenTitleModal={(item) => {
                    setEditingTitle({
                      id: item.id,
                      title: item.title,
                      type: 'response-title'
                    });
                    setEditTitleModalOpen(true);
                  }}
                />
              )) : (
                <div className="bg-gray-100 p-4 rounded text-center">
                  No waiting responses found. Add new ones with the button above.
                </div>
              )}
            </div>
          )}

          {/* Cases Tab Content */}
          {activeTab === TabNames.CASES && (
            <div>
              <div className="flex justify-between mb-2">
                <h2 className="text-base font-semibold text-primary-700">Cases</h2>
                <button 
                  className="bg-primary-500 hover:bg-primary-600 text-white py-1 px-2 rounded text-xs flex items-center gap-1"
                  onClick={() => handleAddNewItem('cases')}
                >
                  <i className="fas fa-plus"></i> Add New Case
                </button>
              </div>
              
              {state.cases && state.cases.length > 0 ? (
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2">
                  {state.cases.map(caseItem => (
                    <div key={caseItem.id} className="case-item mb-2">
                      <Link 
                        to={`/case/${caseItem.id}`}
                        className="block w-full bg-white shadow-sm hover:shadow-md transition-shadow rounded border border-gray-200 p-1.5 text-center"
                      >
                        <div className="flex flex-col items-center justify-between h-full">
                          <div className="w-6 h-6 rounded-full bg-primary-100 flex items-center justify-center text-primary-600 text-xs">
                            <i className="fas fa-briefcase"></i>
                          </div>
                          <h3 className="font-medium text-xs mt-1 mb-0.5 line-clamp-1">{caseItem.title}</h3>
                          <span className="text-[10px] text-gray-500">
                            {caseItem.responses.length} {caseItem.responses.length === 1 ? 'resp.' : 'resp.'}
                          </span>
                          
                          <div className="mt-0.5 flex items-center gap-0">
                            <button 
                              className="text-gray-500 hover:text-primary-500 p-0.5"
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                setEditingTitle({
                                  id: caseItem.id,
                                  title: caseItem.title,
                                  type: 'case-title'
                                });
                                setEditTitleModalOpen(true);
                              }}
                            >
                              <i className="fas fa-pencil-alt text-[10px]"></i>
                            </button>
                            <button 
                              className="text-gray-500 hover:text-alert-500 p-0.5"
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                if (window.confirm(`Are you sure you want to delete "${caseItem.title}"?`)) {
                                  deleteCase(caseItem.id);
                                  showCopyNotification('Case deleted successfully!');
                                }
                              }}
                            >
                              <i className="fas fa-trash text-[10px]"></i>
                            </button>
                          </div>
                        </div>
                      </Link>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="bg-gray-100 p-4 rounded text-center">
                  No cases found. Add new ones with the button above.
                </div>
              )}
            </div>
          )}

          {/* Closing Tab Content */}
          {activeTab === TabNames.CLOSING && (
            <div>
              <div className="flex justify-between mb-2">
                <h2 className="text-base font-semibold text-primary-700">Κλείσιμο Responses</h2>
                <button 
                  className="bg-primary-500 hover:bg-primary-600 text-white py-1 px-2 rounded text-xs flex items-center gap-1"
                  onClick={() => handleAddNewItem('closing')}
                >
                  <i className="fas fa-plus"></i> Add New
                </button>
              </div>
              
              {state.closing && state.closing.length > 0 ? state.closing.map(response => (
                <ResponseItem 
                  key={response.id} 
                  response={response} 
                  onShowNotification={showCopyNotification}
                  onOpenEditModal={(item) => {
                    setEditingItem({
                      id: item.id,
                      title: item.title,
                      content: item.content,
                      contentEN: item.contentEN || '',
                      type: 'edit',
                      category: 'closing'
                    });
                    setEditModalOpen(true);
                  }}
                  onOpenTitleModal={(item) => {
                    setEditingTitle({
                      id: item.id,
                      title: item.title,
                      type: 'response-title'
                    });
                    setEditTitleModalOpen(true);
                  }}
                />
              )) : (
                <div className="bg-gray-100 p-4 rounded text-center">
                  No closing responses found. Add new ones with the button above.
                </div>
              )}
            </div>
          )}

          {/* Comments Tab Content */}
          {activeTab === TabNames.COMMENTS && (
            <div>
              <div className="flex justify-between mb-2">
                <h2 className="text-base font-semibold text-primary-700">Σχόλια & Υποκατηγορίες</h2>
                <button 
                  className="bg-primary-500 hover:bg-primary-600 text-white py-1 px-2 rounded text-xs flex items-center gap-1"
                  onClick={() => handleAddNewItem('comments')}
                >
                  <i className="fas fa-plus"></i> Add Category
                </button>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {state.comments && state.comments.length > 0 ? state.comments.map(category => (
                  <CategoryItem 
                    key={category.id} 
                    category={category} 
                    onShowNotification={showCopyNotification}
                    onOpenTitleModal={(item) => {
                      setEditingTitle({
                        id: item.id,
                        title: item.title,
                        type: 'category-title'
                      });
                      setEditTitleModalOpen(true);
                    }}
                  />
                )) : (
                  <div className="bg-gray-100 p-2 rounded text-center text-sm col-span-2">
                    No categories found. Add new ones with the button above.
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      <EditModal
        isOpen={editModalOpen}
        onClose={() => setEditModalOpen(false)}
        onSave={handleSaveEdit}
        title={editingItem.title}
        content={editingItem.content}
        contentEN={editingItem.contentEN}
      />
      
      <EditTitleModal
        isOpen={editTitleModalOpen}
        onClose={() => setEditTitleModalOpen(false)}
        onSave={handleSaveTitleEdit}
        title={editingTitle.title}
      />

      {/* Copy Notification */}
      <CopyAlert show={showCopyAlert} text={alertText} />

      {/* Bottom Navigation */}
      <TabNavigation activeTab={activeTab} onChangeTab={handleTabChange} />
    </div>
  );
};

export default ChatToolApp;
