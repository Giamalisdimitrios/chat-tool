import { useState } from 'react';
import { Category } from '@/types';
import { useChatTool } from '@/contexts/ChatToolContext';

interface CategoryItemProps {
  category: Category;
  onShowNotification: (text?: string) => void;
  onOpenTitleModal: (category: Category) => void;
}

const CategoryItem = ({ 
  category, 
  onShowNotification,
  onOpenTitleModal
}: CategoryItemProps) => {
  const { deleteCategory, addSubcategory } = useChatTool();
  const [isAddingSubcategory, setIsAddingSubcategory] = useState(false);
  const [newSubcategoryTitle, setNewSubcategoryTitle] = useState('');
  
  // Handle delete
  const handleDelete = () => {
    if (window.confirm(`Are you sure you want to delete "${category.title}"?`)) {
      deleteCategory(category.id);
      onShowNotification('Category deleted successfully!');
    }
  };
  
  // Handle add subcategory
  const handleAddSubcategory = () => {
    if (newSubcategoryTitle.trim()) {
      addSubcategory(category.id, {
        id: Date.now().toString(),
        title: newSubcategoryTitle,
        responses: []
      });
      setNewSubcategoryTitle('');
      setIsAddingSubcategory(false);
      onShowNotification('Subcategory added successfully!');
    }
  };
  
  // Handle open subcategory management
  const handleOpenSubcategory = (categoryId: string) => {
    // This would typically navigate to a subcategory management view
    // For now, just show a notification
    onShowNotification(`Opening subcategories for: ${categoryId}`);
  };

  return (
    <div className="category-container bg-white rounded border border-gray-200 overflow-hidden">
      <div className="py-0 px-1 border-b border-gray-100 flex justify-between items-center bg-secondary-700 text-white h-5">
        <div className="flex items-center">
          <h4 className="font-normal text-xs editable-title truncate max-w-[150px]">{category.title}</h4>
          <button 
            className="ml-0.5 text-white hover:text-secondary-200 edit-title-btn"
            onClick={() => onOpenTitleModal(category)}
          >
            <i className="fas fa-pencil-alt text-[10px]"></i>
          </button>
        </div>
        <div className="flex items-center gap-0">
          <button 
            className="text-white hover:text-secondary-200 add-subcategory-btn py-0 px-1" 
            title="Add Subcategory"
            onClick={() => setIsAddingSubcategory(!isAddingSubcategory)}
          >
            <i className="fas fa-folder-plus text-[10px]"></i>
          </button>
          <button 
            className="text-white hover:text-alert-200 category-delete-btn py-0 px-1"
            onClick={handleDelete}
          >
            <i className="fas fa-trash text-[10px]"></i>
          </button>
        </div>
      </div>
      <div className="p-2">
        {isAddingSubcategory && (
          <div className="mb-2 p-2 bg-secondary-50 rounded border border-secondary-200">
            <input
              type="text"
              className="w-full p-1 text-sm border border-secondary-300 rounded mb-1"
              placeholder="Enter subcategory title..."
              value={newSubcategoryTitle}
              onChange={(e) => setNewSubcategoryTitle(e.target.value)}
            />
            <div className="flex justify-end gap-1">
              <button 
                className="bg-gray-300 hover:bg-gray-400 text-gray-800 px-2 py-1 rounded text-xs"
                onClick={() => setIsAddingSubcategory(false)}
              >
                Cancel
              </button>
              <button 
                className="bg-primary-600 hover:bg-primary-700 text-white px-2 py-1 rounded text-xs"
                onClick={handleAddSubcategory}
              >
                Add
              </button>
            </div>
          </div>
        )}
        
        <button 
          className="w-full text-left bg-secondary-100 hover:bg-secondary-200 active:bg-secondary-700 active:text-white transition-colors duration-150 p-2 rounded border border-secondary-300 mb-1 text-xs"
          onClick={() => handleOpenSubcategory(category.id)}
        >
          Διαχείριση υποκατηγοριών <i className="fas fa-chevron-right float-right mt-0.5"></i>
        </button>
        
        {(category.subcategories?.length || 0) > 0 && (
          <div className="text-xs text-gray-500">
            {category.subcategories?.length} subcategories
          </div>
        )}
      </div>
    </div>
  );
};

export default CategoryItem;
