import { useChatTool } from '@/contexts/ChatToolContext';
import { useState, useRef, useEffect, useCallback } from 'react';
import { ChatToolData } from '@/types';
import { useToast } from '@/hooks/use-toast';

interface HeaderProps {
  onSaveAll: () => void;
}

const Header = ({ onSaveAll }: HeaderProps) => {
  const { exportData, importData } = useChatTool();
  const [showMenu, setShowMenu] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleExport = () => {
    exportData();
    setShowMenu(false);
  };

  const handleSaveAll = () => {
    onSaveAll();
    setShowMenu(false);
  };
  
  const handleImportClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
    setShowMenu(false);
  };
  
  const handleFileChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) {
      console.log("No file selected");
      return;
    }
    
    console.log("File selected:", file.name, file.type, file.size);
    
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        console.log("File read completed");
        const fileContent = e.target?.result as string;
        console.log("File content (first 100 chars):", fileContent.substring(0, 100));
        
        let parsedData: any;
        try {
          parsedData = JSON.parse(fileContent);
          console.log("JSON parsed successfully");
        } catch (parseError) {
          console.error("JSON parse error:", parseError);
          toast({
            title: "Error",
            description: "Failed to parse the imported file. Make sure it's a valid JSON file.",
            variant: "destructive"
          });
          return;
        }
        
        // Type check
        console.log("Checking file structure:", 
          "greeting" in parsedData, 
          "waiting" in parsedData, 
          "cases" in parsedData, 
          "closing" in parsedData, 
          "comments" in parsedData
        );
        
        if (
          !parsedData.greeting || 
          !parsedData.waiting || 
          !parsedData.cases || 
          !parsedData.closing || 
          !parsedData.comments
        ) {
          console.error("Missing required data sections");
          toast({
            title: "Error",
            description: "Invalid file format. Missing required data sections.",
            variant: "destructive"
          });
          return;
        }
        
        // Manually validate that each section is an array
        const arrayChecks = {
          greeting: Array.isArray(parsedData.greeting),
          waiting: Array.isArray(parsedData.waiting),
          cases: Array.isArray(parsedData.cases),
          closing: Array.isArray(parsedData.closing),
          comments: Array.isArray(parsedData.comments)
        };
        
        console.log("Array checks:", arrayChecks);
        
        if (!arrayChecks.greeting || !arrayChecks.waiting || !arrayChecks.cases || 
            !arrayChecks.closing || !arrayChecks.comments) {
          console.error("Invalid data structure");
          toast({
            title: "Error",
            description: "Invalid data structure. Expected arrays for each section.",
            variant: "destructive"
          });
          return;
        }
        
        console.log("Data validation passed, attempting to import...");
        const success = importData(parsedData);
        console.log("Import result:", success);
        
        if (success) {
          toast({
            title: "Success",
            description: "Data imported successfully! Refresh the page to see changes.",
            variant: "default"
          });
          
          // Create a direct localStorage update to ensure data persistence
          try {
            console.log("Directly updating localStorage with imported data");
            localStorage.setItem('chatToolData', JSON.stringify(parsedData));
            
            // Force a page reload to ensure the new data is loaded properly
            setTimeout(() => {
              console.log("Reloading page to reflect imported data");
              window.location.reload();
            }, 1500);
          } catch (storageError) {
            console.error("localStorage update error:", storageError);
          }
        } else {
          console.error("Import function returned false");
          toast({
            title: "Error",
            description: "Failed to import data. Please try again.",
            variant: "destructive"
          });
        }
      } catch (error) {
        console.error('Error during file processing:', error);
        toast({
          title: "Error",
          description: "Failed to process the imported file. Check console for details.",
          variant: "destructive"
        });
      }
    };
    
    reader.onerror = (error) => {
      console.error("FileReader error:", error);
      toast({
        title: "Error",
        description: "Failed to read the file. Please try again.",
        variant: "destructive"
      });
    };
    
    console.log("Starting file read...");
    reader.readAsText(file);
    
    // Reset the file input so the same file can be selected again if needed
    if (event.target) {
      event.target.value = '';
    }
  }, [importData, toast]);

  // Close menu when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setShowMenu(false);
      }
    }
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <header className="bg-white rounded-lg shadow mb-2 p-2 max-w-4xl mx-auto mt-2">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-bold text-primary-700">Chat Tool Admin</h1>
        <div className="relative" ref={menuRef}>
          <button 
            className="w-8 h-8 flex items-center justify-center text-gray-600 hover:text-primary-600 hover:bg-gray-100 rounded-full"
            onClick={() => setShowMenu(!showMenu)}
          >
            <i className="fas fa-ellipsis-v"></i>
          </button>
          
          {showMenu && (
            <div className="absolute right-0 mt-1 w-36 bg-white shadow-lg rounded-md z-10 py-1 border border-gray-200">
              <button 
                className="w-full text-left px-3 py-2 text-sm hover:bg-gray-100 flex items-center gap-2"
                onClick={handleSaveAll}
              >
                <i className="fas fa-save text-success-500"></i> Save All
              </button>
              <button 
                className="w-full text-left px-3 py-2 text-sm hover:bg-gray-100 flex items-center gap-2"
                onClick={handleExport}
              >
                <i className="fas fa-download text-primary-600"></i> Export
              </button>
              <button 
                className="w-full text-left px-3 py-2 text-sm hover:bg-gray-100 flex items-center gap-2"
                onClick={handleImportClick}
              >
                <i className="fas fa-upload text-warning-600"></i> Import
              </button>
              <input 
                type="file" 
                ref={fileInputRef}
                className="hidden" 
                accept=".json" 
                onChange={handleFileChange}
              />
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
