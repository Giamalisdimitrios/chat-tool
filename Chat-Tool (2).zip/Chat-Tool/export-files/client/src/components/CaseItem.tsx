import { useState } from 'react';
import { Case } from '@/types';
import { useChatTool } from '@/contexts/ChatToolContext';
import { useCopyToClipboard } from '@/hooks/useCopyToClipboard';

interface CaseItemProps {
  caseItem: Case;
  onShowNotification: (text?: string) => void;
  onOpenTitleModal: (caseItem: Case) => void;
}

const CaseItem = ({ 
  caseItem, 
  onShowNotification,
  onOpenTitleModal
}: CaseItemProps) => {
  const { deleteCase, addResponseToCase } = useChatTool();
  const { copyText } = useCopyToClipboard(onShowNotification);
  const [newResponse, setNewResponse] = useState('');
  const [isAddingResponse, setIsAddingResponse] = useState(false);
  
  // Handle delete
  const handleDelete = () => {
    if (window.confirm(`Are you sure you want to delete "${caseItem.title}"?`)) {
      deleteCase(caseItem.id);
      onShowNotification('Case deleted successfully!');
    }
  };
  
  // Handle add new response
  const handleAddResponse = () => {
    if (newResponse.trim()) {
      addResponseToCase(caseItem.id, {
        id: Date.now().toString(),
        content: newResponse,
        contentEN: ''
      });
      setNewResponse('');
      setIsAddingResponse(false);
      onShowNotification('Response added to case successfully!');
    }
  };
  
  // Handle delete response
  const handleDeleteResponse = (responseId: string) => {
    if (window.confirm('Are you sure you want to delete this response?')) {
      const updatedResponses = caseItem.responses.filter(r => r.id !== responseId);
      // Update case with filtered responses
      // This would use updateCase from context
      onShowNotification('Response removed from case successfully!');
    }
  };

  return (
    <div className="case-container bg-white rounded-lg shadow mb-3 overflow-hidden">
      <div className="p-3 border-b border-gray-200 flex justify-between items-center bg-primary-700 text-white">
        <div className="flex items-center">
          <h4 className="font-medium text-sm editable-title">{caseItem.title}</h4>
          <button 
            className="ml-2 text-white hover:text-primary-200 edit-title-btn"
            onClick={() => onOpenTitleModal(caseItem)}
          >
            <i className="fas fa-pencil-alt text-xs"></i>
          </button>
        </div>
        <div className="flex items-center gap-1">
          <button 
            className="text-white hover:text-primary-200 case-edit-btn p-1"
            onClick={() => setIsAddingResponse(!isAddingResponse)}
          >
            <i className="fas fa-plus"></i>
          </button>
          <button 
            className="text-white hover:text-alert-200 case-delete-btn p-1"
            onClick={handleDelete}
          >
            <i className="fas fa-trash"></i>
          </button>
        </div>
      </div>
      <div className="p-3">
        {isAddingResponse && (
          <div className="mb-3 p-2 bg-secondary-50 rounded border border-secondary-200">
            <textarea
              className="w-full p-2 border border-secondary-300 rounded mb-2"
              placeholder="Enter new response..."
              value={newResponse}
              onChange={(e) => setNewResponse(e.target.value)}
              rows={3}
            ></textarea>
            <div className="flex justify-end gap-2">
              <button 
                className="bg-gray-300 hover:bg-gray-400 text-gray-800 px-3 py-1 rounded text-sm"
                onClick={() => setIsAddingResponse(false)}
              >
                Cancel
              </button>
              <button 
                className="bg-primary-600 hover:bg-primary-700 text-white px-3 py-1 rounded text-sm"
                onClick={handleAddResponse}
              >
                Add Response
              </button>
            </div>
          </div>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {caseItem.responses.map(response => (
            <div key={response.id} className="relative group">
              <button 
                className="text-left bg-secondary-100 hover:bg-secondary-200 active:bg-primary-600 active:text-white transition-colors duration-150 p-3 rounded border border-secondary-300 w-full"
                onClick={() => copyText(response.content)}
              >
                {response.content}
              </button>
              <button 
                className="absolute top-1 right-1 bg-white rounded-full p-1 opacity-0 group-hover:opacity-100 text-alert-500 hover:text-alert-600 transition-opacity"
                onClick={() => handleDeleteResponse(response.id)}
              >
                <i className="fas fa-times text-xs"></i>
              </button>
            </div>
          ))}
          
          {caseItem.responses.length === 0 && !isAddingResponse && (
            <div className="text-center text-gray-500 p-4 col-span-2">
              No responses added yet. Click the + button to add responses.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CaseItem;
