import { useEffect, useState } from 'react';
import { useParams, useLocation } from 'wouter';
import { useChatTool } from '@/contexts/ChatToolContext';
import CopyAlert from '@/components/CopyAlert';
import { useCopyToClipboard } from '@/hooks/useCopyToClipboard';
import { Case, Response } from '@/types';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import EditModal from '@/components/EditModal';
import { replaceGreetingPlaceholders, generateId } from '@/lib/utils';

const CaseDetailPage = () => {
  const { state, updateCase, deleteResponseFromCase, addResponseToCase } = useChatTool();
  const [location, setLocation] = useLocation();
  const { caseId } = useParams();
  
  const [caseItem, setCaseItem] = useState<Case | null>(null);
  const [showCopyAlert, setShowCopyAlert] = useState(false);
  const [alertText, setAlertText] = useState('Text copied to clipboard!');
  
  // Edit modal state
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editingResponse, setEditingResponse] = useState({
    id: '',
    title: '',
    content: '',
    contentEN: '',
    index: -1
  });

  // Set document title
  useDocumentTitle(caseItem ? `Case: ${caseItem.title}` : 'Case Details');
  
  // Get the selected case by ID
  useEffect(() => {
    if (caseId && state.cases) {
      const foundCase = state.cases.find(c => c.id === caseId);
      if (foundCase) {
        setCaseItem(foundCase);
      } else {
        // If case not found, redirect back to cases list
        setLocation('/');
      }
    }
  }, [caseId, state, setLocation]);

  // Handle copy notification
  const showCopyNotification = (customText?: string) => {
    setAlertText(customText || 'Text copied to clipboard!');
    setShowCopyAlert(true);
    setTimeout(() => setShowCopyAlert(false), 2000);
  };

  const { copyText } = useCopyToClipboard(showCopyNotification);
  
  // Handle opening edit modal
  const handleOpenEditModal = (response: any, index: number) => {
    setEditingResponse({
      id: response.id,
      title: 'Response',  // Title is not really used for case responses
      content: response.content,
      contentEN: response.contentEN || '',
      index
    });
    setEditModalOpen(true);
  };
  
  // Handle adding new response
  const handleAddNewResponse = () => {
    setEditingResponse({
      id: '',
      title: 'New Response',
      content: '',
      contentEN: '',
      index: -1
    });
    setEditModalOpen(true);
  };
  
  // Handle saving edited responses
  const handleSaveEdit = (title: string, content: string, contentEN: string) => {
    if (caseItem) {
      if (editingResponse.id === '') {
        // Adding a new response
        const newResponseId = generateId();
        
        // Add the new response to the case
        addResponseToCase(caseItem.id, {
          id: newResponseId,
          content,
          contentEN
        });
        
        // Show notification
        showCopyNotification('New response added successfully!');
      } else if (editingResponse.index >= 0) {
        // Updating an existing response
        // Create a deep copy of the case to update
        const updatedCase = { ...caseItem };
        
        // Create a deep copy of the responses array
        const updatedResponses = [...updatedCase.responses];
        
        // Get the current response
        const currentResponse = updatedResponses[editingResponse.index];
        
        // Update the specific response with new content
        updatedResponses[editingResponse.index] = {
          id: currentResponse.id,
          content,
          contentEN
        };
        
        // Set the updated responses array
        updatedCase.responses = updatedResponses;
        
        // Update the case in context
        updateCase(updatedCase);
        
        // Update local state
        setCaseItem(updatedCase);
        
        // Show notification
        showCopyNotification('Response updated successfully!');
      }
    }
    
    // Close modal
    setEditModalOpen(false);
  };

  if (!caseItem) {
    return (
      <div className="p-4 flex justify-center items-center">
        <div className="spinner">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-16 p-2">
      <div className="max-w-4xl mx-auto">
        {/* Header with back button */}
        <div className="flex items-center gap-2 mb-2">
          <button 
            className="bg-secondary-200 hover:bg-secondary-300 text-secondary-800 px-2 py-1 rounded text-sm flex items-center gap-1"
            onClick={() => {
              // Store the active tab as "cases" in localStorage
              localStorage.setItem('activeTab', 'cases');
              // Then navigate back to home
              setLocation('/');
            }}
          >
            <i className="fas fa-arrow-left text-xs"></i> Back
          </button>
          <h1 className="text-base font-semibold text-primary-700">{caseItem.title}</h1>
        </div>

        {/* Case responses */}
        <div className="bg-white rounded border border-gray-200 p-3">
          <div className="flex justify-between mb-2">
            <h2 className="text-sm font-medium">Responses</h2>
            <button 
              className="bg-primary-500 hover:bg-primary-600 text-white py-1 px-2 rounded text-xs flex items-center gap-1"
              onClick={handleAddNewResponse}
            >
              <i className="fas fa-plus"></i> Add New
            </button>
          </div>
          
          {caseItem.responses && caseItem.responses.length > 0 ? (
            <div className="space-y-2">
              {caseItem.responses.map(response => (
                <div key={response.id} className="bg-gray-50 p-2 rounded border border-gray-200">
                  <div className="py-0 px-1 border-b border-gray-100 flex justify-between items-center bg-secondary-50 h-5 mb-2">
                    <div className="flex items-center">
                      <h4 className="font-normal text-xs editable-title truncate max-w-[150px]">Response</h4>
                    </div>
                    <div className="flex items-center gap-0">
                      <button 
                        className="text-gray-500 hover:text-primary-500 py-0 px-1 text-xs flex items-center"
                        onClick={() => handleOpenEditModal(response, caseItem.responses.indexOf(response))}
                      >
                        <i className="fas fa-pencil-alt text-[10px]"></i>
                      </button>
                      <button 
                        className="text-gray-500 hover:text-alert-500 py-0 px-1 text-xs flex items-center"
                        onClick={() => {
                          if (window.confirm('Are you sure you want to delete this response?')) {
                            deleteResponseFromCase(caseItem.id, response.id);
                            showCopyNotification('Response deleted successfully!');
                          }
                        }}
                      >
                        <i className="fas fa-trash text-[10px]"></i>
                      </button>
                    </div>
                  </div>
                  
                  <button 
                    className="w-full text-left bg-secondary-100 hover:bg-secondary-200 active:bg-primary-600 active:text-white transition-colors duration-150 p-2 rounded border border-secondary-300 relative pr-14 text-sm"
                    onClick={() => {
                      // Check if the content contains greeting pattern and replace it
                      if (response.content.includes('Καλημέρα/Καλησπέρα')) {
                        const processedContent = replaceGreetingPlaceholders(response.content, true);
                        copyText(processedContent);
                      } else {
                        copyText(response.content);
                      }
                    }}
                    onDoubleClick={() => {
                      if (response.contentEN) {
                        // Check if English content contains greeting pattern and replace it
                        if (response.contentEN.includes('Good Morning/Good Evening')) {
                          const processedContent = replaceGreetingPlaceholders(response.contentEN, false);
                          copyText(processedContent);
                        } else {
                          copyText(response.contentEN || '');
                        }
                      }
                    }}
                  >
                    {response.content}
                    <span className="absolute right-1 top-1/2 transform -translate-y-1/2 text-xs text-gray-500">
                      <i className="fas fa-copy"></i>
                      {response.contentEN && <span className="ml-1" title="Double-click to copy English text">EN</span>}
                    </span>
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center p-2 bg-gray-50 rounded text-sm">
              <p className="text-gray-600">No responses added to this case yet.</p>
            </div>
          )}
        </div>
      </div>

      {/* Copy Notification */}
      <CopyAlert show={showCopyAlert} text={alertText} />
      
      {/* Edit Modal */}
      <EditModal
        isOpen={editModalOpen}
        onClose={() => setEditModalOpen(false)}
        onSave={handleSaveEdit}
        title={editingResponse.title}
        content={editingResponse.content}
        contentEN={editingResponse.contentEN}
      />
    </div>
  );
};

export default CaseDetailPage;