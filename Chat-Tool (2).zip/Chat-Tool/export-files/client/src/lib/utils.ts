import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date): string {
  return new Intl.DateTimeFormat("el-GR", {
    day: "numeric",
    month: "short",
    year: "numeric",
  }).format(date);
}

export function copyToClipboard(text: string): Promise<void> {
  return navigator.clipboard.writeText(text);
}

export function copyBasedOnTime(morningText: string, eveningText: string): Promise<void> {
  const hour = new Date().getHours();
  const textToCopy = (hour >= 5 && hour < 12) ? morningText : eveningText;
  return copyToClipboard(textToCopy);
}

// Get morning/evening greetings based on current time
export function getTimeBasedGreeting(isGreek: boolean = true, formal: boolean = false): string {
  const hour = new Date().getHours();
  if (isGreek) {
    if (formal) {
      return (hour >= 5 && hour < 12) ? 'Καλημέρα σας!' : 'Καλησπέρα σας!';
    } else {
      return (hour >= 5 && hour < 12) ? 'Καλημέρα!' : 'Καλησπέρα!';
    }
  } else {
    return (hour >= 5 && hour < 12) ? 'Good Morning!' : 'Good Evening!';
  }
}

// Replace placeholder greetings with time-based ones
export function replaceGreetingPlaceholders(text: string, isGreek: boolean = true): string {
  if (!text) return text;
  
  // Check if text contains formal greeting patterns
  const hasFormalGreeting = isGreek 
    ? text.includes('Καλημέρα/Καλησπέρα σας') 
    : false;

  // Get appropriate greeting based on time and formality
  const greeting = getTimeBasedGreeting(isGreek, hasFormalGreeting);
  
  // Replace the placeholder with actual greeting
  if (isGreek) {
    // Handle various Greek greeting patterns
    return text
      .replace(/Καλημέρα\/Καλησπέρα σας!?/g, hasFormalGreeting ? greeting : greeting.replace('!', ' σας!'))
      .replace(/Καλημέρα\/Καλησπέρα!?/g, greeting);
  } else {
    // Handle various English greeting patterns (case insensitive)
    return text
      .replace(/Good Morning\/Good Evening!?/gi, greeting)
      .replace(/Good morning\/Good evening!?/gi, greeting);
  }
}

export function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
}
