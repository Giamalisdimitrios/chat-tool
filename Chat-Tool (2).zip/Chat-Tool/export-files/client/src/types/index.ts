export interface Response {
  id: string;
  title: string;
  content: string;
  contentEN?: string;
  category: string;
}

export interface Case {
  id: string;
  title: string;
  responses: {
    id: string;
    content: string;
    contentEN?: string;
  }[];
}

export interface Category {
  id: string;
  title: string;
  subcategories?: {
    id: string;
    title: string;
    responses: {
      id: string;
      content: string;
      contentEN?: string;
    }[];
  }[];
}

export interface ChatToolData {
  greeting: Response[];
  waiting: Response[];
  cases: Case[];
  closing: Response[];
  comments: Category[];
}

export enum TabNames {
  GREETING = "greeting",
  WAITING = "waiting",
  CASES = "cases",
  CLOSING = "closing",
  COMMENTS = "comments"
}

export interface EditModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (title: string, content: string, contentEN: string) => void;
  title: string;
  content: string;
  contentEN: string;
}

export interface EditTitleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (title: string) => void;
  title: string;
}
