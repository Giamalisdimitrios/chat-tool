import { createContext, useContext, useReducer, useEffect, ReactNode } from 'react';
import { ChatToolData, Response, Case, Category, TabNames } from '@/types';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { isElectron, saveDataToFileSystem, loadDataFromFileSystem } from '@/lib/electronStorage';

// Default initial data based on the HTML template
const defaultData: ChatToolData = {
  greeting: [
    {
      id: '1',
      title: 'Γνωρίζω το αίτημα',
      content: 'Καλημέρα/Καλησπέρα! Έχω δει το αίτημά σου',
      contentEN: 'Good morning! I saw your request',
      category: 'greeting'
    },
    {
      id: '2',
      title: 'Γνωρίζω το μήνυμα',
      content: 'Καλημέρα/Καλησπέρα! Έχω δει το μήνυμά σου',
      contentEN: 'Good morning! I saw your message',
      category: 'greeting'
    },
    {
      id: '3',
      title: 'Πως μπορώ να βοηθήσω;',
      content: 'Καλημέρα/Καλησπέρα! Πώς μπορώ να βοηθήσω;',
      contentEN: 'Good morning! How may I help you?',
      category: 'greeting'
    },
    {
      id: '4',
      title: 'Εχω διαβάσει το αίτημά',
      content: 'Καλημέρα/Καλησπέρα! Έχω διαβάσει το αίτημά σου και θα χαρώ πολύ να βοηθήσω!',
      contentEN: 'Good morning! I have read your request and would be happy to help!',
      category: 'greeting'
    },
    {
      id: '5',
      title: 'Χρόνο για κατάστημα (1)',
      content: 'Θα χρειαστώ λίγο χρόνο για να ενημερώσω το κατάστημα και επιστρέφω αμέσως',
      contentEN: 'I will need some time to inform the store and I will get back to you shortly',
      category: 'greeting'
    },
    {
      id: '6',
      title: 'Χρόνο για κατάστημα (2)',
      content: 'Θα χρειαστώ λίγο χρόνο για να επικοινωνήσω με το κατάστημα και θα επανέλθω το συντομότερο δυνατό!',
      contentEN: 'Please bear with me while I check this with the restaurant / shop and I will get back to you shortly',
      category: 'greeting'
    },
    {
      id: '7',
      title: 'Χρόνο για έλεγχο (1)',
      content: 'Θα χρειαστώ λίγο χρόνο να το ελέγξω και επιστρέφω αμέσως',
      contentEN: 'I\'ll take some time to check it and I\'ll be right back',
      category: 'greeting'
    },
    {
      id: '8',
      title: 'Χρόνο για έλεγχο (2)',
      content: 'Θα χρειαστώ λίγο χρόνο να το διαχειριστώ και επιστρέφω αμέσως',
      contentEN: 'I\'ll need some time to fix it and I\'ll be right back',
      category: 'greeting'
    },
    {
      id: '9',
      title: 'Σε ευχαριστώ για το μήνυμά σου - μισό λεπτό',
      content: 'Σ\' ευχαριστούμε για το μήνυμά σου! Θα χρειαστώ λίγο χρόνο να ελέγξω τι ακριβώς συμβαίνει και σε ενημερώνω άμεσα!',
      contentEN: 'Please bear with me while I check this with the restaurant / shop and I will get back to you shortly',
      category: 'greeting'
    }
  ],
  waiting: [
    {
      id: '10',
      title: 'Αναμονή 8',
      content: 'Καλημέρα/Καλησπέρα! Ζητώ συγνώμη για την καθυστέρηση και την αναμονή 😞 Αν είσαι ακόμα εδώ, τι μπορώ να κάνω για σένα;💖',
      contentEN: 'Good morning! I truly apologize for the delay and the waiting 😞! If you\'re still here, how can I help you? 💖',
      category: 'waiting'
    },
    {
      id: '11',
      title: 'Αναμονή 1',
      content: 'Καλημέρα/Καλησπέρα! Λυπάμαι πολύ για όλη σου την αναμονή. Αν είσαι ακόμα εδώ, πώς θα μπορούσα να σε βοηθήσω;',
      contentEN: 'Good morning! I\'m really sorry for keeping you waiting. If you\'re still here, how can I help you?',
      category: 'waiting'
    },
    {
      id: '12',
      title: 'Αναμονή 2',
      content: 'Καλημέρα/Καλησπέρα! Λυπάμαι που περίμενες παραπάνω απ\' όσο θα θέλαμε! Αυτή τη στιγμή αντιμετωπίζουμε αναπάντεχα αυξημένο φόρτο. Αν είσαι ακόμα εδώ, θα χαρώ πολύ να σε βοηθήσω!',
      contentEN: 'Good morning! I\'m sorry you had to wait longer than we would have liked! We are currently experiencing unexpectedly high workload. If you\'re still here, I\'d be very happy to help you!',
      category: 'waiting'
    },
    {
      id: '13',
      title: 'Αναμονή 3',
      content: 'Καλημέρα/Καλησπέρα! Λυπάμαι που δεν ανταποκρίθηκα νωρίτερα στο μήνυμά σου, αντιμετωπίσαμε αυξημένο φόρτο. Είμαι όμως τώρα εδώ, για να δούμε μαζί ό,τι χρειάζεσαι',
      contentEN: 'Good morning! I\'m sorry I couldn\'t respond to your message sooner, we were dealing with high workload. However, I\'m here now to help you with whatever you need',
      category: 'waiting'
    },
    {
      id: '14',
      title: 'Απολογούμαστε για την αναμονή (4)',
      content: 'Ζητώ συγγνώμη για την αναμονή 😔 Αν είσαι ακόμη στο chat, είμαι εδώ για να δούμε ό,τι χρειάζεσαι 💖',
      contentEN: 'I apologize for the wait 😔 If you\'re still in the chat, I\'m here to see what you need 💖',
      category: 'waiting'
    },
    {
      id: '15',
      title: 'Αναμονή 5',
      content: 'Καλημέρα/Καλησπέρα, λόγω αυξημένου φόρτου δεν κατάφερα να σε βοηθήσω νωρίτερα. Αν είσαι ακόμα εδώ, θα χαρώ πολύ να σε εξυπηρετήσω',
      contentEN: 'Good morning, due to high workload I wasn\'t able to help you earlier. If you\'re still here, I\'d be very happy to help you now',
      category: 'waiting'
    },
    {
      id: '16',
      title: 'Απολογούμαστε για την αναμονή (6)',
      content: 'Σου ζητώ συγγνώμη που περίμενες τόση ώρα! Έχουμε αυξημένο φόρτο και δεν σου απάντησα όσο άμεσα θα ήθελα 😔 Σε περίπτωση που είσαι ακόμα στην συνομιλία θα χαρώ πολύ να σε βοηθήσω',
      contentEN: 'I\'m sorry you had to wait longer than we would have liked 😔',
      category: 'waiting'
    }
  ],
  cases: [
    {
      id: '31',
      title: 'Ακύρωση Παραγγελίας',
      responses: [
        {
          id: '32',
          content: 'Θα χρειαστώ λίγο χρόνο να ελέγξω την κατάσταση της παραγγελίας σου και επιστρέφω αμέσως.'
        }
      ]
    },
    {
      id: '33',
      title: 'Προσθήκη/Αφαίρεση Προϊόντος',
      responses: [
        {
          id: '34',
          content: 'Θα χρειαστώ λίγο χρόνο να ελέγξω αν μπορούμε να προσθέσουμε/αφαιρέσουμε προϊόντα στην παραγγελία σου και επιστρέφω αμέσως.'
        }
      ]
    },
    {
      id: '35',
      title: 'Πορεία Παραγγελίας',
      responses: [
        {
          id: '36',
          content: 'Παρακαλώ θα χρειαστώ λίγο χρόνο να ελέγξω την εξέλιξη της παραγγελίας σου και θα επανέλθω αμέσως',
          contentEN: 'Kindly allow me to check the details of your order and I will get back to you as soon as possible'
        },
        {
          id: '37',
          content: 'Ευχαριστώ για τον χρόνο σου! Με ενημέρωσαν από το κατάστημα πως ο διανομέας είναι καθ\' οδόν και πολύ σύντομα θα παραλάβεις την παραγγελία σου. Καλή σου όρεξη!',
          contentEN: 'The restaurant just informed me that your order is on its way. Thank you for your time and enjoy your meal!'
        },
        {
          id: '38',
          content: 'Θα μπορούσες να μου στείλεις τα στοιχεία διεύθυνσης όπου επιθυμείς να παραδοθεί η παραγγελία σου, ώστε να ενημερώσω το κατάστημα;',
          contentEN: 'Could you please provide me with your exact address notes in order to contact the restaurant on your behalf?'
        }
      ]
    },
    {
      id: '39',
      title: 'Καθυστερημένη Παράδοση',
      responses: [
        {
          id: '40',
          content: 'Σε ευχαριστώ πολύ για την υπομονή σου. Έχω κοιτάξει την παραγγελία σου και βλέπω ότι έχει καθυστερήσει περισσότερο από το συνηθισμένο.'
        },
        {
          id: '41',
          content: 'Έχω ήδη επικοινωνήσει με το κατάστημα και τον διανομέα για να επιταχύνουμε την παράδοση. Θα παραδοθεί σύντομα.'
        }
      ]
    },
    {
      id: '42',
      title: 'Αλλαγή δ/νσης παράδοσης',
      responses: [
        {
          id: '43',
          content: 'Θα μπορούσες να μου στείλεις τα στοιχεία διεύθυνσης όπου επιθυμείς να παραδοθεί η παραγγελία σου, ώστε να ενημερώσω το κατάστημα;'
        }
      ]
    },
    {
      id: '44',
      title: 'Λείπει Προϊόν',
      responses: [
        {
          id: '45',
          content: 'Λυπάμαι για την αναστάτωση! Θα επικοινωνήσω με το κατάστημα για να διερευνήσω γιατί λείπει ένα προϊόν από την παραγγελία σου.'
        }
      ]
    },
    {
      id: '46',
      title: 'Θέμα με Ποιότητα/Θερμοκρασία',
      responses: [
        {
          id: '47',
          content: 'Λυπάμαι πολύ για την εμπειρία σου. Θα καταγράψω το πρόβλημα με την ποιότητα/θερμοκρασία του φαγητού και θα ενημερώσω το κατάστημα.'
        }
      ]
    },
    {
      id: '48',
      title: 'Λάθος Προϊόν',
      responses: [
        {
          id: '49',
          content: 'Λυπάμαι για την ταλαιπωρία. Θα επικοινωνήσω άμεσα με το κατάστημα για να διερευνήσω γιατί έλαβες λάθος προϊόν.'
        }
      ]
    },
    {
      id: '50',
      title: 'Κατεστραμμένο/Χυμένο',
      responses: [
        {
          id: '51',
          content: 'Λυπάμαι πολύ για αυτή την αρνητική εμπειρία. Θα επικοινωνήσω με το κατάστημα για το κατεστραμμένο/χυμένο προϊόν.'
        }
      ]
    },
    {
      id: '52',
      title: 'Λάθος Παραγγελία',
      responses: [
        {
          id: '53',
          content: 'Λυπάμαι για την αναστάτωση. Θα διερευνήσω γιατί έλαβες λάθος παραγγελία και θα επιστρέψω με περισσότερες πληροφορίες.'
        }
      ]
    },
    {
      id: '54',
      title: 'Refunds',
      responses: [
        {
          id: '55',
          content: 'Καταλαβαίνω την απογοήτευσή σου. Θα εξετάσω την κατάσταση και θα σου πω αν μπορούμε να προχωρήσουμε σε επιστροφή χρημάτων.'
        }
      ]
    }
  ],
  closing: [
    {
      id: '20',
      title: 'Polite αποχώρηση: Ο χρήστης δεν ανταποκρίνεται (1)',
      content: 'Θα ήθελες να δούμε κάτι άλλο μαζί;',
      contentEN: 'Can I help you with anything else?',
      category: 'closing'
    },
    {
      id: '21',
      title: 'Polite αποχώρηση: Ο χρήστης δεν ανταποκρίνεται (2)',
      content: 'Είσαι ακόμη εδώ; Ελπίζω να έχεις διαβάσει την απάντηση μου πιο πάνω. Σε περίπτωση που χρειάζεσαι κάτι ακόμα, είμαι εδώ να σε βοηθήσω!💖',
      contentEN: 'Are you still here? I hope you have received my response above. If you need anything else, I\'m here to help you! 💖',
      category: 'closing'
    },
    {
      id: '22',
      title: 'Polite αποχώρηση: Ο χρήστης δεν ανταποκρίνεται (3)',
      content: 'Έχεις δει την απάντησή μου πιο πάνω; Θα παραμείνω λίγα λεπτά ακόμα στη συνομιλία μας',
      contentEN: 'Have you received my response above? I\'ll stay in our chat a few more minutes',
      category: 'closing'
    },
    {
      id: '23',
      title: 'Κλείσιμο: Ο χρήστης δεν ανταποκρίνεται (1)',
      content: 'Σ\' ευχαριστώ που επικοινώνησες μαζί μας. Κάτι τελευταίο, μετά τον τερματισμό της συνομιλίας μας, θα θέλαμε πολύ να μας πεις τη γνώμη σου για την εμπειρία που είχες μιλώντας με την ομάδα μας. Δε θα σου πάρει πάνω από 1 λεπτό! Για οτιδήποτε άλλο χρειαστείς είμαστε εδώ για σένα! 😄',
      contentEN: 'Thank you for reaching out. One last thing, after we\'ve ended our chat, we\'d love to tell us how was your experience contacting with our team. It won\'t take you more than 1 minute! We are always here to help you with anything else you may need😀',
      category: 'closing'
    },
    {
      id: '24',
      title: 'Κλείσιμο: Ο χρήστης δεν ανταποκρίνεται (4)',
      content: 'Μάλλον έχεις αποχωρήσει από τη συνομιλία μας και γι\' αυτό θα χρειαστεί να προχωρήσω με την ολοκλήρωσή της. Κάτι τελευταίο, μετά τον τερματισμό της συνομιλίας μας, θα θέλαμε πολύ να μας πεις τη γνώμη σου για την εμπειρία που είχες μιλώντας με την ομάδα μας. Δε θα σου πάρει πάνω από 1 λεπτό! Για οτιδήποτε άλλο χρειαστείς είμαστε πάντα δίπλα σου! 💖',
      contentEN: 'I guess that you\'re no longer in our chat and so I\'m going to have to end it. We are always here to help you with anything else you may need. One last thing, after we\'ve ended our chat, we\'d love to tell us how was your experience contacting with our team. It won\'t take you more than 1 minute! We are always here to help you with anything else you may need💖',
      category: 'closing'
    },
    {
      id: '25',
      title: 'Κλείσιμο Ευχαριστώ',
      content: 'Παρακαλώ!😊Πριν κλείσουμε την συνομιλία μας, μήπως υπάρχει κάτι άλλο που θα μπορούσα να σε βοηθήσω;',
      contentEN: 'You are welcome! 😊 Before we end our conversation, is there anything else I can help you with?',
      category: 'closing'
    },
    {
      id: '26',
      title: 'Polite αποχώρηση: Ο χρήστης δεν ανταποκρίνεται (4)',
      content: 'Σε βοήθησα με την τελευταία μου απάντηση ή θα ήθελες να δούμε κάτι άλλο μαζί;',
      contentEN: 'Is everything OK? Was my last response helpful or is there anything else I might help you with?',
      category: 'closing'
    },
    {
      id: '27',
      title: 'Polite αποχώρηση: Ο χρήστης δεν ανταποκρίνεται (5)',
      content: 'Λίγο πιο πάνω στη συνομιλία μας θα βρεις την απάντηση στο ερώτημα σου. Ελπίζω να σε καλύπτει και όντως να σε βοήθησα 😀',
      contentEN: 'You will find the answer to your question in my previous response. I hope I was able to help you 😀',
      category: 'closing'
    },
    {
      id: '28',
      title: 'Polite αποχώρηση: Ο χρήστης δεν ανταποκρίνεται (6)',
      content: 'Θα ήθελες να δούμε κάτι επιπλέον μαζί;',
      contentEN: 'Is there anything else I might help you with?',
      category: 'closing'
    },
    {
      id: '29',
      title: 'Κλείσιμο: Ο χρήστης δεν ανταποκρίνεται (2)',
      content: 'Κάπου εδώ θα ολοκληρώσω τη συνομιλία μας. Ελπίζω να σε βοήθησα! Κάτι τελευταίο, μετά τον τερματισμό της συνομιλίας μας, θα θέλαμε πολύ να μας πεις τη γνώμη σου για την εμπειρία που είχες μιλώντας με την ομάδα μας. Δε θα σου πάρει πάνω από 1 λεπτό! Για οτιδήποτε άλλο χρειαστείς, είμαι εδώ για σένα! Καλή συνέχεια!',
      contentEN: 'Αt this point I\'m going to end our chat. I am always here for anything else you may need. One last thing, after we\'ve ended our chat, we\'d love to tell us how was your experience contacting with our team. It won\'t take you more than 1 minute! Take care!💖',
      category: 'closing'
    },
    {
      id: '30',
      title: 'Κλείσιμο: Ο χρήστης δεν ανταποκρίνεται (3)',
      content: 'Θα χρειαστεί να τερματίσω το chat μας. Κάτι τελευταίο, μετά τον τερματισμό της συνομιλίας μας, θα θέλαμε πολύ να μας πεις τη γνώμη σου για την εμπειρία που είχες μιλώντας με την ομάδα μας. Δε θα σου πάρει πάνω από 1 λεπτό! Για ό,τι άλλο θες βρισκόμαστε εδώ για να σε βοηθήσουμε!',
      contentEN: 'I\'m going to have to end our chat. One last thing, after we\'ve ended our chat, we\'d love to tell us how was your experience contacting with our team. It won\'t take you more than 1 minute! We are always here to help you with anything else you may need💖',
      category: 'closing'
    }
  ],
  comments: [
    {
      id: '56',
      title: 'Ευχαριστούμε',
      subcategories: [
        {
          id: '57',
          title: 'Απαντήσεις σε ευχαριστίες',
          responses: [
            {
              id: '58',
              content: 'Χαίρομαι που μπόρεσα να σε βοηθήσω! Αν χρειαστείς κάτι άλλο είμαι στη διάθεσή σου!',
              contentEN: 'I\'m glad I could help! If you need anything else, I\'m at your disposal!'
            },
            {
              id: '59',
              content: 'Παρακαλώ! Μακάρι να μπορούσα να κάνω περισσότερα. Αν χρειαστείς οτιδήποτε άλλο μη διστάσεις να επικοινωνήσεις μαζί μας',
              contentEN: 'You\'re welcome! I wish I could do more. If you need anything else, don\'t hesitate to contact us'
            }
          ]
        }
      ]
    },
    {
      id: '60',
      title: 'Καλημέρα',
      subcategories: [
        {
          id: '61',
          title: 'Χαιρετισμός',
          responses: [
            {
              id: '62',
              content: 'Καλημέρα! Πώς μπορώ να σε βοηθήσω σήμερα;',
              contentEN: 'Good morning! How can I help you today?'
            }
          ]
        }
      ]
    },
    {
      id: '63',
      title: 'Ευγένεια',
      subcategories: [
        {
          id: '64',
          title: 'Τυπικές Εκφράσεις',
          responses: [
            {
              id: '65',
              content: 'Σε ευχαριστώ για την ευγένεια και την κατανόησή σου!',
              contentEN: 'Thank you for your kindness and understanding!'
            }
          ]
        }
      ]
    }
  ]
};

// Action types
type Action = 
  | { type: 'SET_DATA'; payload: ChatToolData }
  | { type: 'IMPORT_DATA'; payload: ChatToolData }
  | { type: 'ADD_RESPONSE'; payload: Response }
  | { type: 'UPDATE_RESPONSE'; payload: Response }
  | { type: 'DELETE_RESPONSE'; payload: { id: string; category: string } }
  | { type: 'UPDATE_RESPONSE_TITLE'; payload: { id: string; title: string; category: string } }
  | { type: 'ADD_CASE'; payload: Case }
  | { type: 'UPDATE_CASE'; payload: Case }
  | { type: 'DELETE_CASE'; payload: string }
  | { type: 'ADD_RESPONSE_TO_CASE'; payload: { caseId: string; response: { id: string; content: string; contentEN?: string } } }
  | { type: 'DELETE_RESPONSE_FROM_CASE'; payload: { caseId: string; responseId: string } }
  | { type: 'ADD_CATEGORY'; payload: Category }
  | { type: 'UPDATE_CATEGORY'; payload: Category }
  | { type: 'DELETE_CATEGORY'; payload: string }
  | { type: 'ADD_SUBCATEGORY'; payload: { categoryId: string; subcategory: { id: string; title: string; responses: any[] } } };

// Reducer function
const chatToolReducer = (state: ChatToolData, action: Action): ChatToolData => {
  switch (action.type) {
    case 'SET_DATA':
      return action.payload;
      
    case 'IMPORT_DATA':
      return action.payload;
      
    case 'ADD_RESPONSE':
      return {
        ...state,
        [action.payload.category]: [...state[action.payload.category as keyof ChatToolData] as Response[], action.payload]
      };
      
    case 'UPDATE_RESPONSE': {
      const category = action.payload.category;
      const updatedResponses = (state[category as keyof ChatToolData] as Response[]).map(
        response => response.id === action.payload.id ? action.payload : response
      );
      return {
        ...state,
        [category]: updatedResponses
      };
    }
      
    case 'DELETE_RESPONSE': {
      const { id, category } = action.payload;
      const updatedResponses = (state[category as keyof ChatToolData] as Response[]).filter(
        response => response.id !== id
      );
      return {
        ...state,
        [category]: updatedResponses
      };
    }
      
    case 'UPDATE_RESPONSE_TITLE': {
      const { id, title, category } = action.payload;
      const updatedResponses = (state[category as keyof ChatToolData] as Response[]).map(
        response => response.id === id ? { ...response, title } : response
      );
      return {
        ...state,
        [category]: updatedResponses
      };
    }
      
    case 'ADD_CASE':
      return {
        ...state,
        cases: [...state.cases, action.payload]
      };
      
    case 'UPDATE_CASE': {
      const updatedCases = state.cases.map(
        caseItem => caseItem.id === action.payload.id ? action.payload : caseItem
      );
      return {
        ...state,
        cases: updatedCases
      };
    }
      
    case 'DELETE_CASE': {
      const updatedCases = state.cases.filter(caseItem => caseItem.id !== action.payload);
      return {
        ...state,
        cases: updatedCases
      };
    }
      
    case 'ADD_RESPONSE_TO_CASE': {
      const { caseId, response } = action.payload;
      const updatedCases = state.cases.map(caseItem => {
        if (caseItem.id === caseId) {
          return {
            ...caseItem,
            responses: [...caseItem.responses, response]
          };
        }
        return caseItem;
      });
      return {
        ...state,
        cases: updatedCases
      };
    }
      
    case 'DELETE_RESPONSE_FROM_CASE': {
      const { caseId, responseId } = action.payload;
      const updatedCases = state.cases.map(caseItem => {
        if (caseItem.id === caseId) {
          return {
            ...caseItem,
            responses: caseItem.responses.filter(response => response.id !== responseId)
          };
        }
        return caseItem;
      });
      return {
        ...state,
        cases: updatedCases
      };
    }
      
    case 'ADD_CATEGORY':
      return {
        ...state,
        comments: [...state.comments, action.payload]
      };
      
    case 'UPDATE_CATEGORY': {
      const updatedCategories = state.comments.map(
        category => category.id === action.payload.id ? action.payload : category
      );
      return {
        ...state,
        comments: updatedCategories
      };
    }
      
    case 'DELETE_CATEGORY': {
      const updatedCategories = state.comments.filter(category => category.id !== action.payload);
      return {
        ...state,
        comments: updatedCategories
      };
    }
      
    case 'ADD_SUBCATEGORY': {
      const { categoryId, subcategory } = action.payload;
      const updatedCategories = state.comments.map(category => {
        if (category.id === categoryId) {
          return {
            ...category,
            subcategories: [...(category.subcategories || []), subcategory]
          };
        }
        return category;
      });
      return {
        ...state,
        comments: updatedCategories
      };
    }
      
    default:
      return state;
  }
};

// Create context
interface ChatToolContextProps {
  state: ChatToolData;
  addResponse: (response: Response) => void;
  updateResponse: (response: Response) => void;
  deleteResponse: (id: string, category: string) => void;
  updateResponseTitle: (id: string, title: string, category: string) => void;
  addCase: (caseItem: Case) => void;
  updateCase: (caseItem: Case) => void;
  deleteCase: (id: string) => void;
  addResponseToCase: (caseId: string, response: { id: string; content: string; contentEN?: string }) => void;
  deleteResponseFromCase: (caseId: string, responseId: string) => void;
  addCategory: (category: Category) => void;
  updateCategory: (category: Category) => void;
  deleteCategory: (id: string) => void;
  addSubcategory: (categoryId: string, subcategory: { id: string; title: string; responses: any[] }) => void;
  exportData: () => void;
  importData: (fileData: ChatToolData) => boolean;
}

const ChatToolContext = createContext<ChatToolContextProps | undefined>(undefined);

// Provider component
interface ChatToolProviderProps {
  children: ReactNode;
}

export const ChatToolProvider = ({ children }: ChatToolProviderProps) => {
  const [storedData, setStoredData] = useLocalStorage<ChatToolData>('chatToolData', defaultData);
  const [state, dispatch] = useReducer(chatToolReducer, storedData);

  // Initialize data from Electron filesystem or localStorage
  useEffect(() => {
    const initializeData = async () => {
      // Check if running in Electron
      if (isElectron()) {
        console.log('Running in Electron environment, loading data from file system...');
        try {
          // Try to load data from Electron filesystem
          const fileData = await loadDataFromFileSystem();
          if (fileData) {
            console.log('Data loaded from Electron filesystem');
            dispatch({ type: 'SET_DATA', payload: fileData });
          } else {
            console.log('No data found in Electron filesystem, initializing with default data');
            dispatch({ type: 'SET_DATA', payload: defaultData });
          }
        } catch (error) {
          console.error('Error loading data from Electron filesystem:', error);
          // Fall back to default data if file loading fails
          dispatch({ type: 'SET_DATA', payload: defaultData });
        }
      } else {
        // Browser environment - use localStorage
        console.log('Running in browser environment, using localStorage');
        console.log('Current stored data:', storedData);
        console.log('Current state:', state);
        
        // Only set default data if we're starting fresh (storage is empty)
        const isDataEmpty = Object.keys(storedData).length === 0 ||
                          !storedData.greeting || 
                          !storedData.waiting || 
                          !storedData.cases || 
                          !storedData.closing || 
                          !storedData.comments;

        if (isDataEmpty) {
          dispatch({ type: 'SET_DATA', payload: defaultData });
          console.log('Initialized with default data');
        }
      }
    };

    initializeData();
  }, []);

  // Sync reducer state with storage (filesystem for Electron, localStorage for browser)
  useEffect(() => {
    const saveData = async () => {
      if (isElectron()) {
        // Save to Electron filesystem
        console.log('Saving data to Electron filesystem...');
        await saveDataToFileSystem(state);
      } else {
        // Save to browser localStorage
        console.log('Saving data to localStorage...');
        setStoredData(state);
      }
      console.log('Updated stored data', state);
    };

    // Skip initial save when the app is just starting
    if (Object.keys(state).length > 0) {
      saveData();
    }
  }, [state, setStoredData]);

  // Action creators
  const addResponse = (response: Response) => {
    dispatch({ type: 'ADD_RESPONSE', payload: response });
  };

  const updateResponse = (response: Response) => {
    dispatch({ type: 'UPDATE_RESPONSE', payload: response });
  };

  const deleteResponse = (id: string, category: string) => {
    dispatch({ type: 'DELETE_RESPONSE', payload: { id, category } });
  };

  const updateResponseTitle = (id: string, title: string, category: string) => {
    dispatch({ type: 'UPDATE_RESPONSE_TITLE', payload: { id, title, category } });
  };

  const addCase = (caseItem: Case) => {
    dispatch({ type: 'ADD_CASE', payload: caseItem });
  };

  const updateCase = (caseItem: Case) => {
    dispatch({ type: 'UPDATE_CASE', payload: caseItem });
  };

  const deleteCase = (id: string) => {
    dispatch({ type: 'DELETE_CASE', payload: id });
  };

  const addResponseToCase = (caseId: string, response: { id: string; content: string; contentEN?: string }) => {
    dispatch({ type: 'ADD_RESPONSE_TO_CASE', payload: { caseId, response } });
  };

  const deleteResponseFromCase = (caseId: string, responseId: string) => {
    dispatch({ type: 'DELETE_RESPONSE_FROM_CASE', payload: { caseId, responseId } });
  };

  const addCategory = (category: Category) => {
    dispatch({ type: 'ADD_CATEGORY', payload: category });
  };

  const updateCategory = (category: Category) => {
    dispatch({ type: 'UPDATE_CATEGORY', payload: category });
  };

  const deleteCategory = (id: string) => {
    dispatch({ type: 'DELETE_CATEGORY', payload: id });
  };

  const addSubcategory = (categoryId: string, subcategory: { id: string; title: string; responses: any[] }) => {
    dispatch({ type: 'ADD_SUBCATEGORY', payload: { categoryId, subcategory } });
  };

  // Export functionality
  const exportData = () => {
    try {
      console.log("Exporting data:", state);
      
      // Create a clean copy of the state to export
      const dataToExport = {
        greeting: state.greeting || [],
        waiting: state.waiting || [],
        cases: state.cases || [],
        closing: state.closing || [],
        comments: state.comments || []
      };
      
      console.log("Data prepared for export:", dataToExport);
      
      // In Electron, the data is already saved to the filesystem automatically
      // so we'll just show a notification or message
      if (isElectron()) {
        console.log("In Electron environment, data is already saved to file system");
        // You could add a notification here if needed
        alert("Data is automatically saved to file system in this desktop application.");
        
        // Optionally, force a save to ensure latest data is persisted
        saveDataToFileSystem(dataToExport);
      } else {
        // Browser environment - download as file
        const jsonString = JSON.stringify(dataToExport, null, 2);
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(jsonString);
        
        const downloadAnchorNode = document.createElement('a');
        downloadAnchorNode.setAttribute("href", dataStr);
        downloadAnchorNode.setAttribute("download", "chat_responses.json");
        document.body.appendChild(downloadAnchorNode);
        downloadAnchorNode.click();
        downloadAnchorNode.remove();
      }
      
      console.log("Export completed successfully");
    } catch (error) {
      console.error("Error during export:", error);
    }
  };
  
  // Import functionality
  const importData = (fileData: ChatToolData) => {
    try {
      console.log("Attempting to import data:", fileData);
      
      // Validate the structure of fileData
      if (!fileData || typeof fileData !== 'object') {
        console.error('Invalid data format: Not an object');
        return false;
      }
      
      // Make sure all required properties exist and are arrays
      const requiredProperties = ['greeting', 'waiting', 'cases', 'closing', 'comments'];
      for (const prop of requiredProperties) {
        if (!fileData[prop as keyof ChatToolData]) {
          console.error(`Missing required property: ${prop}`);
          return false;
        }
        
        if (!Array.isArray(fileData[prop as keyof ChatToolData])) {
          console.error(`Property ${prop} is not an array`);
          return false;
        }
      }
      
      // Create a clean copy of the data to import
      const cleanData: ChatToolData = {
        greeting: [...fileData.greeting],
        waiting: [...fileData.waiting],
        cases: [...fileData.cases],
        closing: [...fileData.closing],
        comments: [...fileData.comments]
      };
      
      console.log("Clean data prepared for import:", cleanData);
      
      // Dispatch the import action
      dispatch({ type: 'IMPORT_DATA', payload: cleanData });
      
      console.log("Import dispatched successfully");
      
      // Force a state update by setting data again
      setTimeout(() => {
        console.log("Forcing state refresh after import");
        dispatch({ type: 'SET_DATA', payload: cleanData });
      }, 100);
      
      return true;
    } catch (error) {
      console.error('Failed to import data:', error);
      return false;
    }
  };

  return (
    <ChatToolContext.Provider value={{
      state,
      addResponse,
      updateResponse,
      deleteResponse,
      updateResponseTitle,
      addCase,
      updateCase,
      deleteCase,
      addResponseToCase,
      deleteResponseFromCase,
      addCategory,
      updateCategory,
      deleteCategory,
      addSubcategory,
      exportData,
      importData
    }}>
      {children}
    </ChatToolContext.Provider>
  );
};

// Custom hook to use the context
export const useChatTool = () => {
  const context = useContext(ChatToolContext);
  if (context === undefined) {
    throw new Error('useChatTool must be used within a ChatToolProvider');
  }
  return context;
};
