#!/bin/bash

# Δημιουργία του frontend build
echo "Building frontend..."
npm run build

# Εκτέλεση του electron-builder για δημιουργία εκτελέσιμου
echo "Building Electron app..."
npx electron-builder --config electron-builder.config.js

echo "Build completed! Check the 'release' folder for your executable."