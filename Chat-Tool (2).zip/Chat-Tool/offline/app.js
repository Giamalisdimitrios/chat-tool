document.addEventListener('DOMContentLoaded', function() {
  // Default data
  const defaultData = {
    greeting: [
      {
        id: "1",
        title: "Γνωρίζω το αίτημα",
        content: "Γεια σου! 👋Ευχαριστούμε που επικοινώνησες με την ομάδα μας. Κοιτάμε ήδη το θέμα που αντιμετωπίζεις και θα επικοινωνήσουμε μαζί σου το συντομότερο 😀",
        contentEN: "Hey you! 👋 Thanks for contacting our customer care team. We are looking into your issue and we will get back to you shortly 😀"
      },
      {
        id: "2",
        title: "Καλησπέρα! - Γνωρίζω το αίτημα",
        content: "Καλησπέρα!",
        contentEN: "Good evening!"
      },
      {
        id: "3",
        title: "Δε γνωρίζω το αίτημα",
        content: "Γεια σου! 👋 Ευχαριστούμε που επικοινώνησες μαζί μας! Παρακαλώ ενημέρωσέ μας για το θέμα που αντιμετωπίζεις και θα σε βοηθήσω όσο πιο άμεσα γίνεται 😀",
        contentEN: "Hey you! 👋 Thanks for contacting our customer care team. Please let me know about the issue you are facing and I will help you as soon as possible 😀"
      },
      {
        id: "4",
        title: "Πως μπορώ να βοηθήσω; μ.μ.",
        content: "Καλησπέρα! Πώς μπορώ να βοηθήσω;",
        contentEN: "Good evening! How may I help you?"
      },
      {
        id: "5",
        title: "Σε ευχαριστώ για το μήνυμά σου - μισό λεπτό",
        content: "Σ' ευχαριστούμε για το μήνυμά σου! Θα χρειαστώ λίγο χρόνο να ελέγξω τι ακριβώς συμβαίνει και σε ενημερώνω άμεσα!",
        contentEN: "Thank you for your message! Please give me a minute to check all the details and I will get back to you shortly"
      }
    ],
    waiting: [
      {
        id: "1",
        title: "Λίγη υπομονή",
        content: "Σε παρακαλώ δώσε μου λίγο χρόνο να το κοιτάξω.",
        contentEN: "Please give me some time to check it."
      },
      {
        id: "2",
        title: "Ευχαριστώ για την υπομονή",
        content: "Ευχαριστώ για την υπομονή σου. Χρειάζομαι λίγο ακόμα χρόνο.",
        contentEN: "Thank you for your patience. I still need a bit more time."
      }
    ],
    cases: [
      {
        id: "case-1",
        title: "Ακύρωση από το κατάστημα - MP & OD",
        responses: [
          {
            id: "case-resp-1",
            title: "Ζητάμε αιτία ακύρωσης",
            content: "Ζητάμε πολύ ευγενικά την αιτία ακύρωσης προκειμένου να ενημερώσουμε τον χρήστη.",
            contentEN: "We politely ask for the cancellation reason in order to inform the user."
          },
          {
            id: "case-resp-2",
            title: "Παραγγελία με μετρητά - Έχει επικοινωνήσει",
            content: "Ακυρώνουμε την παραγγελία (δεν επικοινωνούμε με τον χρήστη για ακύρωση εφόσον έχει ήδη μιλήσει με το κατάστημα).",
            contentEN: "We cancel the order (we don't contact the user for cancellation since they already spoke with the store)."
          },
          {
            id: "case-resp-3",
            title: "Παραγγελία με κάρτα - Adyen - Έχει επικοινωνήσει",
            content: "Ακυρώνουμε την παραγγελία (δεν επικοινωνούμε τον χρήστη για διαδικασία αποδέσμευσης καθώς λαμβάνει αυτόματα sms & email για την ακύρωση και αποδέσμευση).",
            contentEN: "We cancel the order (we don't contact the user for the release process as they automatically receive SMS & email for cancellation and release)."
          },
          {
            id: "case-resp-4",
            title: "Παραγγελία με κάρτα - Braintree/Πειραιώς - Έχει επικοινωνήσει",
            content: "Ακυρώνουμε την παραγγελία και στέλνουμε sms στον χρήστη να τον ενημερώσουμε για ακύρωση και διαδικασία αποδέσμευσης.",
            contentEN: "We cancel the order and send SMS to the user to inform them about cancellation and release process."
          }
        ]
      },
      {
        id: "case-2",
        title: "Δε βρέθηκε ο χρήστης",
        responses: [
          {
            id: "case-resp-5",
            title: "Ρωτάμε για διανομέα",
            content: "Ρωτάμε αν ο διανομέας είναι ακόμη στη δ/νση του χρήστη & αν μπορεί να περιμένει λίγα λεπτά ακόμα.",
            contentEN: "We ask if the delivery person is still at the user's address & if they can wait a few more minutes."
          },
          {
            id: "case-resp-6",
            title: "Διανομέας στη διεύθυνση",
            content: "Ενημερώνουμε ότι θα δοκιμάσουμε και εμείς να επικοινωνήσουμε με τον χρήστη και ότι εάν δεν τον βρούμε, θα του στείλουμε SMS.",
            contentEN: "We inform that we will also try to contact the user and if we don't find them, we will send SMS."
          },
          {
            id: "case-resp-7",
            title: "Διαδικασία κλήσεων",
            content: "Καλούμε δύο φορές στο εναλλακτικό τηλέφωνο. Αν δεν απαντήσει, καλούμε 2 φορές στο κινητό τηλέφωνο του λογαριασμού. Αν δεν απαντήσει, στέλνουμε SMS.",
            contentEN: "We call twice on the alternative phone. If no answer, we call twice on the account mobile. If no answer, we send SMS."
          }
        ]
      },
      {
        id: "case-3",
        title: "Έλλειψη",
        responses: [
          {
            id: "case-resp-8",
            title: "Διαδικασία ελέγχου",
            content: "Ανοίγουμε την παραγγελία και τον κατάλογο του καταστήματος. Ρωτάμε ποιο προϊόν είναι σε έλλειψη και αν υπάρχει αντικατάσταση.",
            contentEN: "We open the order and store catalog. We ask which product is out of stock and if there's a replacement."
          },
          {
            id: "case-resp-9",
            title: "Αντικατάσταση ίσης αξίας",
            content: "Ενημερώνουμε τον χρήστη ότι η συνολική αξία της παραγγελίας παραμένει ίδια. Ενημερώνουμε το κατάστημα. Αφήνουμε σχόλιο στο OneView.",
            contentEN: "We inform the user that the total order value remains the same. We inform the store. We leave a comment in OneView."
          }
        ]
      },
      {
        id: "case-4",
        title: "Ζυγίσιμα Προϊόντα",
        responses: [
          {
            id: "case-resp-10",
            title: "Παραγγελία με μετρητά - Βήμα 1",
            content: "Ενημερώνουμε το κατάστημα ότι θα το μεταφέρουμε στον χρήστη για την αλλαγή και θα τους καλέσουμε πίσω να τους ενημερώσουμε σχετικά.",
            contentEN: "We inform the store that we will transfer it to the user for the change and will call them back to inform them."
          },
          {
            id: "case-resp-11",
            title: "Παραγγελία με μετρητά - Βήμα 2",
            content: "Ενημερώνουμε τον χρήστη για τη διαφορά που προκύπτει προκειμένου να πάρουμε το οκ και από τον ίδιο για την αλλαγή τιμής.",
            contentEN: "We inform the user about the difference that arises in order to get approval from them for the price change."
          },
          {
            id: "case-resp-12",
            title: "Παραγγελία με μετρητά - Βήμα 3",
            content: "Ενημερώνουμε το κατάστημα ότι μπορούμε να προχωρήσουμε σε αλλαγή τιμής κατόπιν συνεννόησης με τον χρήστη. Αλλάζουμε το ποσό στην παραγγελία στο backend. Αφήνουμε σχόλιο στο OneView.",
            contentEN: "We inform the store that we can proceed with price change after agreement with the user. We change the amount in the order in the backend. We leave a comment in OneView."
          },
          {
            id: "case-resp-13",
            title: "Παραγγελία με κάρτα - Ερώτηση για μετρητά",
            content: "Ενημερώνουμε τον χρήστη ότι προκύπτει μια χ διαφορά στην τιμή και ρωτάμε αν διαθέτει μετρητά για να καλύψει τη διαφορά στον διανομέα κατά την παράδοση.",
            contentEN: "We inform the user that there is a difference in price and ask if they have cash to cover the difference to the delivery person upon delivery."
          },
          {
            id: "case-resp-14",
            title: "Ο χρήστης έχει μετρητά",
            content: "Ενημερώνουμε για το νέο σύνολο και ότι η διαφορά είναι χ ευρώ. Ενημερώνουμε το κατάστημα για τη διαφορά και ότι ο χρήστης θα καλύψει τη διαφορά με μετρητά στον διανομέα. Αλλάζουμε το ποσό στην παραγγελία. Αφήνουμε σχόλιο στο OneView αναφέροντας ότι θα δοθεί η διαφορά στον διανομέα με μετρητά.",
            contentEN: "We inform about the new total and that the difference is x euros. We inform the store about the difference and that the user will cover it with cash to the delivery person. We change the order amount. We leave a comment in OneView stating that the difference will be given to the delivery person in cash."
          },
          {
            id: "case-resp-15",
            title: "Ο χρήστης δεν έχει μετρητά",
            content: "Ενημερώνουμε τον χρήστη ότι θα καλύψουμε εμείς τη διαφορά μέχρι 1 ευρώ. Αν η διαφορά είναι >1€ ενημερώνουμε Team Leader και αναμένουμε οδηγίες. Ενημερώνουμε το κατάστημα ότι θα καλύψουμε εμείς τη διαφορά. Αλλάζουμε το ποσό στην παραγγελία. Αφήνουμε σχόλιο στο OneView αναφέροντας ότι καλύπτουμε εμείς τη διαφορά.",
            contentEN: "We inform the user that we will cover the difference up to 1 euro. If the difference is >1€ we inform Team Leader and await instructions. We inform the store that we will cover the difference. We change the order amount. We leave a comment in OneView stating that we cover the difference."
          }
        ]
      },
      {
        id: "case-5",
        title: "Το κατ/μα επιθυμεί να προσφέρει ολόκληρη ή μέρος της παραγγελίας",
        responses: [
          {
            id: "case-resp-16",
            title: "Ολόκληρη παραγγελία - Μετρητά",
            content: "Ενημερώνουμε τον χρήστη ότι το κατάστημα θα ήθελε να του στείλει την παραγγελία, χωρίς καμία δική του επιβάρυνση. Στέλνουμε ASANA - Λογιστήριο.",
            contentEN: "We inform the user that the store would like to send them the order without any charge. We send ASANA - Accounting."
          },
          {
            id: "case-resp-17",
            title: "Ολόκληρη παραγγελία - Κάρτα",
            content: "Ενημερώνουμε τον χρήστη ότι το κατάστημα θα στείλει την παραγγελία χωρίς επιβάρυνση και η αποδέσμευση θα γίνει σε 5 εργάσιμες. Στέλνουμε ASANA - e-payments.",
            contentEN: "We inform the user that the store will send the order without charge and the release will be done in 5 business days. We send ASANA - e-payments."
          }
        ]
      },
      {
        id: "case-6",
        title: "Μεταφορά παραγγελίας σε άλλο κατάστημα",
        responses: []
      },
      {
        id: "case-7",
        title: "Ξεχάστηκε προϊόν",
        responses: []
      },
      {
        id: "case-8",
        title: "Ο χρήστης δεν πλήρωσε",
        responses: []
      },
      {
        id: "case-9",
        title: "Περιβαλλοντικό τέλος & τέλος ανακύκλωσης PVC",
        responses: []
      },
      {
        id: "case-10",
        title: "Προϊόντα χωρίς προμήθεια",
        responses: []
      },
      {
        id: "case-11",
        title: "Δεν εξυπηρετείται η διεύθυνση της παραγγελίας από το κατάστημα",
        responses: []
      },
      {
        id: "case-12",
        title: "Customer Cancellation",
        responses: []
      },
      {
        id: "case-13",
        title: "Order Cancellation Inquiry",
        responses: []
      }
    ],
    closing: [
      {
        id: "1",
        title: "Κάτι άλλο;",
        content: "Υπάρχει κάτι άλλο που θα ήθελες να σε βοηθήσω;",
        contentEN: "Is there anything else I could help you with?"
      },
      {
        id: "2",
        title: "Στη διάθεσή σου",
        content: "Είμαι στη διάθεσή σου για οποιαδήποτε άλλη ερώτηση.",
        contentEN: "I am at your disposal for any other questions."
      },
      {
        id: "3",
        title: "Ευχαριστώ",
        content: "Σε ευχαριστώ για την επικοινωνία. Καλή συνέχεια!",
        contentEN: "Thank you for contacting us. Have a nice day!"
      }
    ],
    activeTabs: ["greeting", "waiting", "cases", "closing", "settings"],
    tabsInfo: {
      greeting: { name: "Άνοιγμα", icon: "💬" },
      waiting: { name: "Αναμονή", icon: "⏳" },
      cases: { name: "Cases", icon: "📁" },
      closing: { name: "Κλείσιμο", icon: "✅" },
      settings: { name: "Ρυθμίσεις", icon: "⚙️" }
    }
  };

  // Application state
  const appState = {
    currentData: loadData() || defaultData,
    activeTab: 'greeting',
    editMode: false,
    showLineButtons: false,
    editingItem: null
  };

  // Initialize
  function init() {
    updateUI();
    attachEventListeners();
  }

  // Load data from localStorage
  function loadData() {
    try {
      const savedData = localStorage.getItem('chatToolData');
      if (savedData) {
        return JSON.parse(savedData);
      }
    } catch (error) {
      console.error('Error loading data:', error);
    }
    return null;
  }

  // Save data to localStorage
  function saveData() {
    try {
      localStorage.setItem('chatToolData', JSON.stringify(appState.currentData));
      showNotification('Data saved successfully!');
    } catch (error) {
      console.error('Error saving data:', error);
      alert('Failed to save data. Local storage might be disabled.');
    }
  }

  // Update UI based on current state
  function updateUI() {
    updateTabUI();
    renderContent();
  }

  // Update tab buttons UI
  function updateTabUI() {
    const tabButtons = document.querySelectorAll('.tab-button');
    tabButtons.forEach(btn => {
      if (btn.dataset.tab === appState.activeTab) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
  }

  // Render content based on active tab
  function renderContent() {
    const contentElement = document.getElementById('categoryContent');
    contentElement.innerHTML = '';

    // Update action buttons visibility
    document.querySelector('.action-buttons').style.display = 
      appState.activeTab === 'settings' ? 'none' : 'flex';

    // Toggle edit mode class
    if (appState.editMode) {
      contentElement.classList.add('edit-mode');
    } else {
      contentElement.classList.remove('edit-mode');
    }

    // Render based on active tab
    switch (appState.activeTab) {
      case 'settings':
        renderSettingsTab(contentElement);
        break;
      case 'cases':
        renderCasesTab(contentElement);
        break;
      default:
        renderResponsesTab(contentElement);
        break;
    }
  }

  // Render settings tab
  function renderSettingsTab(container) {
    const settingsContainer = document.createElement('div');
    settingsContainer.className = 'tabs-manager';

    // Header
    const header = document.createElement('div');
    header.className = 'tabs-manager-header';
    header.innerHTML = '<h2>Ρυθμίσεις</h2>';

    // Tabs section
    const tabsSection = document.createElement('div');
    tabsSection.className = 'tabs-section';

    const sectionTitle = document.createElement('h3');
    sectionTitle.className = 'section-title';
    sectionTitle.textContent = 'Διαχείριση Καρτελών';

    const tabList = document.createElement('div');
    tabList.className = 'tab-list';

    // Create tab items
    const tabs = appState.currentData.activeTabs || [];
    const tabsInfo = appState.currentData.tabsInfo || {};

    tabs.forEach(tab => {
      if (tab === 'settings') return; // Skip settings tab

      const tabInfo = tabsInfo[tab] || { name: tab, icon: '📄' };
      
      const tabItem = document.createElement('div');
      tabItem.className = 'tab-list-item';
      
      const tabInfoDiv = document.createElement('div');
      tabInfoDiv.className = 'tab-info';
      tabInfoDiv.innerHTML = `
        <span>${tabInfo.icon}</span>
        <span>${tabInfo.name}</span>
      `;
      
      tabItem.appendChild(tabInfoDiv);
      tabList.appendChild(tabItem);
    });

    tabsSection.appendChild(sectionTitle);
    tabsSection.appendChild(tabList);

    // Data actions
    const dataActions = document.createElement('div');
    dataActions.className = 'data-actions';

    const exportBtn = document.createElement('button');
    exportBtn.className = 'btn btn-secondary';
    exportBtn.innerHTML = '📤 Export Data';
    exportBtn.addEventListener('click', exportData);

    const importBtn = document.createElement('button');
    importBtn.className = 'btn btn-secondary';
    importBtn.innerHTML = '📥 Import Data';
    importBtn.addEventListener('click', openImportModal);

    dataActions.appendChild(exportBtn);
    dataActions.appendChild(importBtn);

    // Assemble the settings container
    settingsContainer.appendChild(header);
    settingsContainer.appendChild(tabsSection);
    settingsContainer.appendChild(dataActions);

    container.appendChild(settingsContainer);
  }

  // Render cases tab
  function renderCasesTab(container) {
    const casesGrid = document.createElement('div');
    casesGrid.className = 'cases-grid';

    const cases = appState.currentData.cases || [];

    cases.forEach(caseItem => {
      const caseElement = createCaseElement(caseItem);
      casesGrid.appendChild(caseElement);
    });

    container.appendChild(casesGrid);
  }

  // Create case element
  function createCaseElement(caseItem) {
    const element = document.createElement('div');
    element.className = 'case-item';
    element.dataset.id = caseItem.id;

    const header = document.createElement('div');
    header.className = 'case-header';

    const title = document.createElement('div');
    title.className = 'case-title';
    title.textContent = caseItem.title;

    const actions = document.createElement('div');
    actions.className = 'response-actions';

    // Edit button
    const editBtn = document.createElement('button');
    editBtn.className = 'action-icon';
    editBtn.innerHTML = '✏️';
    editBtn.title = 'Edit';
    editBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      editItem(caseItem);
    });

    // Delete button
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'action-icon';
    deleteBtn.innerHTML = '🗑️';
    deleteBtn.title = 'Delete';
    deleteBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      deleteItem(caseItem.id, 'cases');
    });

    actions.appendChild(editBtn);
    actions.appendChild(deleteBtn);

    header.appendChild(title);
    header.appendChild(actions);

    const meta = document.createElement('div');
    meta.className = 'case-meta';
    const responseCount = (caseItem.responses || []).length;
    meta.textContent = `${responseCount} ${responseCount === 1 ? 'response' : 'responses'}`;

    element.appendChild(header);
    element.appendChild(meta);

    element.addEventListener('click', () => {
      viewCaseDetail(caseItem);
    });

    return element;
  }

  // View case detail
  function viewCaseDetail(caseItem) {
    const responsesList = (caseItem.responses || [])
      .map(r => `• ${r.title}: ${r.content}`)
      .join('\n');

    alert(`Case: ${caseItem.title}\n\nResponses:\n${responsesList}`);
  }

  // Render responses tab (greeting, waiting, closing)
  function renderResponsesTab(container) {
    const responses = appState.currentData[appState.activeTab] || [];

    responses.forEach(item => {
      if (item.type === 'line') {
        const lineElement = createLineElement(item);
        container.appendChild(lineElement);
      } else {
        const responseElement = createResponseElement(item);
        container.appendChild(responseElement);
      }

      // Add line button if in add line mode
      if (appState.showLineButtons && item.type !== 'line') {
        const addLineButton = createAddLineButton(item.id);
        container.appendChild(addLineButton);
      }
    });
  }

  // Create response element
  function createResponseElement(item) {
    const element = document.createElement('div');
    element.className = 'response-item';
    element.dataset.id = item.id;

    const header = document.createElement('div');
    header.className = 'response-header';

    const title = document.createElement('div');
    title.className = 'response-title';
    title.textContent = item.title;

    // Add EN badge if English content exists
    if (item.contentEN) {
      const badge = document.createElement('span');
      badge.className = 'response-badge';
      badge.textContent = 'EN';
      title.appendChild(badge);
    }

    const actions = document.createElement('div');
    actions.className = 'response-actions';

    // Copy button
    const copyBtn = document.createElement('button');
    copyBtn.className = 'action-icon';
    copyBtn.innerHTML = '📋';
    copyBtn.title = 'Copy';
    copyBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      copyContent(item);
    });

    // Edit button
    const editBtn = document.createElement('button');
    editBtn.className = 'action-icon';
    editBtn.innerHTML = '✏️';
    editBtn.title = 'Edit';
    editBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      editItem(item);
    });

    // Delete button
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'action-icon';
    deleteBtn.innerHTML = '🗑️';
    deleteBtn.title = 'Delete';
    deleteBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      deleteItem(item.id, appState.activeTab);
    });

    actions.appendChild(copyBtn);
    actions.appendChild(editBtn);
    actions.appendChild(deleteBtn);

    header.appendChild(title);
    header.appendChild(actions);

    const content = document.createElement('div');
    content.className = 'response-content';
    content.textContent = formatTimeBasedGreeting(item.content);

    // Copy on click
    content.addEventListener('click', () => {
      copyContent(item);
    });

    // Copy English on double click
    if (item.contentEN) {
      content.addEventListener('dblclick', (e) => {
        e.stopPropagation();
        copyToClipboard(formatTimeBasedGreeting(item.contentEN));
        showNotification('English text copied to clipboard!');
      });
    }

    element.appendChild(header);
    element.appendChild(content);

    return element;
  }

  // Create line element
  function createLineElement(item) {
    const container = document.createElement('div');
    container.className = 'line-item-container';
    container.dataset.id = item.id;

    const line = document.createElement('div');
    line.className = 'line-item';

    const actions = document.createElement('div');
    actions.className = 'line-actions';

    // Delete button
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'action-icon';
    deleteBtn.innerHTML = '🗑️';
    deleteBtn.addEventListener('click', () => {
      deleteItem(item.id, appState.activeTab);
    });

    actions.appendChild(deleteBtn);
    container.appendChild(line);
    container.appendChild(actions);

    return container;
  }

  // Create add line button
  function createAddLineButton(afterId) {
    const button = document.createElement('button');
    button.className = 'btn btn-secondary';
    button.style.width = '100%';
    button.style.marginBottom = '8px';
    button.style.opacity = '0.7';
    button.innerHTML = '➕ Add Line Here';
    button.dataset.afterId = afterId;

    button.addEventListener('click', () => {
      addLine(afterId);
    });

    return button;
  }

  // Format time-based greeting
  function formatTimeBasedGreeting(text) {
    const currentHour = new Date().getHours();
    let greeting = 'Καλημέρα';
    
    if (currentHour >= 12 && currentHour < 17) {
      greeting = 'Καλησπέρα';
    } else if (currentHour >= 17) {
      greeting = 'Καλησπέρα';
    }
    
    const englishGreeting = currentHour < 12 ? 'Good Morning' : 'Good Evening';
    
    return text
      .replace('Καλημέρα/Καλησπέρα', greeting)
      .replace('Good Morning/Good Evening', englishGreeting);
  }

  // Copy content to clipboard with time-based formatting
  function copyContent(item) {
    const formattedContent = formatTimeBasedGreeting(item.content);
    copyToClipboard(formattedContent);
    showNotification('Text copied to clipboard!');
  }

  // Copy text to clipboard
  function copyToClipboard(text) {
    if (!text) return;
    
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text)
        .then(() => {
          console.log('Copied to clipboard');
        })
        .catch(err => {
          console.error('Failed to copy: ', err);
          fallbackCopy(text);
        });
    } else {
      fallbackCopy(text);
    }
  }

  // Fallback method for copying text
  function fallbackCopy(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();
    
    try {
      document.execCommand('copy');
    } catch (err) {
      console.error('Fallback copy failed:', err);
      alert('Could not copy text. Please copy manually: ' + text);
    }
    
    document.body.removeChild(textarea);
  }

  // Show notification
  function showNotification(message) {
    const notification = document.getElementById('notification');
    notification.textContent = message;
    notification.classList.add('show');
    
    setTimeout(() => {
      notification.classList.remove('show');
    }, 3000);
  }

  // Add a new item
  function addNewItem() {
    if (appState.activeTab === 'cases') {
      const title = prompt('Enter case title:');
      if (!title) return;
      
      const newCase = {
        id: 'case-' + Date.now(),
        title: title,
        responses: []
      };
      
      appState.currentData.cases = appState.currentData.cases || [];
      appState.currentData.cases.push(newCase);
      saveData();
      updateUI();
      return;
    }
    
    const newItem = {
      id: Date.now().toString(),
      title: prompt('Enter title:') || 'New Item',
      content: prompt('Enter Greek content:') || '',
      contentEN: prompt('Enter English content (optional):') || ''
    };
    
    if (!newItem.content) return;
    
    appState.currentData[appState.activeTab] = appState.currentData[appState.activeTab] || [];
    appState.currentData[appState.activeTab].push(newItem);
    saveData();
    updateUI();
  }

  // Edit an item
  function editItem(item) {
    appState.editingItem = item;
    
    // Show edit modal
    const modal = document.getElementById('editModal');
    
    // Set form values
    document.getElementById('edit-title').value = item.title || '';
    document.getElementById('edit-content').value = item.content || '';
    document.getElementById('edit-content-en').value = item.contentEN || '';
    
    // Show modal
    modal.classList.add('show');
  }

  // Save edited item
  function saveEditedItem() {
    const editingItem = appState.editingItem;
    if (!editingItem) return;
    
    const newTitle = document.getElementById('edit-title').value;
    const newContent = document.getElementById('edit-content').value;
    const newContentEN = document.getElementById('edit-content-en').value;
    
    if (!newContent) {
      alert('Content cannot be empty');
      return;
    }
    
    if (appState.activeTab === 'cases') {
      const cases = appState.currentData.cases || [];
      const caseIndex = cases.findIndex(c => c.id === editingItem.id);
      
      if (caseIndex !== -1) {
        cases[caseIndex].title = newTitle;
        saveData();
        updateUI();
      }
    } else {
      const items = appState.currentData[appState.activeTab] || [];
      const itemIndex = items.findIndex(i => i.id === editingItem.id);
      
      if (itemIndex !== -1) {
        items[itemIndex].title = newTitle;
        items[itemIndex].content = newContent;
        items[itemIndex].contentEN = newContentEN || undefined;
        saveData();
        updateUI();
      }
    }
    
    // Close modal and reset state
    closeModal('editModal');
    appState.editingItem = null;
  }

  // Delete an item
  function deleteItem(id, category) {
    if (!confirm('Are you sure you want to delete this item?')) return;
    
    if (category === 'cases') {
      appState.currentData.cases = (appState.currentData.cases || []).filter(c => c.id !== id);
    } else {
      appState.currentData[category] = (appState.currentData[category] || []).filter(item => item.id !== id);
    }
    
    saveData();
    updateUI();
  }

  // Add a line
  function addLine(afterId) {
    const items = appState.currentData[appState.activeTab] || [];
    const index = items.findIndex(item => item.id === afterId);
    
    if (index === -1) return;
    
    const lineItem = {
      id: 'line-' + Date.now(),
      type: 'line'
    };
    
    items.splice(index + 1, 0, lineItem);
    saveData();
    updateUI();
  }

  // Toggle edit mode
  function toggleEditMode() {
    appState.editMode = !appState.editMode;
    
    // Update button text
    const editBtn = document.getElementById('editModeBtn');
    if (appState.editMode) {
      editBtn.innerHTML = '💾 Save';
      editBtn.classList.add('btn-primary');
      editBtn.classList.remove('btn-secondary');
    } else {
      editBtn.innerHTML = '✏️ Edit';
      editBtn.classList.remove('btn-primary');
      editBtn.classList.add('btn-secondary');
    }
    
    updateUI();
  }

  // Toggle add line mode
  function toggleAddLineMode() {
    appState.showLineButtons = !appState.showLineButtons;
    
    // Update button text
    const lineBtn = document.getElementById('addLineBtn');
    if (appState.showLineButtons) {
      lineBtn.innerHTML = '✅ Done';
      lineBtn.classList.add('btn-primary');
      lineBtn.classList.remove('btn-secondary');
    } else {
      lineBtn.innerHTML = '➖ Add Line';
      lineBtn.classList.remove('btn-primary');
      lineBtn.classList.add('btn-secondary');
    }
    
    updateUI();
  }

  // Export data
  function exportData() {
    const dataStr = JSON.stringify(appState.currentData, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = 'chat_tool_data.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    
    showNotification('Data exported successfully!');
  }

  // Open import modal
  function openImportModal() {
    const modal = document.getElementById('importModal');
    modal.classList.add('show');
  }

  // Import data
  function importData() {
    const fileInput = document.getElementById('importFile');
    
    if (!fileInput.files || fileInput.files.length === 0) {
      alert('Please select a file to import');
      return;
    }
    
    const file = fileInput.files[0];
    const reader = new FileReader();
    
    reader.onload = function(e) {
      try {
        const data = JSON.parse(e.target.result);
        appState.currentData = data;
        saveData();
        updateUI();
        closeModal('importModal');
        showNotification('Data imported successfully!');
      } catch (error) {
        console.error('Error importing data:', error);
        alert('Failed to import data. Make sure the file is a valid JSON.');
      }
    };
    
    reader.readAsText(file);
  }

  // Close modal
  function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.remove('show');
  }

  // Attach event listeners
  function attachEventListeners() {
    // Tab navigation
    document.querySelectorAll('.tab-button').forEach(btn => {
      btn.addEventListener('click', () => {
        appState.activeTab = btn.dataset.tab;
        updateUI();
      });
    });
    
    // Save button
    document.getElementById('saveBtn').addEventListener('click', saveData);
    
    // Edit mode button
    document.getElementById('editModeBtn').addEventListener('click', toggleEditMode);
    
    // Add line button
    document.getElementById('addLineBtn').addEventListener('click', toggleAddLineMode);
    
    // Add new button
    document.getElementById('addNewBtn').addEventListener('click', addNewItem);
    
    // Save edit button
    document.getElementById('saveEditBtn').addEventListener('click', saveEditedItem);
    
    // Import button
    document.getElementById('importBtn').addEventListener('click', importData);
    
    // Close modals
    document.querySelectorAll('.modal-close, .cancel-modal').forEach(btn => {
      btn.addEventListener('click', () => {
        const modal = btn.closest('.modal');
        modal.classList.remove('show');
      });
    });
    
    // Close modal when clicking outside
    document.querySelectorAll('.modal').forEach(modal => {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          modal.classList.remove('show');
        }
      });
    });
  }

  // Initialize the app
  init();
});