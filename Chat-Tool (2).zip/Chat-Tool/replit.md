# Chat Tool App - Repository Architecture

## Overview

This is a customer support chat tool web application built with React and TypeScript. It allows users to manage predefined responses for customer service across multiple categories, with bilingual support (Greek and English). The application can run as a web application or be packaged as an Electron desktop app.

## Recent Changes (January 2025)

✓ Updated greeting templates with 5 new professional customer service openings
✓ Replaced cases section with 13 new operational categories for MP & OD processes
✓ Added detailed "Ζυγίσιμα Προϊόντα" workflow with cash/card payment scenarios
✓ Integrated specific process templates for store cancellations, user contact issues, and product shortages
✓ Fully implemented night mode/dark theme functionality with discrete toggle button
✓ Added complete dark mode support to all UI components (ResponseItem, CaseItem, TabsManager, etc.)
✓ Implemented smooth color transitions and proper contrast for accessibility in dark mode

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with custom CSS variables
- **UI Components**: Radix UI components with shadcn/ui
- **Routing**: Wouter for client-side routing
- **State Management**: React Context API with useReducer
- **Icons**: Font Awesome 6

### Backend Architecture
- **Server**: Express.js with TypeScript
- **Database**: Configured for PostgreSQL with Drizzle ORM (currently minimal implementation)
- **API**: RESTful API endpoints (currently basic health check)
- **File Serving**: Vite development server integration

### Build System
- **Bundler**: Vite for development and production builds
- **Deployment**: Supports both web deployment and Electron packaging
- **Development**: Hot module replacement with Vite

## Key Components

### Data Management
- **Storage**: Local storage for web version, file system for Electron
- **Context Provider**: ChatToolContext manages all application state
- **Data Structure**: JSON-based with categories, responses, cases, and custom tabs
- **Backup/Restore**: Export/import functionality for data persistence

### User Interface Components
- **TabNavigation**: Multi-tab interface for different response categories
- **ResponseItem**: Individual response management with edit/delete actions
- **CaseItem**: Case management with multiple responses per case
- **EditModal**: Modal for editing response content in both languages
- **CategoryManager**: Hierarchical category and subcategory management

### Core Features
- **Bilingual Support**: Greek and English content for each response
- **Time-based Greetings**: Automatic morning/evening greeting replacement
- **Drag & Drop**: Reordering of responses and tabs
- **Copy to Clipboard**: One-click copying of responses
- **Custom Tabs**: User-defined tabs with custom icons and names

## Data Flow

1. **Initialization**: App loads default data or retrieves from storage
2. **User Interaction**: Users interact with tabs, responses, and cases
3. **State Updates**: Context provider manages state changes via reducer
4. **Persistence**: Changes automatically saved to localStorage (web) or file system (Electron)
5. **Export/Import**: Users can backup/restore data via JSON files

### Storage Strategy
- **Web Version**: localStorage with sessionStorage fallback
- **Electron Version**: File system storage in user data directory
- **Backup**: JSON export/import for data portability

## External Dependencies

### Core Dependencies
- **React Ecosystem**: React, React DOM, React Router (Wouter)
- **UI Libraries**: Radix UI, Tailwind CSS, Font Awesome
- **Build Tools**: Vite, TypeScript, ESBuild
- **Database**: Drizzle ORM with PostgreSQL support
- **Utilities**: clsx, tailwind-merge, date-fns

### Development Dependencies
- **Electron**: For desktop app packaging
- **Replit Integration**: Development environment plugins
- **Testing**: TypeScript compiler for type checking

### Optional Integrations
- **Stripe**: Payment processing (configured but not actively used)
- **Tanstack Query**: Data fetching (minimal usage)

## Deployment Strategy

### Web Application
- **Development**: Vite dev server with hot reloading
- **Production**: Static build deployed to Replit or other hosting
- **Assets**: Served from dist/public directory

### Electron Desktop App
- **Packaging**: Electron Builder for cross-platform builds
- **Distribution**: Portable executables and installers
- **Auto-updates**: Configured but not implemented

### Data Persistence
- **Web**: Browser localStorage with export/import
- **Desktop**: File system storage in user data folder
- **Backup**: JSON files for data portability

The application prioritizes simplicity and reliability, with automatic data persistence and a clean, functional interface optimized for customer support workflows.