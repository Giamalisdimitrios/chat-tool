import { ChatToolData } from "../types";

// Custom chat data provided by the user
export const defaultData: ChatToolData = {
  "greeting": [
    {
      "id": "1",
      "title": "Γνωρίζω το αίτημα",
      "content": "Γεια σου! 👋Ευχαριστούμε που επικοινώνησες με την ομάδα μας. Κοιτάμε ήδη το θέμα που αντιμετωπίζεις και θα επικοινωνήσουμε μαζί σου το συντομότερο 😀",
      "contentEN": "Hey you! 👋 Thanks for contacting our customer care team. We are looking into your issue and we will get back to you shortly 😀",
      "category": "greeting"
    },
    {
      "id": "2",
      "title": "Καλησπέρα! - Γνωρίζω το αίτημα",
      "content": "Καλησπέρα!",
      "contentEN": "Good evening!",
      "category": "greeting"
    },
    {
      "id": "3",
      "title": "Δε γνωρίζω το αίτημα",
      "content": "Γεια σου! 👋 Ευχαριστούμε που επικοινώνησες μαζί μας! Παρακαλώ ενημέρωσέ μας για το θέμα που αντιμετωπίζεις και θα σε βοηθήσω όσο πιο άμεσα γίνεται 😀",
      "contentEN": "Hey you! 👋 Thanks for contacting our customer care team. Please let me know about the issue you are facing and I will help you as soon as possible 😀",
      "category": "greeting"
    },
    {
      "id": "4",
      "title": "Πως μπορώ να βοηθήσω; μ.μ.",
      "content": "Καλησπέρα! Πώς μπορώ να βοηθήσω;",
      "contentEN": "Good evening! How may I help you?",
      "category": "greeting"
    },
    {
      "id": "5",
      "title": "Σε ευχαριστώ για το μήνυμά σου - μισό λεπτό",
      "content": "Σ' ευχαριστούμε για το μήνυμά σου! Θα χρειαστώ λίγο χρόνο να ελέγξω τι ακριβώς συμβαίνει και σε ενημερώνω άμεσα!",
      "contentEN": "Thank you for your message! Please give me a minute to check all the details and I will get back to you shortly",
      "category": "greeting"
    }
  ],
  "waiting": [
    {
      "id": "10",
      "title": "Αναμονή 8",
      "content": "Καλημέρα/Καλησπέρα! Ζητώ συγνώμη για την καθυστέρηση και την αναμονή 😞 Αν είσαι ακόμα εδώ, τι μπορώ να κάνω για σένα;💖",
      "contentEN": "Good morning! I truly apologize for the delay and the waiting 😞! If you're still here, how can I help you? 💖",
      "category": "waiting"
    },
    {
      "id": "11",
      "title": "Αναμονή 1",
      "content": "Καλημέρα/Καλησπέρα! Λυπάμαι πολύ για όλη σου την αναμονή. Αν είσαι ακόμα εδώ, πώς θα μπορούσα να σε βοηθήσω;",
      "contentEN": "Good morning! I'm really sorry for keeping you waiting. If you're still here, how can I help you?",
      "category": "waiting"
    },
    {
      "id": "12",
      "title": "Αναμονή 2",
      "content": "Καλημέρα/Καλησπέρα! Λυπάμαι που περίμενες παραπάνω απ' όσο θα θέλαμε! Αυτή τη στιγμή αντιμετωπίζουμε αναπάντεχα αυξημένο φόρτο. Αν είσαι ακόμα εδώ, θα χαρώ πολύ να σε βοηθήσω!",
      "contentEN": "Good morning! I'm sorry you had to wait longer than we would have liked! We are currently experiencing unexpectedly high workload. If you're still here, I'd be very happy to help you!",
      "category": "waiting"
    },
    {
      "id": "13",
      "title": "Αναμονή 3",
      "content": "Καλημέρα/Καλησπέρα! Λυπάμαι που δεν ανταποκρίθηκα νωρίτερα στο μήνυμά σου, αντιμετωπίσαμε αυξημένο φόρτο. Είμαι όμως τώρα εδώ, για να δούμε μαζί ό,τι χρειάζεσαι",
      "contentEN": "Good morning! I'm sorry I couldn't respond to your message sooner, we were dealing with high workload. However, I'm here now to help you with whatever you need",
      "category": "waiting"
    },
    {
      "id": "14",
      "title": "Απολογούμαστε για την αναμονή (4)",
      "content": "Ζητώ συγγνώμη για την αναμονή 😔 Αν είσαι ακόμη στο chat, είμαι εδώ για να δούμε ό,τι χρειάζεσαι 💖",
      "contentEN": "I apologize for the wait 😔 If you're still in the chat, I'm here to see what you need 💖",
      "category": "waiting"
    },
    {
      "id": "15",
      "title": "Αναμονή 5",
      "content": "Καλημέρα/Καλησπέρα, λόγω αυξημένου φόρτου δεν κατάφερα να σε βοηθήσω νωρίτερα. Αν είσαι ακόμα εδώ, θα χαρώ πολύ να σε εξυπηρετήσω",
      "contentEN": "Good morning, due to high workload I wasn't able to help you earlier. If you're still here, I'd be very happy to help you now",
      "category": "waiting"
    },
    {
      "id": "16",
      "title": "Απολογούμαστε για την αναμονή (6)",
      "content": "Σου ζητώ συγγνώμη που περίμενες τόση ώρα! Έχουμε αυξημένο φόρτο και δεν σου απάντησα όσο άμεσα θα ήθελα 😔 Σε περίπτωση που είσαι ακόμα στην συνομιλία θα χαρώ πολύ να σε βοηθήσω",
      "contentEN": "I'm sorry you had to wait longer than we would have liked 😔",
      "category": "waiting"
    }
  ],
  "cases": [
    {
      "id": "case-1",
      "title": "Ακύρωση από το κατάστημα - MP & OD",
      "responses": [
        {
          "id": "case-resp-1",
          "title": "Ζητάμε αιτία ακύρωσης",
          "content": "Ζητάμε πολύ ευγενικά την αιτία ακύρωσης προκειμένου να ενημερώσουμε τον χρήστη.",
          "contentEN": "We politely ask for the cancellation reason in order to inform the user.",
          "type": "response"
        },
        {
          "id": "case-resp-2",
          "title": "Παραγγελία με μετρητά - Έχει επικοινωνήσει",
          "content": "Ακυρώνουμε την παραγγελία (δεν επικοινωνούμε με τον χρήστη για ακύρωση εφόσον έχει ήδη μιλήσει με το κατάστημα).",
          "contentEN": "We cancel the order (we don't contact the user for cancellation since they already spoke with the store).",
          "type": "response"
        },
        {
          "id": "case-resp-3",
          "title": "Παραγγελία με κάρτα - Adyen - Έχει επικοινωνήσει",
          "content": "Ακυρώνουμε την παραγγελία (δεν επικοινωνούμε τον χρήστη για διαδικασία αποδέσμευσης καθώς λαμβάνει αυτόματα sms & email για την ακύρωση και αποδέσμευση).",
          "contentEN": "We cancel the order (we don't contact the user for the release process as they automatically receive SMS & email for cancellation and release).",
          "type": "response"
        },
        {
          "id": "case-resp-4",
          "title": "Παραγγελία με κάρτα - Braintree/Πειραιώς - Έχει επικοινωνήσει",
          "content": "Ακυρώνουμε την παραγγελία και στέλνουμε sms στον χρήστη να τον ενημερώσουμε για ακύρωση και διαδικασία αποδέσμευσης.",
          "contentEN": "We cancel the order and send SMS to the user to inform them about cancellation and release process.",
          "type": "response"
        }
      ]
    },
    {
      "id": "case-2",
      "title": "Δε βρέθηκε ο χρήστης",
      "responses": [
        {
          "id": "case-resp-5",
          "title": "Ρωτάμε για διανομέα",
          "content": "Ρωτάμε αν ο διανομέας είναι ακόμη στη δ/νση του χρήστη & αν μπορεί να περιμένει λίγα λεπτά ακόμα.",
          "contentEN": "We ask if the delivery person is still at the user's address & if they can wait a few more minutes.",
          "type": "response"
        },
        {
          "id": "case-resp-6",
          "title": "Διανομέας στη διεύθυνση",
          "content": "Ενημερώνουμε ότι θα δοκιμάσουμε και εμείς να επικοινωνήσουμε με τον χρήστη και ότι εάν δεν τον βρούμε, θα του στείλουμε SMS.",
          "contentEN": "We inform that we will also try to contact the user and if we don't find them, we will send SMS.",
          "type": "response"
        },
        {
          "id": "case-resp-7",
          "title": "Διαδικασία κλήσεων",
          "content": "Καλούμε δύο φορές στο εναλλακτικό τηλέφωνο. Αν δεν απαντήσει, καλούμε 2 φορές στο κινητό τηλέφωνο του λογαριασμού. Αν δεν απαντήσει, στέλνουμε SMS.",
          "contentEN": "We call twice on the alternative phone. If no answer, we call twice on the account mobile. If no answer, we send SMS.",
          "type": "response"
        }
      ]
    },
    {
      "id": "case-3",
      "title": "Έλλειψη",
      "responses": [
        {
          "id": "case-resp-8",
          "title": "Διαδικασία ελέγχου",
          "content": "Ανοίγουμε την παραγγελία και τον κατάλογο του καταστήματος. Ρωτάμε ποιο προϊόν είναι σε έλλειψη και αν υπάρχει αντικατάσταση.",
          "contentEN": "We open the order and store catalog. We ask which product is out of stock and if there's a replacement.",
          "type": "response"
        },
        {
          "id": "case-resp-9",
          "title": "Αντικατάσταση ίσης αξίας",
          "content": "Ενημερώνουμε τον χρήστη ότι η συνολική αξία της παραγγελίας παραμένει ίδια. Ενημερώνουμε το κατάστημα. Αφήνουμε σχόλιο στο OneView.",
          "contentEN": "We inform the user that the total order value remains the same. We inform the store. We leave a comment in OneView.",
          "type": "response"
        }
      ]
    },
    {
      "id": "case-4",
      "title": "Ζυγίσιμα Προϊόντα",
      "responses": [
        {
          "id": "case-resp-10",
          "title": "Παραγγελία με μετρητά - Βήμα 1",
          "content": "Ενημερώνουμε το κατάστημα ότι θα το μεταφέρουμε στον χρήστη για την αλλαγή και θα τους καλέσουμε πίσω να τους ενημερώσουμε σχετικά.",
          "contentEN": "We inform the store that we will transfer it to the user for the change and will call them back to inform them.",
          "type": "response"
        },
        {
          "id": "case-resp-11",
          "title": "Παραγγελία με μετρητά - Βήμα 2",
          "content": "Ενημερώνουμε τον χρήστη για τη διαφορά που προκύπτει προκειμένου να πάρουμε το οκ και από τον ίδιο για την αλλαγή τιμής.",
          "contentEN": "We inform the user about the difference that arises in order to get approval from them for the price change.",
          "type": "response"
        },
        {
          "id": "case-resp-12",
          "title": "Παραγγελία με μετρητά - Βήμα 3",
          "content": "Ενημερώνουμε το κατάστημα ότι μπορούμε να προχωρήσουμε σε αλλαγή τιμής κατόπιν συνεννόησης με τον χρήστη. Αλλάζουμε το ποσό στην παραγγελία στο backend. Αφήνουμε σχόλιο στο OneView.",
          "contentEN": "We inform the store that we can proceed with price change after agreement with the user. We change the amount in the order in the backend. We leave a comment in OneView.",
          "type": "response"
        },
        {
          "id": "case-resp-13",
          "title": "Παραγγελία με κάρτα - Ερώτηση για μετρητά",
          "content": "Ενημερώνουμε τον χρήστη ότι προκύπτει μια χ διαφορά στην τιμή και ρωτάμε αν διαθέτει μετρητά για να καλύψει τη διαφορά στον διανομέα κατά την παράδοση.",
          "contentEN": "We inform the user that there is a difference in price and ask if they have cash to cover the difference to the delivery person upon delivery.",
          "type": "response"
        },
        {
          "id": "case-resp-14",
          "title": "Ο χρήστης έχει μετρητά",
          "content": "Ενημερώνουμε για το νέο σύνολο και ότι η διαφορά είναι χ ευρώ. Ενημερώνουμε το κατάστημα για τη διαφορά και ότι ο χρήστης θα καλύψει τη διαφορά με μετρητά στον διανομέα. Αλλάζουμε το ποσό στην παραγγελία. Αφήνουμε σχόλιο στο OneView αναφέροντας ότι θα δοθεί η διαφορά στον διανομέα με μετρητά.",
          "contentEN": "We inform about the new total and that the difference is x euros. We inform the store about the difference and that the user will cover it with cash to the delivery person. We change the order amount. We leave a comment in OneView stating that the difference will be given to the delivery person in cash.",
          "type": "response"
        },
        {
          "id": "case-resp-15",
          "title": "Ο χρήστης δεν έχει μετρητά",
          "content": "Ενημερώνουμε τον χρήστη ότι θα καλύψουμε εμείς τη διαφορά μέχρι 1 ευρώ. Αν η διαφορά είναι >1€ ενημερώνουμε Team Leader και αναμένουμε οδηγίες. Ενημερώνουμε το κατάστημα ότι θα καλύψουμε εμείς τη διαφορά. Αλλάζουμε το ποσό στην παραγγελία. Αφήνουμε σχόλιο στο OneView αναφέροντας ότι καλύπτουμε εμείς τη διαφορά.",
          "contentEN": "We inform the user that we will cover the difference up to 1 euro. If the difference is >1€ we inform Team Leader and await instructions. We inform the store that we will cover the difference. We change the order amount. We leave a comment in OneView stating that we cover the difference.",
          "type": "response"
        }
      ]
    },
    {
      "id": "case-5",
      "title": "Το κατ/μα επιθυμεί να προσφέρει ολόκληρη ή μέρος της παραγγελίας",
      "responses": [
        {
          "id": "case-resp-16",
          "title": "Ολόκληρη παραγγελία - Μετρητά",
          "content": "Ενημερώνουμε τον χρήστη ότι το κατάστημα θα ήθελε να του στείλει την παραγγελία, χωρίς καμία δική του επιβάρυνση. Στέλνουμε ASANA - Λογιστήριο.",
          "contentEN": "We inform the user that the store would like to send them the order without any charge. We send ASANA - Accounting.",
          "type": "response"
        },
        {
          "id": "case-resp-17",
          "title": "Ολόκληρη παραγγελία - Κάρτα",
          "content": "Ενημερώνουμε τον χρήστη ότι το κατάστημα θα στείλει την παραγγελία χωρίς επιβάρυνση και η αποδέσμευση θα γίνει σε 5 εργάσιμες. Στέλνουμε ASANA - e-payments.",
          "contentEN": "We inform the user that the store will send the order without charge and the release will be done in 5 business days. We send ASANA - e-payments.",
          "type": "response"
        }
      ]
    },
    {
      "id": "case-6",
      "title": "Μεταφορά παραγγελίας σε άλλο κατάστημα",
      "responses": []
    },
    {
      "id": "case-7",
      "title": "Ξεχάστηκε προϊόν",
      "responses": []
    },
    {
      "id": "case-8",
      "title": "Ο χρήστης δεν πλήρωσε",
      "responses": []
    },
    {
      "id": "case-9",
      "title": "Περιβαλλοντικό τέλος & τέλος ανακύκλωσης PVC",
      "responses": []
    },
    {
      "id": "case-10",
      "title": "Προϊόντα χωρίς προμήθεια",
      "responses": []
    },
    {
      "id": "case-11",
      "title": "Δεν εξυπηρετείται η διεύθυνση της παραγγελίας από το κατάστημα",
      "responses": []
    },
    {
      "id": "case-12",
      "title": "Customer Cancellation",
      "responses": []
    },
    {
      "id": "case-13",
      "title": "Order Cancellation Inquiry",
      "responses": []
    }
  ],
  "closing": [
    {
      "id": "82",
      "title": "Άλλο που μπορώ να βοηθήσω;",
      "content": "Υπάρχει κάτι άλλο που μπορώ να βοηθήσω;",
      "contentEN": "Is there anything else I can help you with?",
      "category": "closing"
    },
    {
      "id": "83",
      "title": "Ευχαριστούμε για την επικοινωνία (1)",
      "content": "Σ' ευχαριστούμε για την επικοινωνία! Καλή συνέχεια.",
      "contentEN": "Thank you for your message! Have a nice day.",
      "category": "closing"
    },
    {
      "id": "84",
      "title": "Ευχαριστούμε για την επικοινωνία (2)",
      "content": "Εύχομαι να σε βοήθησα κι αν χρειαστείς κάτι, μη διστάσεις να μου πεις!",
      "contentEN": "I hope I helped you and if you need anything, don't hesitate to let me know!",
      "category": "closing"
    },
    {
      "id": "85",
      "title": "Ευχαριστούμε για την Υπομονή",
      "content": "Σε ευχαριστούμε για την υπομονή σου! Στόχος μας είναι να παρέχουμε την καλύτερη δυνατή εξυπηρέτηση!",
      "contentEN": "Thank you for your patience! Our goal is to provide the best possible service!",
      "category": "closing"
    },
    {
      "id": "86",
      "title": "Χαίρομαι που βοήθησα",
      "content": "Χαίρομαι που μπόρεσα να βοηθήσω! Καλή συνέχεια!",
      "contentEN": "I'm glad I could help! Have a nice day!",
      "category": "closing"
    },
    {
      "id": "87",
      "title": "Προωθούμε τα σχόλια",
      "content": "Τα σχόλιά σου είναι πολύ σημαντικά και θα τα προωθήσω στην ομάδα μας ώστε να βελτιώνουμε συνεχώς τις υπηρεσίες μας!",
      "contentEN": "Your comments are very important and I will forward them to our team so that we can continuously improve our services!",
      "category": "closing"
    },
    {
      "id": "88",
      "title": "Καλή απόλαυση",
      "content": "Σου εύχομαι καλή απόλαυση!",
      "contentEN": "I wish you bon appétit!",
      "category": "closing"
    },
    {
      "id": "89",
      "title": "Καλή όρεξη",
      "content": "Καλή όρεξη και καλό υπόλοιπο της ημέρας!",
      "contentEN": "Bon appétit and have a nice rest of your day!",
      "category": "closing"
    }
  ],
  "comments": [
    {
      "id": "101",
      "title": "Πληροφορίες παραγγελίας",
      "subcategories": [
        {
          "id": "201",
          "title": "Χρόνος παράδοσης",
          "responses": [
            {
              "id": "301",
              "content": "Ο χρόνος παράδοσης που εμφανίζεται στην εφαρμογή είναι μια εκτίμηση και μπορεί να υπάρξουν μικρές αποκλίσεις. Αυτό μπορεί να συμβεί λόγω διάφορων παραγόντων όπως η κίνηση στους δρόμους, αυξημένος αριθμός παραγγελιών κλπ.",
              "contentEN": "The delivery time displayed in the app is an estimate and there may be small deviations. This can happen due to various factors such as traffic on the roads, increased number of orders, etc."
            },
            {
              "id": "302",
              "content": "Ο χρόνος παράδοσης επηρεάζεται από πολλούς παράγοντες όπως ο φόρτος εργασίας του καταστήματος, η κίνηση στους δρόμους και η απόσταση. Σε περίπτωση καθυστέρησης, μη διστάσεις να επικοινωνήσεις μαζί μας.",
              "contentEN": "The delivery time is affected by many factors such as the workload of the store, traffic on the roads, and distance. In case of delay, don't hesitate to contact us."
            }
          ]
        },
        {
          "id": "202",
          "title": "Τρόποι πληρωμής",
          "responses": [
            {
              "id": "303",
              "content": "Μπορείς να πληρώσεις με μετρητά στον διανομέα ή με κάρτα στην εφαρμογή. Αν αντιμετωπίζεις κάποιο πρόβλημα με την πληρωμή, μπορούμε να σε βοηθήσουμε.",
              "contentEN": "You can pay with cash to the delivery person or with a card in the app. If you're having a problem with the payment, we can help you."
            },
            {
              "id": "304",
              "content": "Υπάρχουν διάφοροι τρόποι πληρωμής διαθέσιμοι, όπως πληρωμή με κάρτα μέσω της εφαρμογής ή πληρωμή με μετρητά κατά την παράδοση.",
              "contentEN": "Various payment methods are available, such as card payment through the app or cash payment upon delivery."
            }
          ]
        }
      ]
    },
    {
      "id": "102",
      "title": "Προβλήματα εφαρμογής",
      "subcategories": [
        {
          "id": "203",
          "title": "Τεχνικά θέματα",
          "responses": [
            {
              "id": "305",
              "content": "Αν αντιμετωπίζεις τεχνικό πρόβλημα, δοκίμασε να κάνεις επανεκκίνηση της εφαρμογής ή να την ενημερώσεις στην τελευταία έκδοση.",
              "contentEN": "If you're experiencing a technical issue, try restarting the app or updating it to the latest version."
            },
            {
              "id": "306",
              "content": "Σε περίπτωση τεχνικού προβλήματος, συνήθως βοηθάει η επανεκκίνηση της συσκευής ή η επανεγκατάσταση της εφαρμογής.",
              "contentEN": "In case of a technical problem, restarting the device or reinstalling the app usually helps."
            }
          ]
        },
        {
          "id": "204",
          "title": "Προβλήματα σύνδεσης",
          "responses": [
            {
              "id": "307",
              "content": "Αν δεν μπορείς να συνδεθείς στην εφαρμογή, έλεγξε τη σύνδεσή σου στο internet και δοκίμασε ξανά. Αν το πρόβλημα παραμένει, δοκίμασε να αποσυνδεθείς και να συνδεθείς ξανά.",
              "contentEN": "If you can't connect to the app, check your internet connection and try again. If the problem persists, try logging out and logging back in."
            },
            {
              "id": "308",
              "content": "Για προβλήματα σύνδεσης, συνήθως φταίει η σύνδεση στο διαδίκτυο. Δοκίμασε να συνδεθείς σε άλλο δίκτυο και να κάνεις επανεκκίνηση της συσκευής σου.",
              "contentEN": "For connection problems, the internet connection is usually at fault. Try connecting to another network and restarting your device."
            }
          ]
        }
      ]
    }
  ],
  "tabsOrder": ["greeting", "waiting", "cases", "closing", "comments"],
  "activeTabs": ["greeting", "waiting", "cases", "closing"]
}