import { useEffect, useState, useRef } from 'react';
import { useParams, useLocation } from 'wouter';
import { useChatTool } from '@/contexts/ChatToolContext';
import CopyAlert from '@/components/CopyAlert';
import { useCopyToClipboard } from '@/hooks/useCopyToClipboard';
import { Category } from '@/types';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import EditModal from '@/components/EditModal';
import { generateId } from '@/lib/utils';
import LineItemComponent from '@/components/LineItem';
import ResponseItem from '@/components/ResponseItem';
import TabNavigation from '@/components/TabNavigation';
import { TabNames } from '@/types';

const SubcategoryDetailPage = () => {
  const { state, updateCategory } = useChatTool();
  
  // States
  const [isDragging, setIsDragging] = useState(false);
  const [isEditModeActive, setIsEditModeActive] = useState(false);
  const [showAddLineButtons, setShowAddLineButtons] = useState(false);
  const [draggedItem, setDraggedItem] = useState<number | null>(null);
  const dragItemNode = useRef<HTMLDivElement | null>(null);
  const [location, setLocation] = useLocation();
  const { categoryId } = useParams();
  
  const [category, setCategory] = useState<Category | null>(null);
  const [showCopyAlert, setShowCopyAlert] = useState(false);
  const [alertText, setAlertText] = useState('Text copied to clipboard!');
  
  // Edit modal state
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editingResponse, setEditingResponse] = useState({
    id: '',
    title: '',
    content: '',
    contentEN: '',
    index: -1
  });

  // Set document title
  useDocumentTitle(category ? `Subcategory: ${category.title}` : 'Subcategory');
  
  // Get the selected category by ID
  useEffect(() => {
    if (categoryId) {
      let foundCategory: Category | undefined;
      
      // Check in comments array first
      foundCategory = state.comments?.find(c => c.id === categoryId);
      
      // If not found, check in custom tabs
      if (!foundCategory) {
        for (const key in state) {
          if (key.startsWith('custom_') && Array.isArray(state[key])) {
            foundCategory = state[key].find((c: any) => c.id === categoryId);
            if (foundCategory) {
              // Add customTab property to help with updates
              foundCategory = {...foundCategory, customTab: key};
              break;
            }
          }
        }
      }
      
      if (foundCategory) {
        setCategory(foundCategory);
      } else {
        // If category not found, redirect back
        setLocation('/');
      }
    }
  }, [categoryId, state, setLocation]);

  // Handle copy notification
  const showCopyNotification = (customText?: string) => {
    setAlertText(customText || 'Text copied to clipboard!');
    setShowCopyAlert(true);
    setTimeout(() => setShowCopyAlert(false), 2000);
  };

  const { copyText } = useCopyToClipboard(showCopyNotification);
  
  // Handle opening edit modal
  const handleOpenEditModal = (response: any, index: number) => {
    setEditingResponse({
      id: response.id,
      title: response.title || 'Response',  // Use existing title if available
      content: response.content,
      contentEN: response.contentEN || '',
      index
    });
    setEditModalOpen(true);
  };
  
  // Handle adding new response
  const handleAddNewResponse = () => {
    setEditingResponse({
      id: '',
      title: 'New Response',
      content: '',
      contentEN: '',
      index: -1
    });
    setEditModalOpen(true);
  };
  
  // Drag and drop handlers
  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, index: number) => {
    if (!isEditModeActive || !category) return;
    
    setIsDragging(true);
    setDraggedItem(index);
    dragItemNode.current = e.target as HTMLDivElement;
    
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/html', (e.target as HTMLDivElement).innerHTML);
    
    setTimeout(() => {
      if (dragItemNode.current) {
        dragItemNode.current.classList.add('dragging');
      }
    }, 0);
  };
  
  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>, targetIndex: number) => {
    if (!isEditModeActive || draggedItem === null || !category || !category.responses) return;
    
    const currentItem = targetIndex;
    
    // Add visual indicator for drag target
    const responseItems = document.querySelectorAll('.subcategory-response-item');
    responseItems.forEach((item, index) => {
      if (index === targetIndex) {
        item.classList.add('drag-over-target');
      } else {
        item.classList.remove('drag-over-target');
      }
    });
    
    if (draggedItem !== currentItem) {
      // Create deep copy of the category
      const updatedCategory = {...category};
      const newItems = [...updatedCategory.responses];
      const draggedItemContent = newItems[draggedItem];
      newItems.splice(draggedItem, 1);
      newItems.splice(targetIndex, 0, draggedItemContent);
      
      // Update the responses order
      updatedCategory.responses = newItems;
      
      // Update the context
      if (category.customTab) {
        updateCategory({...updatedCategory, customTab: category.customTab});
      } else {
        updateCategory(updatedCategory);
      }
      
      // Update local state
      setCategory(updatedCategory);
      setDraggedItem(targetIndex);
    }
  };
  
  const handleDragEnd = (e: React.DragEvent<HTMLDivElement>) => {
    if (!isEditModeActive) return;
    
    setIsDragging(false);
    setDraggedItem(null);
    
    if (dragItemNode.current) {
      dragItemNode.current.classList.remove('dragging');
      dragItemNode.current = null;
    }
    
    // Remove visual indicators
    const responseItems = document.querySelectorAll('.subcategory-response-item');
    responseItems.forEach(item => {
      item.classList.remove('drag-over-target');
    });
  };
  
  // Toggle edit mode
  const toggleEditMode = () => {
    setIsEditModeActive(!isEditModeActive);
    
    if (showAddLineButtons) {
      setShowAddLineButtons(false);
    }
  };
  
  // This function is called when the Add Line button is clicked
  const handleAddLine = (afterResponseId: string) => {
    if (!category || !category.responses) return;
    
    // Create a new array with a line inserted after the specified response
    const updatedResponses = [...category.responses];
    
    // Find the index of the response
    const index = updatedResponses.findIndex((r: {id: string}) => r.id === afterResponseId);
    if (index === -1) return;
    
    // Create a line item
    const lineItem: { id: string; content: string; contentEN?: string; type: 'line' } = {
      id: `line-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      content: '',
      type: 'line'
    };
    
    // Insert the line after the specified response
    updatedResponses.splice(index + 1, 0, lineItem);
    
    // Update the category
    const updatedCategory = {...category, responses: updatedResponses};
    
    // Update the context
    if (category.customTab) {
      updateCategory({...updatedCategory, customTab: category.customTab});
    } else {
      updateCategory(updatedCategory);
    }
    
    // Update local state
    setCategory(updatedCategory);
    
    showCopyNotification('Line added successfully!');
  };
  
  // Handle saving edited responses
  const handleSaveEdit = (title: string, content: string, contentEN: string) => {
    if (!category) return;
    
    // Create deep copy of the category
    const updatedCategory = {...category};
    
    if (editingResponse.id === '') {
      // Adding a new response
      const newResponseId = generateId();
      const newResponse = {
        id: newResponseId,
        title,
        content,
        contentEN,
        type: 'response'
      };
      
      // Initialize responses array if it doesn't exist
      if (!updatedCategory.responses) {
        updatedCategory.responses = [];
      }
      
      // Add the new response
      updatedCategory.responses = [...updatedCategory.responses, newResponse];
      
      // Update the context
      if (category.customTab) {
        updateCategory({...updatedCategory, customTab: category.customTab});
      } else {
        updateCategory(updatedCategory);
      }
      
      // Update local state
      setCategory(updatedCategory);
      
      showCopyNotification('New response added successfully!');
    } else if (editingResponse.index >= 0 && updatedCategory.responses) {
      // Updating an existing response
      // Create a deep copy of the responses array
      const updatedResponses = [...updatedCategory.responses];
      
      // Get the current response
      const currentResponse = updatedResponses[editingResponse.index];
      
      // Update the specific response with new content
      updatedResponses[editingResponse.index] = {
        id: currentResponse.id,
        title,
        content,
        contentEN,
        type: currentResponse.type
      };
      
      // Update the category
      updatedCategory.responses = updatedResponses;
      
      // Update the context
      if (category.customTab) {
        updateCategory({...updatedCategory, customTab: category.customTab});
      } else {
        updateCategory(updatedCategory);
      }
      
      // Update local state
      setCategory(updatedCategory);
      
      showCopyNotification('Response updated successfully!');
    }
    
    // Close modal
    setEditModalOpen(false);
  };
  
  // Handle deleting a response
  const handleDeleteResponse = (responseId: string) => {
    if (!category || !category.responses) return;
    
    if (window.confirm('Are you sure you want to delete this response?')) {
      // Create deep copy of the category
      const updatedCategory = {...category};
      
      // Filter out the response to delete
      updatedCategory.responses = updatedCategory.responses.filter((r: {id: string}) => r.id !== responseId);
      
      // Update the context
      if (category.customTab) {
        updateCategory({...updatedCategory, customTab: category.customTab});
      } else {
        updateCategory(updatedCategory);
      }
      
      // Update local state
      setCategory(updatedCategory);
      
      showCopyNotification('Response deleted successfully!');
    }
  };

  // Tab change handler for bottom navigation
  const handleTabChange = (tab: TabNames | string) => {
    // Store the active tab in localStorage
    localStorage.setItem('activeTab', tab);
    // Navigate to home page
    setLocation('/');
  };

  if (!category) {
    return (
      <div className="p-4 flex justify-center items-center">
        <div className="spinner">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-2" id="subcategory-detail-page">
      <div className="max-w-4xl mx-auto">
        {/* Header with back button */}
        <div className="flex items-center gap-2 mb-2">
          <button 
            className="bg-secondary-200 hover:bg-secondary-300 text-secondary-800 px-2 py-1 rounded text-sm flex items-center gap-1"
            onClick={() => {
              // If this is from a custom tab, set that tab as active
              if (category.customTab) {
                localStorage.setItem('activeTab', category.customTab);
              }
              // Navigate back to home
              setLocation('/');
            }}
          >
            <i className="fas fa-arrow-left text-xs"></i> Back
          </button>
          <h1 className="text-base font-semibold text-primary-700">{category.title}</h1>
        </div>

        {/* Responses */}
        <div className="bg-white rounded border border-gray-200 p-3">
          <div className="flex justify-between items-center mb-2">
            <h2 className="text-sm font-medium">Responses</h2>
            <div className="flex items-center gap-1">
              <button 
                className={`text-xs py-1 px-2 rounded text-white ${isEditModeActive 
                  ? 'bg-primary-600 hover:bg-primary-700' 
                  : 'bg-primary-500 hover:bg-primary-600'}`}
                onClick={() => {
                  toggleEditMode();
                  setShowAddLineButtons(false);
                }}
              >
                <i className="fas fa-pencil-alt mr-1 text-[10px]"></i>
                {isEditModeActive ? 'Save' : 'Edit'}
              </button>
              <button 
                className={`text-xs py-1 px-2 rounded ${
                  showAddLineButtons 
                    ? 'bg-primary-600 hover:bg-primary-700 text-white' 
                    : 'bg-primary-500 hover:bg-primary-600 text-white'
                }`}
                onClick={() => {
                  setShowAddLineButtons(!showAddLineButtons);
                  setIsEditModeActive(false);
                  if (showAddLineButtons) {
                    showCopyNotification('Add Line mode disabled');
                  } else {
                    showCopyNotification('Click on a response to add a line below it');
                  }
                }}
              >
                <i className="fas fa-grip-lines mr-1 text-[10px]"></i>
                {showAddLineButtons ? 'Done' : 'Add Line'}
              </button>
              <button 
                className="bg-primary-500 hover:bg-primary-600 text-white py-1 px-2 rounded text-xs flex items-center gap-1"
                onClick={handleAddNewResponse}
              >
                <i className="fas fa-plus"></i> Add New
              </button>
            </div>
          </div>
          
          {category.responses && category.responses.length > 0 ? (
            <div className={`space-y-2 ${isEditModeActive ? 'edit-mode' : ''}`}>
              {category.responses.map((response: any, index: number) => 
                response.type === 'line' ? (
                  <div 
                    key={response.id}
                    draggable={isEditModeActive}
                    onDragStart={(e) => handleDragStart(e, index)}
                    onDragEnter={(e) => handleDragEnter(e, index)}
                    onDragEnd={handleDragEnd}
                    onDragOver={(e) => e.preventDefault()}
                    className={`${isDragging && index === draggedItem ? 'dragging' : ''} subcategory-response-item`}
                  >
                    <LineItemComponent
                      id={response.id}
                      category="subcategory"
                      isEditMode={isEditModeActive}
                      onDelete={() => {
                        if (window.confirm('Are you sure you want to delete this line?')) {
                          handleDeleteResponse(response.id);
                        }
                      }}
                    />
                  </div>
                ) : (
                  <div 
                    key={response.id} 
                    className="relative subcategory-response-item"
                    draggable={isEditModeActive}
                    onDragStart={(e) => handleDragStart(e, index)}
                    onDragEnter={(e) => handleDragEnter(e, index)}
                    onDragEnd={handleDragEnd}
                    onDragOver={(e) => e.preventDefault()}
                  >
                    <ResponseItem 
                      response={{
                        id: response.id,
                        title: response.title || 'Response',
                        content: response.content,
                        contentEN: response.contentEN || '',
                        category: 'subcategory',
                        type: 'response'
                      }}
                      onShowNotification={showCopyNotification}
                      onOpenEditModal={(resp) => handleOpenEditModal(resp, index)}
                      onOpenTitleModal={() => {}}
                      onDelete={() => handleDeleteResponse(response.id)}
                    />
                    
                    {!isEditModeActive && showAddLineButtons && (
                      <button 
                        className="add-line-button absolute right-2 top-1/2 -translate-y-1/2 bg-primary-500 hover:bg-primary-600 text-white text-xs py-1 px-2 rounded"
                        onClick={() => handleAddLine(response.id)}
                        title="Add line after this response"
                      >
                        <i className="fas fa-plus"></i>
                      </button>
                    )}
                  </div>
                )
              )}
            </div>
          ) : (
            <div className="text-center text-gray-500 p-4">
              No responses yet. Click "Add New" to create one.
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      <EditModal
        isOpen={editModalOpen}
        onClose={() => setEditModalOpen(false)}
        title={editingResponse.title}
        content={editingResponse.content}
        contentEN={editingResponse.contentEN}
        onSave={handleSaveEdit}
      />

      {/* Copy Notification */}
      <CopyAlert show={showCopyAlert} text={alertText} />

      {/* Bottom Navigation */}
      <TabNavigation 
        activeTab={category.customTab || 'comments'} 
        onChangeTab={handleTabChange}
      />
    </div>
  );
};

export default SubcategoryDetailPage;