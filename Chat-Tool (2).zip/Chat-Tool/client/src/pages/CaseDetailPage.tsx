import { useEffect, useState, useRef } from 'react';
import { useParams, useLocation } from 'wouter';
import { useChatTool } from '@/contexts/ChatToolContext';
import CopyAlert from '@/components/CopyAlert';
import { useCopyToClipboard } from '@/hooks/useCopyToClipboard';
import { Case, Response, LineItem } from '@/types';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import EditModal from '@/components/EditModal';
import { replaceGreetingPlaceholders, generateId } from '@/lib/utils';
import LineItemComponent from '@/components/LineItem';
import ResponseItem from '@/components/ResponseItem';
import TabNavigation from '@/components/TabNavigation';
import { TabNames } from '@/types';

const CaseDetailPage = () => {
  const { state, updateCase, deleteResponseFromCase, addResponseToCase, updateCaseResponsesOrder } = useChatTool();
  
  // States
  const [isDragging, setIsDragging] = useState(false);
  const [isEditModeActive, setIsEditModeActive] = useState(false);
  const [showAddLineButtons, setShowAddLineButtons] = useState(false);
  const [draggedItem, setDraggedItem] = useState<number | null>(null);
  const dragItemNode = useRef<HTMLDivElement | null>(null);
  const [location, setLocation] = useLocation();
  const { caseId } = useParams();
  const addLineButtonsRef = useRef<HTMLButtonElement[]>([]);
  
  const [caseItem, setCaseItem] = useState<Case | null>(null);
  const [showCopyAlert, setShowCopyAlert] = useState(false);
  const [alertText, setAlertText] = useState('Text copied to clipboard!');
  
  // Edit modal state
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editingResponse, setEditingResponse] = useState({
    id: '',
    title: '',
    content: '',
    contentEN: '',
    index: -1
  });

  // Set document title
  useDocumentTitle(caseItem ? `Case: ${caseItem.title}` : 'Case Details');
  
  // Get the selected case by ID
  useEffect(() => {
    if (caseId && state.cases) {
      const foundCase = state.cases.find(c => c.id === caseId);
      if (foundCase) {
        setCaseItem(foundCase);
      } else {
        // If case not found, redirect back to cases list
        setLocation('/');
      }
    }
  }, [caseId, state, setLocation]);

  // Handle copy notification
  const showCopyNotification = (customText?: string) => {
    setAlertText(customText || 'Text copied to clipboard!');
    setShowCopyAlert(true);
    setTimeout(() => setShowCopyAlert(false), 2000);
  };

  const { copyText } = useCopyToClipboard(showCopyNotification);
  
  // Handle opening edit modal
  const handleOpenEditModal = (response: any, index: number) => {
    setEditingResponse({
      id: response.id,
      title: response.title || 'Response',  // Use existing title if available
      content: response.content,
      contentEN: response.contentEN || '',
      index
    });
    setEditModalOpen(true);
  };
  
  // Handle adding new response
  const handleAddNewResponse = () => {
    setEditingResponse({
      id: '',
      title: 'New Response',
      content: '',
      contentEN: '',
      index: -1
    });
    setEditModalOpen(true);
  };
  
  // Drag and drop handlers
  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, index: number) => {
    if (!isEditModeActive) return;
    
    setIsDragging(true);
    setDraggedItem(index);
    dragItemNode.current = e.target as HTMLDivElement;
    
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/html', (e.target as HTMLDivElement).innerHTML);
    
    setTimeout(() => {
      if (dragItemNode.current) {
        dragItemNode.current.classList.add('dragging');
      }
    }, 0);
  };
  
  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>, targetIndex: number) => {
    if (!isEditModeActive || draggedItem === null) return;
    
    const currentItem = targetIndex;
    
    // Add visual indicator for drag target
    const responseItems = document.querySelectorAll('.case-response-item');
    responseItems.forEach((item, index) => {
      if (index === targetIndex) {
        item.classList.add('drag-over-target');
      } else {
        item.classList.remove('drag-over-target');
      }
    });
    
    if (draggedItem !== currentItem) {
      if (caseItem) {
        const newItems = [...caseItem.responses];
        const draggedItemContent = newItems[draggedItem];
        newItems.splice(draggedItem, 1);
        newItems.splice(targetIndex, 0, draggedItemContent);
        
        // Update the case with new order
        const updatedCase = { ...caseItem, responses: newItems };
        setCaseItem(updatedCase);
      }
      setDraggedItem(targetIndex);
    }
  };
  
  const handleDragEnd = (e: React.DragEvent<HTMLDivElement>) => {
    if (!isEditModeActive) return;
    
    setIsDragging(false);
    setDraggedItem(null);
    
    if (dragItemNode.current) {
      dragItemNode.current.classList.remove('dragging');
      dragItemNode.current = null;
    }
    
    // Remove visual indicators
    const responseItems = document.querySelectorAll('.case-response-item');
    responseItems.forEach(item => {
      item.classList.remove('drag-over-target');
    });
    
    // Save the new order to the context
    if (caseItem) {
      const responseIds = caseItem.responses.map(response => response.id);
      updateCaseResponsesOrder(caseItem.id, responseIds);
    }
  };
  
  // Toggle edit mode
  const toggleEditMode = () => {
    setIsEditModeActive(!isEditModeActive);
  };
  
  // Effect to make sure add line buttons are visible
  useEffect(() => {
    if (showAddLineButtons) {
      // Set a timeout to ensure components are rendered
      setTimeout(() => {
        const addLineButtons = document.querySelectorAll('.add-line-button');
        console.log('Found add line buttons:', addLineButtons.length);
      }, 100);
    }
  }, [showAddLineButtons]);
  
  // This function is called when the Add Line button is clicked
  const handleAddLine = (afterResponseId: string) => {
    if (!caseItem) return;
    
    // Create a new array with a line inserted after the specified response
    const updatedResponses = [...caseItem.responses];
    
    // Find the index of the response
    const index = updatedResponses.findIndex(r => r.id === afterResponseId);
    if (index === -1) return;
    
    // Create a line item
    const lineItem: { id: string; content: string; contentEN?: string; type: 'line' } = {
      id: `line-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      content: '',
      type: 'line'
    };
    
    // Insert the line after the specified response
    updatedResponses.splice(index + 1, 0, lineItem);
    
    // Update the case with the new responses
    const updatedCase = { ...caseItem, responses: updatedResponses };
    
    // Update the case in the context
    updateCase(updatedCase);
    
    // Update local state
    setCaseItem(updatedCase);
    
    showCopyNotification('Line added successfully!');
  };

  // Handle saving edited responses
  const handleSaveEdit = (title: string, content: string, contentEN: string) => {
    if (caseItem) {
      if (editingResponse.id === '') {
        // Adding a new response
        const newResponseId = generateId();
        
        // Add the new response to the case
        addResponseToCase(caseItem.id, {
          id: newResponseId,
          title, // Include title in the response
          content,
          contentEN,
          type: 'response'
        });
        
        // Show notification
        showCopyNotification('New response added successfully!');
      } else if (editingResponse.index >= 0) {
        // Updating an existing response
        // Create a deep copy of the case to update
        const updatedCase = { ...caseItem };
        
        // Create a deep copy of the responses array
        const updatedResponses = [...updatedCase.responses];
        
        // Get the current response
        const currentResponse = updatedResponses[editingResponse.index];
        
        // Update the specific response with new content
        updatedResponses[editingResponse.index] = {
          id: currentResponse.id,
          title, // Include title in the response
          content,
          contentEN,
          type: currentResponse.type
        };
        
        // Set the updated responses array
        updatedCase.responses = updatedResponses;
        
        // Update the case in context
        updateCase(updatedCase);
        
        // Update local state
        setCaseItem(updatedCase);
        
        // Show notification
        showCopyNotification('Response updated successfully!');
      }
    }
    
    // Close modal
    setEditModalOpen(false);
  };

  if (!caseItem) {
    return (
      <div className="p-4 flex justify-center items-center">
        <div className="spinner">Loading...</div>
      </div>
    );
  }

  // Tab change handler for bottom navigation
  const handleTabChange = (tab: TabNames | string) => {
    // Store the active tab in localStorage
    localStorage.setItem('activeTab', tab);
    // Navigate to home page
    setLocation('/');
  };

  return (
    <div className="min-h-screen p-2" id="case-detail-page">
      <div className="max-w-4xl mx-auto">
        {/* Header with back button */}
        <div className="flex items-center gap-2 mb-2">
          <button 
            className="bg-secondary-200 dark:bg-secondary-700 hover:bg-secondary-300 dark:hover:bg-secondary-600 text-secondary-800 dark:text-secondary-200 px-2 py-1 rounded text-sm flex items-center gap-1 transition-colors"
            onClick={() => {
              // Store the active tab as "cases" in localStorage
              localStorage.setItem('activeTab', 'cases');
              // Then navigate back to home
              setLocation('/');
            }}
          >
            <i className="fas fa-arrow-left text-xs"></i> Back
          </button>
          <h1 className="text-base font-semibold text-primary-700 dark:text-primary-400">{caseItem.title}</h1>
        </div>

        {/* Case responses */}
        <div className="bg-white dark:bg-gray-800 rounded border border-gray-200 dark:border-gray-700 p-3 transition-colors">
          <div className="flex justify-between items-center mb-2">
            <h2 className="text-sm font-medium text-gray-800 dark:text-gray-200">Responses</h2>
            <div className="flex items-center gap-1">
              <button 
                className={`text-xs py-1 px-2 rounded text-white ${isEditModeActive 
                  ? 'bg-primary-600 hover:bg-primary-700' 
                  : 'bg-primary-500 hover:bg-primary-600'}`}
                onClick={() => {
                  toggleEditMode();
                  setShowAddLineButtons(false);
                }}
              >
                <i className="fas fa-pencil-alt mr-1 text-[10px]"></i>
                {isEditModeActive ? 'Save' : 'Edit'}
              </button>
              <button 
                className={`text-xs py-1 px-2 rounded ${
                  showAddLineButtons 
                    ? 'bg-primary-600 hover:bg-primary-700 text-white' 
                    : 'bg-primary-500 hover:bg-primary-600 text-white'
                }`}
                onClick={() => {
                  setShowAddLineButtons(!showAddLineButtons);
                  setIsEditModeActive(false);
                  if (showAddLineButtons) {
                    showCopyNotification('Add Line mode disabled');
                  } else {
                    showCopyNotification('Click on a response to add a line below it');
                  }
                }}
              >
                <i className="fas fa-grip-lines mr-1 text-[10px]"></i>
                {showAddLineButtons ? 'Done' : 'Add Line'}
              </button>
              <button 
                className="bg-primary-500 hover:bg-primary-600 text-white py-1 px-2 rounded text-xs flex items-center gap-1"
                onClick={handleAddNewResponse}
              >
                <i className="fas fa-plus"></i> Add New
              </button>
            </div>
          </div>
          
          {caseItem.responses && caseItem.responses.length > 0 ? (
            <div className={`space-y-2 ${isEditModeActive ? 'edit-mode' : ''}`}>
              {caseItem.responses.map((response, index) => 
                response.type === 'line' ? (
                  <div 
                    key={response.id}
                    draggable={isEditModeActive}
                    onDragStart={(e) => handleDragStart(e, index)}
                    onDragEnter={(e) => handleDragEnter(e, index)}
                    onDragEnd={handleDragEnd}
                    onDragOver={(e) => e.preventDefault()}
                    className={`${isDragging && index === draggedItem ? 'dragging' : ''} case-response-item`}
                  >
                    <LineItemComponent
                      id={response.id}
                      category="cases"
                      isEditMode={isEditModeActive}
                      onDelete={() => {
                        if (window.confirm('Are you sure you want to delete this line?')) {
                          // Delete from context
                          deleteResponseFromCase(caseItem.id, response.id);
                          
                          // Also update local state
                          const updatedCase = {
                            ...caseItem,
                            responses: caseItem.responses.filter(r => r.id !== response.id)
                          };
                          setCaseItem(updatedCase);
                          
                          showCopyNotification('Line deleted successfully!');
                        }
                      }}
                    />
                  </div>
                ) : (
                  <div 
                    key={response.id} 
                    className="relative case-response-item"
                    draggable={isEditModeActive}
                    onDragStart={(e) => handleDragStart(e, index)}
                    onDragEnter={(e) => handleDragEnter(e, index)}
                    onDragEnd={handleDragEnd}
                    onDragOver={(e) => e.preventDefault()}
                  >
                    {/* Convert to full response */}
                    <ResponseItem 
                      response={{
                        id: response.id,
                        title: response.title || 'Response',
                        content: response.content,
                        contentEN: response.contentEN || '',
                        category: 'cases',
                        type: 'response'
                      }}
                      onShowNotification={showCopyNotification}
                      onOpenEditModal={(resp) => handleOpenEditModal(resp, index)}
                      onOpenTitleModal={() => {}}
                      onDelete={() => {
                        if (caseItem) {
                          // Delete from context
                          deleteResponseFromCase(caseItem.id, response.id);
                          
                          // Also update local state
                          const updatedCase = {
                            ...caseItem,
                            responses: caseItem.responses.filter(r => r.id !== response.id)
                          };
                          setCaseItem(updatedCase);
                          
                          // Show notification
                          showCopyNotification('Response deleted successfully!');
                        }
                      }}
                    />
                    
                    {!isEditModeActive && showAddLineButtons && (
                      <button 
                        className="add-line-button absolute right-2 top-1/2 -translate-y-1/2 bg-primary-500 hover:bg-primary-600 text-white text-xs py-1 px-2 rounded"
                        onClick={() => handleAddLine(response.id)}
                        title="Add line after this response"
                      >
                        <i className="fas fa-plus"></i>
                      </button>
                    )}
                  </div>
                )
              )}
            </div>
          ) : (
            <div className="text-center p-2 bg-gray-50 dark:bg-gray-700 rounded text-sm transition-colors">
              <p className="text-gray-600 dark:text-gray-400">No responses added to this case yet.</p>
            </div>
          )}
        </div>
      </div>

      {/* Copy Notification */}
      <CopyAlert show={showCopyAlert} text={alertText} />
      
      {/* Edit Modal */}
      <EditModal
        isOpen={editModalOpen}
        onClose={() => setEditModalOpen(false)}
        onSave={handleSaveEdit}
        title={editingResponse.title}
        content={editingResponse.content}
        contentEN={editingResponse.contentEN}
      />

      {/* Bottom Navigation - always visible */}
      <TabNavigation activeTab={TabNames.CASES} onChangeTab={handleTabChange} />
    </div>
  );
};

export default CaseDetailPage;