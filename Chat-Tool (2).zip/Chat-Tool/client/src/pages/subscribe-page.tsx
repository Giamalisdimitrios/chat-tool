import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Crown, Calendar, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function SubscribePage() {
  const { user, subscriptionStatus } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const handleSubscribe = async (isYearly: boolean) => {
    if (!process.env.VITE_STRIPE_PUBLIC_KEY) {
      toast({
        title: "Stripe not configured",
        description: "Payment system is not yet configured.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const priceId = isYearly 
        ? process.env.VITE_STRIPE_PRICE_ID_YEARLY 
        : process.env.VITE_STRIPE_PRICE_ID_MONTHLY;

      const response = await fetch("/api/create-subscription", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ priceId }),
      });

      const { clientSecret } = await response.json();

      if (clientSecret) {
        // Here you would integrate with Stripe Elements
        // For now, just show success
        toast({
          title: "Subscription initiated",
          description: "Payment process started successfully.",
        });
      }
    } catch (error) {
      toast({
        title: "Subscription failed",
        description: "There was an error starting your subscription.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const daysLeft = subscriptionStatus?.trialEndsAt 
    ? Math.max(0, Math.ceil((new Date(subscriptionStatus.trialEndsAt).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)))
    : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 to-primary-100 dark:from-gray-900 dark:to-gray-800 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-primary-900 dark:text-primary-100 mb-4">
            Επιλέξτε το πλάνο σας
          </h1>
          <p className="text-lg text-primary-700 dark:text-primary-300">
            Συνεχίστε να χρησιμοποιείτε το Chat Tool Pro με ένα από τα πλάνα μας
          </p>
          
          {subscriptionStatus?.subscriptionStatus === "trial" && (
            <div className="mt-4 inline-flex items-center space-x-2 bg-orange-100 dark:bg-orange-900 text-orange-800 dark:text-orange-200 px-4 py-2 rounded-full">
              <Calendar className="w-4 h-4" />
              <span>Δωρεάν δοκιμή: {daysLeft} μέρες απομένουν</span>
            </div>
          )}
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-3xl mx-auto">
          {/* Monthly Plan */}
          <Card className="relative">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Μηνιαίο Πλάνο</span>
                <Badge variant="secondary">Δημοφιλές</Badge>
              </CardTitle>
              <CardDescription>
                Ιδανικό για μικρές επιχειρήσεις
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-6">
                <span className="text-4xl font-bold text-primary-600">€1.99</span>
                <span className="text-primary-500">/μήνα</span>
              </div>
              
              <ul className="space-y-3 mb-6">
                <li className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>Απεριόριστες απαντήσεις</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>Συγχρονισμός σε όλες τις συσκευές</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>Προσαρμοσμένες κατηγορίες</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>Εξαγωγή/Εισαγωγή δεδομένων</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>Email υποστήριξη</span>
                </li>
              </ul>

              <Button 
                className="w-full" 
                onClick={() => handleSubscribe(false)}
                disabled={isLoading}
              >
                {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Επιλογή μηνιαίου πλάνου
              </Button>
            </CardContent>
          </Card>

          {/* Yearly Plan */}
          <Card className="relative border-primary-500 border-2">
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
              <Badge className="bg-primary-500 text-white px-4 py-1">
                <Crown className="w-3 h-3 mr-1" />
                Καλύτερη αξία
              </Badge>
            </div>
            
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Ετήσιο Πλάνο</span>
                <Badge variant="default" className="bg-green-500">-50%</Badge>
              </CardTitle>
              <CardDescription>
                2 μήνες δωρεάν!
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-6">
                <div>
                  <span className="text-4xl font-bold text-primary-600">€19.99</span>
                  <span className="text-primary-500">/χρόνο</span>
                </div>
                <div className="text-sm text-gray-500 mt-1">
                  <span className="line-through">€23.88</span> - Εξοικονομείτε €3.89
                </div>
              </div>
              
              <ul className="space-y-3 mb-6">
                <li className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>Όλα τα χαρακτηριστικά του μηνιαίου</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>2 μήνες δωρεάν</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>Προτεραιότητα υποστήριξης</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>Έκπτωση σε μελλοντικές αναβαθμίσεις</span>
                </li>
                <li className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>Χωρίς δεσμεύσεις</span>
                </li>
              </ul>

              <Button 
                className="w-full bg-primary-500 hover:bg-primary-600" 
                onClick={() => handleSubscribe(true)}
                disabled={isLoading}
              >
                {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Επιλογή ετήσιου πλάνου
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-8 text-sm text-gray-600 dark:text-gray-400">
          <p>
            Μπορείτε να ακυρώσετε οποιαδήποτε στιγμή. Χωρίς κρυφές χρεώσεις.
          </p>
          <p className="mt-2">
            Όλες οι πληρωμές επεξεργάζονται με ασφάλεια μέσω Stripe.
          </p>
        </div>
      </div>
    </div>
  );
}