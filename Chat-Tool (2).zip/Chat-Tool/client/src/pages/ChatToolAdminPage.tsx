import { useEffect } from 'react';
import { useLocation } from 'wouter';
import ChatToolApp from '@/components/ChatToolApp';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';

export default function ChatToolAdminPage() {
  useDocumentTitle('Chat Tool Admin');
  const [location, setLocation] = useLocation();

  useEffect(() => {
    if (location !== '/') {
      setLocation('/');
    }
  }, [location, setLocation]);

  return <ChatToolApp />;
}
