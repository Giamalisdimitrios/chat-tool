export const useCopyToClipboard = (onCopy: (text?: string) => void) => {
  const copyText = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      onCopy();
    } catch (err) {
      console.error('Failed to copy: ', err);
    }
  };

  const copyBasedOnTime = async (morningText: string, eveningText: string) => {
    const hour = new Date().getHours();
    const textToCopy = (hour >= 5 && hour < 17) ? morningText : eveningText;
    await copyText(textToCopy);
  };

  return { copyText, copyBasedOnTime };
};
