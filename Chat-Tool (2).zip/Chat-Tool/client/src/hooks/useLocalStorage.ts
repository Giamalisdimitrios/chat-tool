import { useState, useEffect } from 'react';

// Enhanced storage hook with dual storage support 
// (localStorage and sessionStorage as backup)
export function useLocalStorage<T>(key: string, initialValue: T): [T, (value: T | ((val: T) => T)) => void] {
  // Get data from storage (with fallback)
  const readValue = (): T => {
    // Prevent build error "window is undefined" but keep working
    if (typeof window === 'undefined') {
      return initialValue;
    }

    try {
      // First try localStorage
      const localItem = window.localStorage.getItem(key);
      
      if (localItem) {
        // If found in localStorage, also ensure it's in sessionStorage as backup
        try {
          window.sessionStorage.setItem(key, localItem);
        } catch (sessionError) {
          console.warn(`Error backing up to sessionStorage:`, sessionError);
        }
        return JSON.parse(localItem);
      }
      
      // If not in localStorage, try sessionStorage
      const sessionItem = window.sessionStorage.getItem(key);
      if (sessionItem) {
        console.log(`Retrieved from sessionStorage fallback for "${key}"`);
        // Restore to localStorage from sessionStorage
        try {
          window.localStorage.setItem(key, sessionItem);
        } catch (localError) {
          console.warn(`Error restoring to localStorage:`, localError);
        }
        return JSON.parse(sessionItem);
      }
      
      // If not found in either storage, return initial value
      return initialValue;
    } catch (error) {
      console.warn(`Error reading storage for key "${key}":`, error);
      return initialValue;
    }
  };

  // State to store our value
  // Pass initial state function to useState so logic is only executed once
  const [storedValue, setStoredValue] = useState<T>(readValue);

  // Return a wrapped version of useState's setter function that ...
  // ... persists the new value to both storage types.
  const setValue = (value: T | ((val: T) => T)) => {
    try {
      // Allow value to be a function so we have the same API as useState
      const valueToStore =
        value instanceof Function ? value(storedValue) : value;
      
      // Save to state
      setStoredValue(valueToStore);
      
      // Save to storage
      if (typeof window !== 'undefined') {
        const valueStr = JSON.stringify(valueToStore);
        console.log("Saving data to localStorage...", key);
        
        // Try saving to localStorage
        let localStorageSaveSuccessful = false;
        try {
          window.localStorage.setItem(key, valueStr);
          
          // Verify localStorage save was successful
          const savedLocalStr = window.localStorage.getItem(key);
          if (savedLocalStr === valueStr) {
            localStorageSaveSuccessful = true;
          } else {
            console.warn(`LocalStorage verification failed: saved value doesn't match for key "${key}"`);
          }
        } catch (localError) {
          console.error(`LocalStorage error for key "${key}":`, localError);
        }
        
        // Always try saving to sessionStorage as backup
        try {
          window.sessionStorage.setItem(key, valueStr);
          console.log(`Backup to sessionStorage for "${key}" completed`);
          
          // If localStorage failed but sessionStorage succeeded, log it
          if (!localStorageSaveSuccessful) {
            console.log(`Data saved to sessionStorage fallback for "${key}"`);
          }
        } catch (sessionError) {
          console.error(`SessionStorage error for key "${key}":`, sessionError);
        }
      }
    } catch (error) {
      console.warn(`Error setting storage for key "${key}":`, error);
    }
  };

  // Listen for changes to this key in localStorage from other tabs/windows
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === key && e.newValue) {
        try {
          // Update our state
          const newValue = JSON.parse(e.newValue);
          setStoredValue(newValue);
          
          // Ensure session storage is synced
          window.sessionStorage.setItem(key, e.newValue);
        } catch (error) {
          console.warn(`Error processing storage event for key "${key}":`, error);
        }
      }
    };
    
    // Add event listener
    window.addEventListener('storage', handleStorageChange);
    
    // Initial read
    setStoredValue(readValue());
    
    // Clean up
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [key]);

  return [storedValue, setValue];
}
