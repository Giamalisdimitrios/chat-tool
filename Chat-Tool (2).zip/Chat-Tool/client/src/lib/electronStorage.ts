import { ChatToolData } from '@/types';

// Add electron interface to window object
declare global {
  interface Window {
    electron?: {
      saveData: (data: any) => Promise<{ success: boolean, error?: string }>;
      loadData: () => Promise<{ success: boolean, data?: ChatToolData, error?: string }>;
    };
  }
}

// Check if running in Electron environment
export const isElectron = (): boolean => {
  return window.electron !== undefined;
};

// Save data to disk via Electron
export const saveDataToFileSystem = async (data: ChatToolData): Promise<boolean> => {
  if (!isElectron()) {
    console.log('Not running in Electron, skipping file system save');
    return false;
  }

  try {
    console.log('Saving data to file system...');
    const result = await window.electron!.saveData(data);
    if (result.success) {
      console.log('Data saved to file system successfully');
      return true;
    } else {
      console.error('Failed to save data to file system:', result.error);
      return false;
    }
  } catch (error) {
    console.error('Error saving data to file system:', error);
    return false;
  }
};

// Load data from disk via Electron
export const loadDataFromFileSystem = async (): Promise<ChatToolData | null> => {
  if (!isElectron()) {
    console.log('Not running in Electron, skipping file system load');
    return null;
  }

  try {
    console.log('Loading data from file system...');
    const result = await window.electron!.loadData();
    if (result.success && result.data) {
      console.log('Data loaded from file system successfully');
      return result.data;
    } else {
      console.error('Failed to load data from file system:', result.error);
      return null;
    }
  } catch (error) {
    console.error('Error loading data from file system:', error);
    return null;
  }
};