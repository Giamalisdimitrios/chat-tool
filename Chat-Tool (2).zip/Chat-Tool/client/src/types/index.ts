export interface Response {
  id: string;
  title: string;
  content: string;
  contentEN?: string;
  category: string;
  type?: 'response' | 'line';
}

export interface LineItem {
  id: string;
  type: 'line';
  category: string;
}

export interface Case {
  id: string;
  title: string;
  responses: {
    id: string;
    title?: string;
    content: string;
    contentEN?: string;
    type?: 'response' | 'line';
  }[];
}

export interface Category {
  id: string;
  title: string;
  customTab?: string; // For identifying the tab this category belongs to
  subcategories?: {
    id: string;
    title: string;
    responses: {
      id: string;
      title?: string;
      content: string;
      contentEN?: string;
      type?: 'response' | 'line';
    }[];
  }[];
  responses?: {
    id: string;
    title?: string;
    content: string;
    contentEN?: string;
    type?: 'response' | 'line';
  }[];
}

export interface ChatToolData {
  greeting: Response[];
  waiting: Response[];
  cases: Case[];
  closing: Response[];
  comments: Category[];
  tabsOrder: string[];
  activeTabs: string[];
  [key: string]: any; // Allow dynamic addition of custom tabs
}

export enum TabNames {
  GREETING = "greeting",
  WAITING = "waiting",
  CASES = "cases",
  CLOSING = "closing",
  COMMENTS = "comments",
  TABS_MANAGER = "tabs_manager"
}

export interface EditModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (title: string, content: string, contentEN: string) => void;
  title: string;
  content: string;
  contentEN: string;
}

export interface EditTitleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (title: string) => void;
  title: string;
}
