import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "next-themes";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import SubscribePage from "@/pages/subscribe-page";
import ChatToolAdminPage from "@/pages/ChatToolAdminPage";
import CaseDetailPage from "@/pages/CaseDetailPage";
import SubcategoryDetailPage from "@/pages/SubcategoryDetailPage";
import { ChatToolProvider } from "./contexts/ChatToolContext";
import WelcomeOverlay from "./components/WelcomeOverlay";

function Router() {
  return (
    <Switch>
      <ProtectedRoute path="/" component={ChatToolAdminPage} />
      <ProtectedRoute path="/case/:caseId" component={CaseDetailPage} />
      <ProtectedRoute path="/subcategory/:categoryId" component={SubcategoryDetailPage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/subscribe" component={SubscribePage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
        <TooltipProvider>
          <AuthProvider>
            <ChatToolProvider>
              <Toaster />
              <WelcomeOverlay />
              <Router />
            </ChatToolProvider>
          </AuthProvider>
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
