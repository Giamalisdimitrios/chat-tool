import { createContext, useContext, useReducer, useEffect, ReactNode } from 'react';
import { ChatToolData, Response, Case, Category, TabNames, LineItem } from '@/types';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { isElectron, saveDataToFileSystem, loadDataFromFileSystem } from '@/lib/electronStorage';
import { defaultData } from '../data/defaultData';
import { useAuth } from '@/hooks/use-auth';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

// Create context
interface ChatToolContextProps {
  state: ChatToolData;
  addResponse: (response: Response) => void;
  updateResponse: (response: Response) => void;
  deleteResponse: (id: string, category: string) => void;
  updateResponseTitle: (id: string, title: string, category: string) => void;
  addCase: (caseItem: Case) => void;
  updateCase: (caseItem: Case) => void;
  deleteCase: (id: string) => void;
  addResponseToCase: (caseId: string, response: { id: string; title?: string; content: string; contentEN?: string; type?: 'response' | 'line' }) => void;
  deleteResponseFromCase: (caseId: string, responseId: string) => void;
  updateCaseResponsesOrder: (caseId: string, newOrder: string[]) => void;
  updateCasesOrder: (newOrder: string[]) => void;
  addCategory: (category: Category) => void;
  updateCategory: (category: Category) => void;
  deleteCategory: (id: string, customTab?: string) => void;
  addSubcategory: (categoryId: string, subcategory: { id: string; title: string; responses: any[] }, customTab?: string) => void;
  addLine: (category: string, afterResponseId: string) => void;
  updateResponsesOrder: (category: string, newOrder: string[]) => void;
  updateTabsOrder: (newOrder: string[]) => void;
  updateActiveTabs: (activeTabs: string[]) => void;
  addCustomTab: (tabId: string, tabType: string, tabName: string) => void;
  exportData: () => void;
  importData: (fileData: ChatToolData) => boolean;
}

const ChatToolContext = createContext<ChatToolContextProps | undefined>(undefined);

type Action = 
  | { type: 'SET_DATA'; payload: ChatToolData }
  | { type: 'IMPORT_DATA'; payload: ChatToolData }
  | { type: 'ADD_RESPONSE'; payload: Response }
  | { type: 'UPDATE_RESPONSE'; payload: Response }
  | { type: 'DELETE_RESPONSE'; payload: { id: string; category: string } }
  | { type: 'UPDATE_RESPONSE_TITLE'; payload: { id: string; title: string; category: string } }
  | { type: 'ADD_CASE'; payload: Case }
  | { type: 'UPDATE_CASE'; payload: Case }
  | { type: 'DELETE_CASE'; payload: string }
  | { type: 'ADD_RESPONSE_TO_CASE'; payload: { caseId: string; response: { id: string; title?: string; content: string; contentEN?: string; type?: 'response' | 'line' } } }
  | { type: 'DELETE_RESPONSE_FROM_CASE'; payload: { caseId: string; responseId: string } }
  | { type: 'UPDATE_CASE_RESPONSES_ORDER'; payload: { caseId: string; newOrder: string[] } }
  | { type: 'ADD_CATEGORY'; payload: Category }
  | { type: 'UPDATE_CATEGORY'; payload: Category }
  | { type: 'DELETE_CATEGORY'; payload: string | { id: string; customTab: string } }
  | { type: 'ADD_SUBCATEGORY'; payload: { categoryId: string; subcategory: { id: string; title: string; responses: any[] }; customTab?: string } }
  | { type: 'ADD_LINE'; payload: { category: string; afterResponseId: string } }
  | { type: 'UPDATE_RESPONSES_ORDER'; payload: { category: string; newOrder: string[] } }
  | { type: 'UPDATE_CASES_ORDER'; payload: string[] }
  | { type: 'UPDATE_TABS_ORDER'; payload: string[] }
  | { type: 'UPDATE_ACTIVE_TABS'; payload: string[] }
  | { type: 'ADD_CUSTOM_TAB'; payload: { tabId: string; tabType: string; tabName: string } };

// Reducer function
const chatToolReducer = (state: ChatToolData, action: Action): ChatToolData => {
  // Create a deep copy of state to avoid direct mutations
  let stateCopy = JSON.parse(JSON.stringify(state));
  
  switch (action.type) {
    case 'SET_DATA':
      return action.payload;
      
    case 'IMPORT_DATA':
      return action.payload;
      
    case 'UPDATE_TABS_ORDER':
      return { ...stateCopy, tabsOrder: action.payload };
      
    case 'UPDATE_ACTIVE_TABS':
      return { ...stateCopy, activeTabs: action.payload };
      
    case 'ADD_CUSTOM_TAB': {
      const { tabId, tabType, tabName } = action.payload;
      
      // Create the new tab in state
      if (tabType === 'normal') {
        stateCopy[tabId] = []; // For normal tabs, we have an array of responses
      } else if (tabType === 'subcategories') {
        stateCopy[tabId] = []; // For subcategories tabs, we need an array of categories
      }
      
      // Update the active tabs
      if (!stateCopy.activeTabs.includes(tabId)) {
        stateCopy.activeTabs = [...stateCopy.activeTabs, tabId];
      }
      
      // Update the tabs order if needed
      if (!stateCopy.tabsOrder.includes(tabId)) {
        stateCopy.tabsOrder = [...stateCopy.tabsOrder, tabId];
      }
      
      return stateCopy;
    }
      
    case 'ADD_RESPONSE': {
      const category = action.payload.category;
      
      // Make sure the category array exists
      if (!stateCopy[category]) {
        stateCopy[category] = [];
      }
      
      // Add the response to the appropriate category array
      return {
        ...stateCopy,
        [category]: [...stateCopy[category as keyof ChatToolData] as Response[], action.payload]
      };
    }
      
    case 'UPDATE_RESPONSE': {
      const category = action.payload.category;
      
      // Make sure the category array exists
      if (!stateCopy[category]) {
        stateCopy[category] = [];
        return stateCopy; // No need to proceed if array didn't exist
      }
      
      const updatedResponses = (stateCopy[category as keyof ChatToolData] as Response[]).map(
        response => response.id === action.payload.id ? action.payload : response
      );
      
      return {
        ...stateCopy,
        [category]: updatedResponses
      };
    }
      
    case 'DELETE_RESPONSE': {
      const { id, category } = action.payload;
      
      // Make sure the category array exists
      if (!stateCopy[category]) {
        stateCopy[category] = [];
        return stateCopy; // No need to proceed if array didn't exist
      }
      
      const updatedResponses = (stateCopy[category as keyof ChatToolData] as Response[]).filter(
        response => response.id !== id
      );
      
      return {
        ...stateCopy,
        [category]: updatedResponses
      };
    }
      
    case 'UPDATE_RESPONSE_TITLE': {
      const { id, title, category } = action.payload;
      
      // Make sure the category array exists
      if (!stateCopy[category]) {
        stateCopy[category] = [];
        return stateCopy; // No need to proceed if array didn't exist
      }
      
      const updatedResponses = (stateCopy[category as keyof ChatToolData] as Response[]).map(
        response => response.id === id ? { ...response, title } : response
      );
      
      return {
        ...stateCopy,
        [category]: updatedResponses
      };
    }
      
    case 'ADD_CASE':
      return {
        ...state,
        cases: [...state.cases, action.payload]
      };
      
    case 'UPDATE_CASE': {
      const updatedCases = state.cases.map(
        caseItem => caseItem.id === action.payload.id ? action.payload : caseItem
      );
      return {
        ...state,
        cases: updatedCases
      };
    }
      
    case 'DELETE_CASE': {
      const updatedCases = state.cases.filter(caseItem => caseItem.id !== action.payload);
      return {
        ...state,
        cases: updatedCases
      };
    }
      
    case 'ADD_RESPONSE_TO_CASE': {
      const { caseId, response } = action.payload;
      const updatedCases = state.cases.map(caseItem => {
        if (caseItem.id === caseId) {
          return {
            ...caseItem,
            responses: [...caseItem.responses, response]
          };
        }
        return caseItem;
      });
      return {
        ...state,
        cases: updatedCases
      };
    }
      
    case 'DELETE_RESPONSE_FROM_CASE': {
      const { caseId, responseId } = action.payload;
      const updatedCases = state.cases.map(caseItem => {
        if (caseItem.id === caseId) {
          return {
            ...caseItem,
            responses: caseItem.responses.filter(response => response.id !== responseId)
          };
        }
        return caseItem;
      });
      return {
        ...state,
        cases: updatedCases
      };
    }
      
    case 'UPDATE_CASE_RESPONSES_ORDER': {
      const { caseId, newOrder } = action.payload;
      const updatedCases = state.cases.map(caseItem => {
        if (caseItem.id === caseId) {
          // Create a map of responses by id for quick lookup
          const responsesMap = caseItem.responses.reduce((map, response) => {
            map[response.id] = response;
            return map;
          }, {} as Record<string, any>);
          
          // Create a new array with the updated order
          const updatedResponses = newOrder.map(id => responsesMap[id]);
          
          return {
            ...caseItem,
            responses: updatedResponses
          };
        }
        return caseItem;
      });
      
      return {
        ...state,
        cases: updatedCases
      };
    }
      
    case 'ADD_CATEGORY': {
      // Check if we have a custom subcategory tab active
      if (action.payload.customTab && typeof action.payload.customTab === 'string') {
        const customTab = action.payload.customTab;
        // Make sure the custom tab array exists
        if (!stateCopy[customTab]) {
          stateCopy[customTab] = [];
        }
        
        // Remove the temporary customTab property before saving
        const { customTab: _, ...categoryToSave } = action.payload;
        
        return {
          ...stateCopy,
          [customTab]: [...(stateCopy[customTab] as any[]), categoryToSave]
        };
      }
      
      // Default behavior - add to comments
      return {
        ...stateCopy,
        comments: [...stateCopy.comments, action.payload]
      };
    }
      
    case 'UPDATE_CATEGORY': {
      // Check if this category belongs to a custom tab
      if (action.payload.customTab && typeof action.payload.customTab === 'string') {
        const customTab = action.payload.customTab;
        if (!stateCopy[customTab]) {
          console.error(`Custom tab ${customTab} not found`);
          return state;
        }
        
        const updatedCategories = stateCopy[customTab].map(
          category => category.id === action.payload.id ? action.payload : category
        );
        
        return {
          ...stateCopy,
          [customTab]: updatedCategories
        };
      }
      
      // Default behavior - update in comments
      const updatedCategories = stateCopy.comments.map(
        category => category.id === action.payload.id ? action.payload : category
      );
      return {
        ...stateCopy,
        comments: updatedCategories
      };
    }
      
    case 'DELETE_CATEGORY': {
      // For custom tabs, we need both the id and the tab name
      if (typeof action.payload === 'object' && action.payload.customTab) {
        const { id, customTab } = action.payload;
        
        if (!stateCopy[customTab]) {
          console.error(`Custom tab ${customTab} not found`);
          return state;
        }
        
        const updatedCategories = stateCopy[customTab].filter(category => category.id !== id);
        
        return {
          ...stateCopy,
          [customTab]: updatedCategories
        };
      }
      
      // Default behavior - remove from comments
      const updatedCategories = stateCopy.comments.filter(category => category.id !== action.payload);
      return {
        ...stateCopy,
        comments: updatedCategories
      };
    }
      
    case 'ADD_SUBCATEGORY': {
      const { categoryId, subcategory, customTab } = action.payload;
      
      // Handle custom tabs with subcategories
      if (customTab && typeof customTab === 'string') {
        if (!stateCopy[customTab]) {
          console.error(`Custom tab ${customTab} not found for ADD_SUBCATEGORY`);
          return state;
        }
        
        const updatedCategories = stateCopy[customTab].map((category: Category) => {
          if (category.id === categoryId) {
            return {
              ...category,
              subcategories: [...(category.subcategories || []), subcategory]
            };
          }
          return category;
        });
        
        return {
          ...stateCopy,
          [customTab]: updatedCategories
        };
      }
      
      // Default behavior - add to comments
      const updatedCategories = stateCopy.comments.map((category: Category) => {
        if (category.id === categoryId) {
          return {
            ...category,
            subcategories: [...(category.subcategories || []), subcategory]
          };
        }
        return category;
      });
      
      return {
        ...stateCopy,
        comments: updatedCategories
      };
    }
    
    case 'ADD_LINE': {
      const { category, afterResponseId } = action.payload;
      
      // Make sure the category array exists
      if (!stateCopy[category]) {
        stateCopy[category] = [];
        return stateCopy;
      }
      
      const responses = stateCopy[category as keyof ChatToolData] as Response[];
      
      // Find the index of the response after which the line will be added
      const index = responses.findIndex(response => response.id === afterResponseId);
      
      if (index === -1) {
        return stateCopy;
      }
      
      // Create a line item
      const lineItem: Response = {
        id: `line-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        title: '',
        content: '',
        category,
        type: 'line'
      };
      
      // Insert the line after the specified response
      const updatedResponses = [
        ...responses.slice(0, index + 1),
        lineItem,
        ...responses.slice(index + 1)
      ];
      
      return {
        ...stateCopy,
        [category]: updatedResponses
      };
    }
    
    case 'UPDATE_RESPONSES_ORDER': {
      const { category, newOrder } = action.payload;
      
      // Make sure the category array exists
      if (!stateCopy[category]) {
        stateCopy[category] = [];
        return stateCopy;
      }
      
      const responses = stateCopy[category as keyof ChatToolData] as Response[];
      
      // Create a map of responses by id for quick lookup
      const responsesMap = responses.reduce((map, response) => {
        map[response.id] = response;
        return map;
      }, {} as Record<string, Response>);
      
      // Create a new array with the updated order
      const updatedResponses = newOrder.map(id => responsesMap[id]).filter(Boolean); // Filter out any undefined values
      
      return {
        ...stateCopy,
        [category]: updatedResponses
      };
    }
    
    case 'UPDATE_CASES_ORDER': {
      const newOrder = action.payload;
      
      // Create a map of cases by id for quick lookup
      const casesMap = state.cases.reduce((map, caseItem) => {
        map[caseItem.id] = caseItem;
        return map;
      }, {} as Record<string, Case>);
      
      // Create a new array with the updated order
      const updatedCases = newOrder.map(id => casesMap[id]);
      
      return {
        ...state,
        cases: updatedCases
      };
    }
      
    default:
      return state;
  }
};

// Provider component
interface ChatToolProviderProps {
  children: ReactNode;
}

export const ChatToolProvider = ({ children }: ChatToolProviderProps) => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [storedData, setStoredData] = useLocalStorage<ChatToolData>('chatToolData', defaultData);
  const [state, dispatch] = useReducer(chatToolReducer, defaultData);

  // Fetch chat data from server if authenticated
  const { data: serverData, isLoading } = useQuery({
    queryKey: ['/api/chat-data'],
    enabled: !!user, // Only fetch if user is authenticated
    refetchOnWindowFocus: false,
  });

  // Mutation to save data to server
  const saveDataMutation = useMutation({
    mutationFn: async (data: ChatToolData) => {
      const response = await apiRequest('POST', '/api/chat-data', data);
      return response.json();
    },
    onError: (error) => {
      console.error('Failed to save data to server:', error);
    },
  });

  // Initialize data based on authentication status
  useEffect(() => {
    const initializeData = async () => {
      if (user && serverData) {
        // User is authenticated and server data is available
        console.log('Loading data from server:', serverData);
        dispatch({ type: 'SET_DATA', payload: serverData });
      } else if (user && !isLoading) {
        // User is authenticated but no server data (first time)
        console.log('No server data found, using default data');
        dispatch({ type: 'SET_DATA', payload: defaultData });
      } else if (!user) {
        // Not authenticated - check if running in Electron
        if (isElectron()) {
          console.log('Running in Electron environment, loading data from file system...');
          try {
            const fileData = await loadDataFromFileSystem();
            if (fileData) {
              console.log('Data loaded from Electron filesystem');
              dispatch({ type: 'SET_DATA', payload: fileData });
            } else {
              console.log('No data found in Electron filesystem, initializing with default data');
              dispatch({ type: 'SET_DATA', payload: defaultData });
            }
          } catch (error) {
            console.error('Error loading data from Electron filesystem:', error);
            dispatch({ type: 'SET_DATA', payload: defaultData });
          }
        } else {
          // Browser without authentication - use localStorage for demo
          console.log('Browser demo mode, using localStorage');
          if (storedData && Object.keys(storedData).length > 0) {
            dispatch({ type: 'SET_DATA', payload: storedData });
          } else {
            dispatch({ type: 'SET_DATA', payload: defaultData });
          }
        }
      }
    };

    initializeData();
  }, [user, serverData, isLoading]);

  // Save data based on authentication status
  useEffect(() => {
    const saveData = async () => {
      // Skip initial save or empty state
      if (Object.keys(state).length === 0) return;

      if (user) {
        // User is authenticated - save to server
        console.log('Saving data to server...');
        saveDataMutation.mutate(state);
      } else if (isElectron()) {
        // Electron without authentication - save to filesystem
        console.log('Saving data to Electron filesystem...');
        await saveDataToFileSystem(state);
      } else {
        // Browser without authentication - save to localStorage
        console.log('Saving data to localStorage...');
        setStoredData(state);
      }
    };

    // Debounce saves to avoid too frequent API calls
    const timeoutId = setTimeout(saveData, 1000);
    return () => clearTimeout(timeoutId);
  }, [state, user, saveDataMutation, setStoredData]);

  // Action creators
  const addResponse = (response: Response) => {
    dispatch({ type: 'ADD_RESPONSE', payload: response });
  };

  const updateResponse = (response: Response) => {
    dispatch({ type: 'UPDATE_RESPONSE', payload: response });
  };

  const deleteResponse = (id: string, category: string) => {
    dispatch({ type: 'DELETE_RESPONSE', payload: { id, category } });
  };

  const updateResponseTitle = (id: string, title: string, category: string) => {
    dispatch({ type: 'UPDATE_RESPONSE_TITLE', payload: { id, title, category } });
  };

  const addCase = (caseItem: Case) => {
    dispatch({ type: 'ADD_CASE', payload: caseItem });
  };
  
  const addCustomTab = (tabId: string, tabType: string, tabName: string) => {
    dispatch({ 
      type: 'ADD_CUSTOM_TAB', 
      payload: { tabId, tabType, tabName } 
    });
  };

  const updateCase = (caseItem: Case) => {
    dispatch({ type: 'UPDATE_CASE', payload: caseItem });
  };

  const deleteCase = (id: string) => {
    dispatch({ type: 'DELETE_CASE', payload: id });
  };

  const addResponseToCase = (caseId: string, response: { id: string; title?: string; content: string; contentEN?: string; type?: 'response' | 'line' }) => {
    dispatch({ type: 'ADD_RESPONSE_TO_CASE', payload: { caseId, response } });
  };

  const deleteResponseFromCase = (caseId: string, responseId: string) => {
    try {
      // First perform action in state
      dispatch({ type: 'DELETE_RESPONSE_FROM_CASE', payload: { caseId, responseId } });
      
      // Then manually force the update to localStorage for extra safety
      if (!isElectron() && typeof window !== 'undefined') {
        // Find updated case data
        const updatedCase = state.cases.find(c => c.id === caseId);
        if (updatedCase) {
          // Get current data from localStorage
          const currentData = window.localStorage.getItem('chatToolData');
          if (currentData) {
            const parsedData = JSON.parse(currentData);
            // Update specific case
            const updatedCases = parsedData.cases.map((c: Case) => {
              if (c.id === caseId) {
                return {
                  ...c,
                  responses: c.responses.filter(r => r.id !== responseId)
                };
              }
              return c;
            });
            
            // Update localStorage directly
            const updatedData = { ...parsedData, cases: updatedCases };
            console.log("Directly updating localStorage after case response deletion:", updatedData);
            window.localStorage.setItem('chatToolData', JSON.stringify(updatedData));
          }
        }
      }
    } catch (error) {
      console.error("Error in deleteResponseFromCase:", error);
    }
  };
  
  const updateCaseResponsesOrder = (caseId: string, newOrder: string[]) => {
    dispatch({ type: 'UPDATE_CASE_RESPONSES_ORDER', payload: { caseId, newOrder } });
  };

  const addCategory = (category: Category) => {
    dispatch({ type: 'ADD_CATEGORY', payload: category });
  };

  const updateCategory = (category: Category) => {
    dispatch({ type: 'UPDATE_CATEGORY', payload: category });
  };

  const deleteCategory = (id: string, customTab?: string) => {
    if (customTab) {
      dispatch({ 
        type: 'DELETE_CATEGORY', 
        payload: { id, customTab } 
      });
    } else {
      dispatch({ type: 'DELETE_CATEGORY', payload: id });
    }
  };

  const addSubcategory = (
    categoryId: string, 
    subcategory: { id: string; title: string; responses: any[] },
    customTab?: string
  ) => {
    dispatch({ 
      type: 'ADD_SUBCATEGORY', 
      payload: { categoryId, subcategory, customTab } 
    });
  };
  
  const addLine = (category: string, afterResponseId: string) => {
    dispatch({ type: 'ADD_LINE', payload: { category, afterResponseId } });
  };
  
  const updateResponsesOrder = (category: string, newOrder: string[]) => {
    dispatch({ type: 'UPDATE_RESPONSES_ORDER', payload: { category, newOrder } });
  };
  
  const updateCasesOrder = (newOrder: string[]) => {
    dispatch({ type: 'UPDATE_CASES_ORDER', payload: newOrder });
  };

  // Export functionality
  const exportData = () => {
    try {
      console.log("Exporting data:", state);
      
      // Create a clean copy of the state to export
      const dataToExport = {
        greeting: state.greeting || [],
        waiting: state.waiting || [],
        cases: state.cases || [],
        closing: state.closing || [],
        comments: state.comments || [],
        tabsOrder: state.tabsOrder || ["greeting", "waiting", "cases", "closing", "comments"],
        activeTabs: state.activeTabs || ["greeting", "waiting", "cases", "closing"]
      };
      
      console.log("Data prepared for export:", dataToExport);
      
      // In Electron, the data is already saved to the filesystem automatically
      // so we'll just show a notification or message
      if (isElectron()) {
        console.log("In Electron environment, data is already saved to file system");
        // You could add a notification here if needed
        alert("Data is automatically saved to file system in this desktop application.");
        
        // Optionally, force a save to ensure latest data is persisted
        saveDataToFileSystem(dataToExport as ChatToolData);
      } else {
        // Browser environment - download as file
        const jsonString = JSON.stringify(dataToExport, null, 2);
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(jsonString);
        
        const downloadAnchorNode = document.createElement('a');
        downloadAnchorNode.setAttribute("href", dataStr);
        downloadAnchorNode.setAttribute("download", "chat_responses.json");
        document.body.appendChild(downloadAnchorNode);
        downloadAnchorNode.click();
        downloadAnchorNode.remove();
      }
      
      console.log("Export completed successfully");
    } catch (error) {
      console.error("Error during export:", error);
    }
  };
  
  // Import functionality
  const importData = (fileData: ChatToolData) => {
    try {
      console.log("Attempting to import data:", fileData);
      
      // Validate the structure of fileData
      if (!fileData || typeof fileData !== 'object') {
        console.error('Invalid data format: Not an object');
        return false;
      }
      
      // Make sure all required properties exist and are arrays
      const requiredProperties = ['greeting', 'waiting', 'cases', 'closing', 'comments'];
      for (const prop of requiredProperties) {
        if (!fileData[prop as keyof ChatToolData]) {
          console.error(`Missing required property: ${prop}`);
          return false;
        }
        
        if (!Array.isArray(fileData[prop as keyof ChatToolData])) {
          console.error(`Property ${prop} is not an array`);
          return false;
        }
      }
      
      // Create a clean copy of the data to import
      const cleanData: ChatToolData = {
        greeting: [...fileData.greeting],
        waiting: [...fileData.waiting],
        cases: [...fileData.cases],
        closing: [...fileData.closing],
        comments: [...fileData.comments],
        tabsOrder: fileData.tabsOrder || ["greeting", "waiting", "cases", "closing", "comments"],
        activeTabs: fileData.activeTabs || ["greeting", "waiting", "cases", "closing"]
      };
      
      console.log("Clean data prepared for import:", cleanData);
      
      // Dispatch the import action
      dispatch({ type: 'IMPORT_DATA', payload: cleanData });
      
      console.log("Import dispatched successfully");
      
      // Force a state update by setting data again
      setTimeout(() => {
        console.log("Forcing state refresh after import");
        dispatch({ type: 'SET_DATA', payload: cleanData });
      }, 100);
      
      return true;
    } catch (error) {
      console.error('Failed to import data:', error);
      return false;
    }
  };

  // Function to update tabs order
  const updateTabsOrder = (newOrder: string[]) => {
    dispatch({ type: 'UPDATE_TABS_ORDER', payload: newOrder });
  };

  // Function to update active tabs
  const updateActiveTabs = (activeTabs: string[]) => {
    dispatch({ type: 'UPDATE_ACTIVE_TABS', payload: activeTabs });
  };

  return (
    <ChatToolContext.Provider value={{
      state,
      addResponse,
      updateResponse,
      deleteResponse,
      updateResponseTitle,
      addCase,
      updateCase,
      deleteCase,
      addResponseToCase,
      deleteResponseFromCase,
      updateCaseResponsesOrder,
      updateCasesOrder,
      addCategory,
      updateCategory,
      deleteCategory,
      addSubcategory,
      addLine,
      updateResponsesOrder,
      updateTabsOrder,
      updateActiveTabs,
      addCustomTab,
      exportData,
      importData
    }}>
      {children}
    </ChatToolContext.Provider>
  );
};

// Custom hook to use the context
export const useChatTool = () => {
  const context = useContext(ChatToolContext);
  if (context === undefined) {
    throw new Error('useChatTool must be used within a ChatToolProvider');
  }
  return context;
};