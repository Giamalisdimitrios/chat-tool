import { useState } from 'react';
import { useChatTool } from '@/contexts/ChatToolContext';
import { TabNames, Category } from '@/types';
import { v4 as uuidv4 } from 'uuid';
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import CategoryItem from './CategoryItem';

interface CategoryManagerProps {
  activeTab: TabNames | string;
}

const CategoryManager: React.FC<CategoryManagerProps> = ({ activeTab }) => {
  const { state, addCategory, deleteCategory } = useChatTool();
  const [isEditing, setIsEditing] = useState(false);

  // Toggle edit mode
  const toggleEditMode = () => {
    setIsEditing(!isEditing);
  };

  // Function to get the display name for the current tab
  const getTabDisplayName = () => {
    if (activeTab === TabNames.COMMENTS) {
      return 'Comments';
    }
    
    if (typeof activeTab === 'string' && activeTab.startsWith('custom_')) {
      // For custom tabs, get the name from localStorage
      return localStorage.getItem(`tab_name_${activeTab}`) || activeTab.replace('custom_', '');
    }
    
    return 'Category';
  };

  // Handler for adding a new normal page
  const handleAddNormalPage = () => {
    const tabName = getTabDisplayName();
    const newPageTitle = prompt(`Εισάγετε τίτλο για τη νέα κατηγορία στο "${tabName}":`);
    if (newPageTitle && newPageTitle.trim() !== '') {
      const newCategory: Category = {
        id: `category-${Date.now()}-${uuidv4().slice(0, 8)}`,
        title: newPageTitle.trim(),
        subcategories: []
      };
      
      // If it's a built-in tab (comments)
      if (activeTab === TabNames.COMMENTS) {
        addCategory(newCategory);
      }
      // For custom tabs
      else if (typeof activeTab === 'string' && activeTab.startsWith('custom_')) {
        // Add customTab property to the new category
        addCategory({
          ...newCategory,
          customTab: activeTab
        });
      }
    }
  };

  // Handler for adding a page with subcategories
  const handleAddPageWithSubcategories = () => {
    const tabName = getTabDisplayName();
    const newPageTitle = prompt(`Εισάγετε τίτλο για τη νέα κατηγορία με υποκατηγορίες στο "${tabName}":`);
    if (newPageTitle && newPageTitle.trim() !== '') {
      const newCategory: Category = {
        id: `category-${Date.now()}-${uuidv4().slice(0, 8)}`,
        title: newPageTitle.trim(),
        subcategories: []
      };
      
      // If it's a built-in tab (comments)
      if (activeTab === TabNames.COMMENTS) {
        addCategory(newCategory);
      }
      // For custom tabs
      else if (typeof activeTab === 'string' && activeTab.startsWith('custom_')) {
        // Add customTab property to the new category
        addCategory({
          ...newCategory,
          customTab: activeTab
        });
      }
    }
  };

  return (
    <div className="category-manager">
      {/* Floating edit button - only show in comments tab */}
      {activeTab === TabNames.COMMENTS && (
        <Popover>
          <PopoverTrigger asChild>
            <button 
              className="category-manager-button"
              onClick={toggleEditMode}
              style={{
                position: 'fixed',
                bottom: '20px',
                right: '20px',
                width: '40px',
                height: '40px',
                borderRadius: '50%',
                backgroundColor: isEditing ? '#ff4757' : '#f1f2f6',
                boxShadow: '0 2px 5px rgba(0, 0, 0, 0.2)',
                border: 'none',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                zIndex: 1000,
                transition: 'background-color 0.3s ease'
              }}
            >
              <i className={`fas ${isEditing ? 'fa-times' : 'fa-pencil-alt'}`} style={{ color: isEditing ? 'white' : '#2f3542' }}></i>
            </button>
          </PopoverTrigger>
          <PopoverContent className="p-2" side="top">
            <div className="flex flex-col gap-2">
              <button
                onClick={handleAddNormalPage}
                className="w-full text-left px-3 py-2 text-sm hover:bg-gray-100 rounded"
              >
                <i className="fas fa-file-alt mr-2"></i> Νέα Σελίδα
              </button>
              <button
                onClick={handleAddPageWithSubcategories}
                className="w-full text-left px-3 py-2 text-sm hover:bg-gray-100 rounded"
              >
                <i className="fas fa-folder-plus mr-2"></i> Σελίδα με Υποκατηγορίες
              </button>
            </div>
          </PopoverContent>
        </Popover>
      )}

      {/* Display categories for this tab */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 mt-4">
        {/* Show categories for the current tab */}
        {activeTab === TabNames.COMMENTS && state.comments && 
          state.comments.map((category) => (
            <CategoryItem 
              key={category.id} 
              category={category} 
              onShowNotification={(text) => alert(text || 'Action completed')} 
              onOpenTitleModal={(category) => {}}
            />
          ))
        }
        
        {/* For custom tabs */}
        {typeof activeTab === 'string' && 
          activeTab.startsWith('custom_') && 
          state[activeTab] && 
          Array.isArray(state[activeTab]) &&
          state[activeTab].map((category) => (
            <CategoryItem 
              key={category.id} 
              category={{...category, customTab: activeTab}} 
              onShowNotification={(text) => alert(text || 'Action completed')} 
              onOpenTitleModal={(category) => {}}
            />
          ))
        }
        
        {/* Show empty state if no categories */}
        {((activeTab === TabNames.COMMENTS && (!state.comments || state.comments.length === 0)) ||
          (typeof activeTab === 'string' && 
           activeTab.startsWith('custom_') && 
           (!state[activeTab] || !Array.isArray(state[activeTab]) || state[activeTab].length === 0))) && (
          <div className="col-span-full text-center py-8 text-gray-500">
            <p>No categories yet. Use the buttons to create one.</p>
          </div>
        )}
      </div>

      {/* This mode state will be used by other components to show/hide delete buttons */}
      <div className={`category-manager-mode-${isEditing ? 'edit' : 'view'}`} 
           style={{ display: 'none' }}></div>
           
      <style>{`
        .category-delete-button {
          display: ${isEditing ? 'flex' : 'none'};
          position: absolute;
          right: -10px;
          top: -10px;
          width: 24px;
          height: 24px;
          background-color: #ff4757;
          color: white;
          border-radius: 50%;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          cursor: pointer;
          border: none;
          z-index: 5;
        }
      `}</style>
    </div>
  );
};

export default CategoryManager;