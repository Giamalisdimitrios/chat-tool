import { useState, useEffect, useRef } from 'react';
import { useChatTool } from '@/contexts/ChatToolContext';

const TAB_NAMES: Record<string, string> = {
  greeting: "Άνοιγμα",
  waiting: "Αναμονή",
  cases: "Cases",
  closing: "Κλείσιμο",
  comments: "Σχόλια",
  tabs_manager: "Ρυθμίσεις"
};

const TAB_ICONS: Record<string, string> = {
  greeting: "fas fa-comment-dots",
  waiting: "fas fa-clock",
  cases: "fas fa-briefcase",
  closing: "fas fa-check-circle",
  comments: "fas fa-comment",
  tabs_manager: "fas fa-cogs"
};

// Βασικές επιλογές εικονιδίων
const AVAILABLE_ICONS = [
  { name: "Άνοιγμα", class: "fas fa-comment-dots" },
  { name: "Αναμονή", class: "fas fa-clock" },
  { name: "Cases", class: "fas fa-briefcase" },
  { name: "Κλείσιμο", class: "fas fa-check-circle" },
  { name: "List", class: "fas fa-list" },
  { name: "Folder", class: "fas fa-folder" },
  { name: "Star", class: "fas fa-star" },
  { name: "Heart", class: "fas fa-heart" },
  { name: "Bell", class: "fas fa-bell" },
  { name: "Book", class: "fas fa-book" }
];

const TabsManager = () => {
  const { state, updateTabsOrder, updateActiveTabs, addCustomTab } = useChatTool();
  
  const [visibleTabs, setVisibleTabs] = useState<string[]>([]);
  const [originalTabs, setOriginalTabs] = useState<string[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [showNewTabModal, setShowNewTabModal] = useState(false);
  const [newTabType, setNewTabType] = useState<'normal' | 'subcategories'>('normal');
  const [newTabName, setNewTabName] = useState('');
  const [hasChanges, setHasChanges] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  
  // State για το modal επεξεργασίας καρτέλας
  const [showEditTabModal, setShowEditTabModal] = useState(false);
  const [editingTab, setEditingTab] = useState<string | null>(null);
  const [editTabName, setEditTabName] = useState('');
  const [editTabIcon, setEditTabIcon] = useState('');

  // Initialize tabs when component mounts
  useEffect(() => {
    // Get active tabs from state or use defaults
    const active = state.activeTabs && state.activeTabs.length > 0
      ? state.activeTabs
      : ["greeting", "waiting", "cases", "closing"];
    
    setVisibleTabs(active);
    // Αποθήκευση των αρχικών τιμών για περίπτωση ακύρωσης
    setOriginalTabs([...active]);
  }, [state.tabsOrder, state.activeTabs]);

  // Drag and drop handlers for manual implementation
  const dragItem = useRef<number | null>(null);
  const dragOverItem = useRef<number | null>(null);
  
  // Handle drag start for visible tabs
  const handleVisibleDragStart = (position: number) => {
    dragItem.current = position;
    setIsDragging(true);
  };
  
  // Handle drag end for visible tabs
  const handleVisibleDragEnd = () => {
    setIsDragging(false);
    
    if (dragItem.current === null || dragOverItem.current === null) return;
    
    // Get the dragged item
    const list = [...visibleTabs];
    const draggedItem = list[dragItem.current];
    
    // Remove it from the array
    list.splice(dragItem.current, 1);
    
    // Add it at the new position
    list.splice(dragOverItem.current, 0, draggedItem);
    
    // Update state
    setVisibleTabs(list);
    setHasChanges(true);
    
    // Reset refs
    dragItem.current = null;
    dragOverItem.current = null;
  };
  
  // Handle drag enter
  const handleDragEnter = (position: number) => {
    dragOverItem.current = position;
  };
  
  // Handle removing tab from visible
  const removeFromVisible = (tab: string) => {
    // Don't allow removing the last tab
    if (visibleTabs.length <= 1) {
      return;
    }
    
    const newVisible = visibleTabs.filter(t => t !== tab);
    setVisibleTabs(newVisible);
    setHasChanges(true);
  };

  // Handle adding a new tab
  const handleAddNewTab = () => {
    // Έλεγχος αν ο χρήστης προσπαθεί να προσθέσει περισσότερες από 6 καρτέλες
    // Αφήνουμε χώρο για το κουμπί ρυθμίσεων που βρίσκεται πάντα στην μπάρα
    if (visibleTabs.length >= 6) {
      alert('Μπορείτε να έχετε μέγιστο 6 ενεργές καρτέλες (+ το κουμπί Ρυθμίσεις).');
      return;
    }
    
    setShowNewTabModal(true);
  };

  // Toggle edit mode
  const toggleEditMode = () => {
    setIsEditMode(!isEditMode);
  };
  
  // Open edit tab modal
  const openEditTabModal = (tab: string) => {
    setEditingTab(tab);
    setEditTabName(TAB_NAMES[tab] || localStorage.getItem(`tab_name_${tab}`) || tab);
    setEditTabIcon(TAB_ICONS[tab] || localStorage.getItem(`tab_icon_${tab}`) || "fas fa-list");
    setShowEditTabModal(true);
  };
  
  // Save edited tab
  const saveEditedTab = () => {
    if (!editingTab || !editTabName.trim()) {
      alert("Παρακαλώ εισάγετε ένα όνομα για την καρτέλα");
      return;
    }
    
    // Update the tab name in TAB_NAMES and localStorage
    localStorage.setItem(`tab_name_${editingTab}`, editTabName);
    TAB_NAMES[editingTab] = editTabName;
    
    // Update the icon in TAB_ICONS and localStorage
    localStorage.setItem(`tab_icon_${editingTab}`, editTabIcon);
    TAB_ICONS[editingTab] = editTabIcon;
    
    // Αν είναι μια από τις βασικές καρτέλες, κάνουμε ανανέωση αμέσως
    if (["greeting", "waiting", "cases", "closing", "comments"].includes(editingTab)) {
      window.location.reload();
      return;
    }
    
    setHasChanges(true);
    setShowEditTabModal(false);
    setEditingTab(null);
  };

  // Handle creating a new tab
  const handleCreateNewTab = () => {
    if (!newTabName.trim()) {
      alert("Παρακαλώ εισάγετε ένα όνομα για την καρτέλα");
      return;
    }

    // Generate a unique ID for the new tab
    const tabId = `custom_${Date.now()}`;
    
    // Add the new tab to visible tabs
    const newList = [...visibleTabs, tabId];
    setVisibleTabs(newList);
    
    // Add the tab name to TAB_NAMES (needs to be stored for UI display)
    localStorage.setItem(`tab_name_${tabId}`, newTabName);
    TAB_NAMES[tabId] = newTabName;
    
    // Add a suitable icon based on type and store it
    const iconClass = newTabType === 'normal' ? "fas fa-list" : "fas fa-folder";
    localStorage.setItem(`tab_icon_${tabId}`, iconClass);
    TAB_ICONS[tabId] = iconClass;
    
    // Store the tab type for later use
    localStorage.setItem(`tab_type_${tabId}`, newTabType);
    
    // Create the custom tab in the context
    addCustomTab(tabId, newTabType, newTabName);
    
    // Close the modal and reset values
    setShowNewTabModal(false);
    setNewTabName('');
    setNewTabType('normal');
    setHasChanges(true);
  };
  
  // Apply changes to the active tabs
  const applyChanges = () => {
    // Έλεγχος ότι δεν υπερβαίνει το μέγιστο αριθμό καρτελών (6)
    // Αφήνουμε χώρο για το κουμπί ρυθμίσεων που βρίσκεται πάντα στην μπάρα
    if (visibleTabs.length > 6) {
      alert('Μπορείτε να έχετε μέγιστο 6 ενεργές καρτέλες (+ το κουμπί Ρυθμίσεις). Παρακαλώ αφαιρέστε κάποιες πριν την εφαρμογή των αλλαγών.');
      return;
    }
    
    // Ενημέρωση της σειράς και των ενεργών καρτελών
    updateActiveTabs(visibleTabs);
    updateTabsOrder(visibleTabs);
    
    // Ανανεώνουμε τη σελίδα χωρίς προειδοποίηση για να εφαρμοστούν οι αλλαγές αμέσως
    window.location.reload();
  };
  
  // Ακύρωση των αλλαγών και επιστροφή στην αρχική κατάσταση
  const cancelChanges = () => {
    setVisibleTabs([...originalTabs]);
    setHasChanges(false);
    setIsEditMode(false);
  };

  return (
    <div className="p-4">
      <div className="mb-6">
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
          Διαχειριστείτε τη σειρά και την εμφάνιση των καρτελών στην εφαρμογή.
        </p>
      </div>
      
      <div>
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-medium mb-3 text-primary-600 dark:text-primary-400">Ενεργές Καρτέλες</h3>
          <div className="flex space-x-2">
            <button 
              className={`${isEditMode ? 'bg-alert-500' : 'bg-primary-500 hover:bg-primary-600'} text-white px-4 py-1 rounded text-sm flex items-center`}
              onClick={toggleEditMode}
            >
              <i className={`${isEditMode ? 'fas fa-times' : 'fas fa-pencil-alt'} mr-1`}></i>
              {isEditMode ? 'Τέλος' : 'Επεξεργασία'}
            </button>
            <button 
              className="bg-primary-500 hover:bg-primary-600 text-white px-4 py-1 rounded text-sm flex items-center"
              onClick={handleAddNewTab}
            >
              <i className="fas fa-plus mr-1"></i>
              Νέα Καρτέλα
            </button>
          </div>
        </div>
        
        <div className="min-h-[200px] p-3 rounded-md bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 mb-6 transition-colors">
          {visibleTabs.length === 0 ? (
            <p className="text-gray-400 dark:text-gray-500 text-center py-4">Δεν υπάρχουν ενεργές καρτέλες</p>
          ) : (
            <div>
              {visibleTabs.map((tab, index) => (
                tab !== 'tabs_manager' && (
                  <div 
                    key={tab}
                    draggable
                    onDragStart={() => handleVisibleDragStart(index)}
                    onDragEnter={() => handleDragEnter(index)}
                    onDragEnd={handleVisibleDragEnd}
                    onDragOver={e => e.preventDefault()}
                    className={`flex items-center justify-between p-2 mb-2 bg-white dark:bg-gray-700 rounded-md shadow border transition-colors ${
                      dragItem.current === index && isDragging ? 'border-2 border-dashed border-blue-400' : 'border-gray-200 dark:border-gray-600'
                    } cursor-grab`}
                  >
                    <div className="flex items-center">
                      <i className={`${localStorage.getItem(`tab_icon_${tab}`) || TAB_ICONS[tab] || 'fas fa-list'} text-primary-500 dark:text-primary-400 mr-2`}></i>
                      <span className="text-gray-800 dark:text-gray-200">
                        {localStorage.getItem(`tab_name_${tab}`) || TAB_NAMES[tab] || tab}
                        {isEditMode && (
                          <button 
                            onClick={() => openEditTabModal(tab)}
                            className="ml-2 text-primary-500 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 text-xs"
                            title="Επεξεργασία ονόματος και εικονιδίου"
                          >
                            <i className="fas fa-pencil-alt"></i>
                          </button>
                        )}
                      </span>
                    </div>
                    {isEditMode ? (
                      <button 
                        onClick={() => removeFromVisible(tab)}
                        className="text-red-500 hover:text-red-700 transition-colors duration-150"
                        disabled={visibleTabs.length <= 1}
                        title={visibleTabs.length <= 1 ? "Δεν μπορείτε να αφαιρέσετε την τελευταία καρτέλα" : "Αφαίρεση καρτέλας"}
                      >
                        <i className="fas fa-times"></i>
                      </button>
                    ) : null}
                  </div>
                )
              ))}
            </div>
          )}
        </div>
      </div>
      
      {/* Apply and Cancel Changes Buttons */}
      {hasChanges && (
        <div className="mt-4 mb-6 flex justify-end space-x-3">
          <button 
            onClick={cancelChanges}
            className="bg-gray-500 hover:bg-gray-600 text-white px-6 py-2 rounded flex items-center"
          >
            <i className="fas fa-times mr-2"></i>
            Άκυρο
          </button>
          <button 
            onClick={applyChanges}
            className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded flex items-center"
          >
            <i className="fas fa-check mr-2"></i>
            Εφαρμογή Αλλαγών
          </button>
        </div>
      )}
      
      {isDragging && (
        <div className="mt-4 p-3 bg-blue-50 rounded text-sm text-blue-700">
          <i className="fas fa-info-circle mr-1"></i>
          Σύρετε και αφήστε για να αλλάξετε τη σειρά των καρτελών
        </div>
      )}
      
      <div className="mt-6 text-sm text-gray-500">
        <p>
          <i className="fas fa-info-circle mr-1"></i>
          Πατήστε "Εφαρμογή Αλλαγών" για να αποθηκεύσετε τις αλλαγές σας. Η καρτέλα "Ρυθμίσεις" δεν εμφανίζεται στη λίστα καθώς δεν μπορεί να αφαιρεθεί ή να αλλάξει θέση.
        </p>
      </div>
      
      {/* Διαγραφή Δεδομένων */}
      <div className="mt-6 pt-4 border-t border-gray-200">
        <h3 className="text-lg font-medium mb-3 text-red-600">Επικίνδυνη Ζώνη</h3>
        <p className="text-sm text-gray-600 mb-4">
          Οι παρακάτω ενέργειες είναι μη αναστρέψιμες και ενδέχεται να προκαλέσουν απώλεια δεδομένων.
        </p>
        
        <div className="flex">
          <button 
            onClick={() => {
              if (window.confirm('Είστε βέβαιοι ότι θέλετε να καθαρίσετε όλα τα δεδομένα τοπικής αποθήκευσης; Αυτή η ενέργεια θα διαγράψει όλες τις προσαρμογές και τις ρυθμίσεις.')) {
                localStorage.clear();
                sessionStorage.clear();
                alert('Τα δεδομένα διαγράφηκαν με επιτυχία. Η σελίδα θα ανανεωθεί.');
                window.location.reload();
              }
            }}
            className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded text-sm"
          >
            <i className="fas fa-trash-alt mr-1"></i>
            Ολική Επαναφορά
          </button>
        </div>
      </div>
      
      {/* New Tab Modal */}
      {showNewTabModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md transition-colors">
            <h3 className="text-lg font-medium mb-4 text-primary-700 dark:text-primary-400">Προσθήκη Νέας Καρτέλας</h3>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Όνομα Καρτέλας
              </label>
              <input 
                type="text" 
                value={newTabName}
                onChange={(e) => setNewTabName(e.target.value)}
                className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 transition-colors"
                placeholder="π.χ. Προϊόντα"
              />
            </div>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Τύπος Καρτέλας
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  className={`p-3 border rounded-md flex flex-col items-center transition-colors ${
                    newTabType === 'normal' ? 'border-primary-500 bg-primary-50 dark:bg-primary-900' : 'border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700'
                  }`}
                  onClick={() => setNewTabType('normal')}
                >
                  <i className="fas fa-list text-xl mb-1"></i>
                  <span className="text-sm text-gray-800 dark:text-gray-200">Normal Tab</span>
                  <span className="text-xs text-gray-500 dark:text-gray-400 mt-1">Απλός κατάλογος απαντήσεων</span>
                </button>
                <button
                  type="button"
                  className={`p-3 border rounded-md flex flex-col items-center transition-colors ${
                    newTabType === 'subcategories' ? 'border-primary-500 bg-primary-50 dark:bg-primary-900' : 'border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700'
                  }`}
                  onClick={() => setNewTabType('subcategories')}
                >
                  <i className="fas fa-folder text-xl mb-1"></i>
                  <span className="text-sm text-gray-800 dark:text-gray-200">Tab with Subcategories</span>
                  <span className="text-xs text-gray-500 dark:text-gray-400 mt-1">Με υποκατηγορίες όπως στο Cases</span>
                </button>
              </div>
            </div>
            
            <div className="flex justify-end space-x-3">
              <button
                type="button"
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors"
                onClick={() => setShowNewTabModal(false)}
              >
                Ακύρωση
              </button>
              <button
                type="button"
                className="px-4 py-2 bg-primary-600 text-white rounded hover:bg-primary-700"
                onClick={handleCreateNewTab}
              >
                Προσθήκη
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Edit Tab Modal */}
      {showEditTabModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md transition-colors">
            <h3 className="text-lg font-medium mb-4 text-primary-700 dark:text-primary-400">Επεξεργασία Καρτέλας</h3>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Όνομα Καρτέλας
              </label>
              <input 
                type="text" 
                value={editTabName}
                onChange={(e) => setEditTabName(e.target.value)}
                className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 transition-colors"
                placeholder="Όνομα καρτέλας"
              />
            </div>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Εικονίδιο Καρτέλας
              </label>
              <div className="grid grid-cols-3 gap-3">
                {AVAILABLE_ICONS.map((icon) => (
                  <button
                    key={icon.class}
                    type="button"
                    className={`p-2 border rounded flex flex-col items-center justify-center transition-colors ${
                      editTabIcon === icon.class ? 'border-primary-500 bg-primary-50 dark:bg-primary-900' : 'border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700'
                    }`}
                    onClick={() => setEditTabIcon(icon.class)}
                  >
                    <i className={`${icon.class} text-xl mb-1`}></i>
                    <span className="text-xs whitespace-nowrap overflow-hidden text-ellipsis w-full text-center text-gray-800 dark:text-gray-200">{icon.name}</span>
                  </button>
                ))}
              </div>
            </div>
            
            <div className="flex justify-end space-x-3">
              <button
                type="button"
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors"
                onClick={() => setShowEditTabModal(false)}
              >
                Ακύρωση
              </button>
              <button
                type="button"
                className="px-4 py-2 bg-primary-600 text-white rounded hover:bg-primary-700"
                onClick={saveEditedTab}
              >
                Αποθήκευση
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TabsManager;