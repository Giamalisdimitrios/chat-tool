import { LineItem as LineItemType } from '@/types';

interface LineItemProps {
  id: string;
  category: string;
  isEditMode: boolean;
  onDelete: () => void;
}

const LineItem = ({ id, category, isEditMode, onDelete }: LineItemProps) => {
  return (
    <div className="line-item mb-3 px-1 relative" data-id={id}>
      <div className="w-full border-t-4 border-primary-700 my-2"></div>
      
      {isEditMode && (
        <button 
          className="absolute -top-3 right-0 text-gray-500 hover:text-alert-500 bg-white px-1 rounded-full"
          onClick={onDelete}
        >
          <i className="fas fa-trash text-[10px]"></i>
        </button>
      )}
    </div>
  );
};

export default LineItem;