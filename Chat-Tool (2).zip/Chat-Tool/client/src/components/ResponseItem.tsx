import { useState } from 'react';
import { Response } from '@/types';
import { useChatTool } from '@/contexts/ChatToolContext';
import { useCopyToClipboard } from '@/hooks/useCopyToClipboard';
import { replaceGreetingPlaceholders } from '@/lib/utils';

interface ResponseItemProps {
  response: Response;
  onShowNotification: (text?: string) => void;
  onOpenEditModal: (response: Response) => void;
  onOpenTitleModal: (response: Response) => void;
  onDelete?: () => void;
}

const ResponseItem = ({ 
  response, 
  onShowNotification,
  onOpenEditModal,
  onOpenTitleModal,
  onDelete
}: ResponseItemProps) => {
  const { deleteResponse } = useChatTool();
  const { copyText, copyBasedOnTime } = useCopyToClipboard(onShowNotification);
  
  // Handle delete
  const handleDelete = () => {
    if (window.confirm(`Are you sure you want to delete "${response.title}"?`)) {
      if (onDelete) {
        // If custom onDelete handler is provided, use that instead
        onDelete();
      } else {
        // Otherwise use default delete from context
        deleteResponse(response.id, response.category);
        onShowNotification('Response deleted successfully!');
      }
    }
  };

  return (
    <div className="message-container bg-white dark:bg-gray-800 rounded border border-gray-200 dark:border-gray-700 mb-2 overflow-hidden transition-colors" data-id={response.id}>
      <div className="py-0 px-1 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center bg-secondary-50 dark:bg-gray-700 h-5 transition-colors">
        <div className="flex items-center">
          <h4 className="font-normal text-xs editable-title truncate max-w-[150px] text-gray-800 dark:text-gray-200">{response.title}</h4>
        </div>
        <div className="flex items-center gap-0">
          <button 
            className="text-gray-500 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 message-edit-btn py-0 px-1"
            onClick={() => onOpenEditModal(response)}
          >
            <i className="fas fa-edit text-[10px]"></i>
          </button>
          <button 
            className="text-gray-500 dark:text-gray-400 hover:text-alert-500 dark:hover:text-alert-400 message-delete-btn py-0 px-1"
            onClick={handleDelete}
          >
            <i className="fas fa-trash text-[10px]"></i>
          </button>
        </div>
      </div>
      <div className="p-2">
        <button 
          className="w-full text-left bg-secondary-100 dark:bg-gray-700 hover:bg-secondary-200 dark:hover:bg-gray-600 active:bg-primary-600 active:text-white transition-colors duration-150 p-2 rounded border border-secondary-300 dark:border-gray-600 relative text-sm text-gray-800 dark:text-gray-200"
          onClick={() => {
            // Check if the content contains ANY Greek greeting pattern
            if (
              response.content.includes('Καλημέρα/Καλησπέρα') ||
              response.content.includes('Καλημέρα/Καλησπέρα σας')
            ) {
              // Apply the replacement and copy the content
              const processedContent = replaceGreetingPlaceholders(response.content, true);
              copyText(processedContent);
            } else {
              copyText(response.content);
            }
          }}
          onDoubleClick={() => {
            if (response.contentEN) {
              // Check if the English content contains ANY greeting pattern
              if (
                response.contentEN.includes('Good Morning/Good Evening') || 
                response.contentEN.includes('Good morning/Good evening') || 
                response.contentEN.includes('Good Morning/Evening') || 
                response.contentEN.includes('Good morning/evening')
              ) {
                // Apply the replacement and copy the content
                const processedContent = replaceGreetingPlaceholders(response.contentEN, false);
                copyText(processedContent);
              } else {
                copyText(response.contentEN);
              }
            }
          }}
        >
          {response.content}
        </button>
      </div>
    </div>
  );
};

export default ResponseItem;
