import { useState, useEffect } from 'react';
import { EditModalProps } from '@/types';

const EditModal = ({ 
  isOpen, 
  onClose, 
  onSave, 
  title: initialTitle, 
  content: initialContent, 
  contentEN: initialContentEN 
}: EditModalProps) => {
  const [title, setTitle] = useState(initialTitle);
  const [content, setContent] = useState(initialContent);
  const [contentEN, setContentEN] = useState(initialContentEN);

  useEffect(() => {
    setTitle(initialTitle);
    setContent(initialContent);
    setContentEN(initialContentEN);
  }, [initialTitle, initialContent, initialContentEN, isOpen]);

  const handleSave = () => {
    onSave(title, content, contentEN);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-lg mx-4">
        <h3 className="text-lg font-bold mb-4 text-gray-800">Edit Message</h3>
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="messageTitle">
            Title
          </label>
          <input 
            id="messageTitle" 
            type="text" 
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="messageContent">
            Message Content (Greek)
          </label>
          <textarea 
            id="messageContent" 
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline h-32"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Εισάγετε ελληνικό κείμενο εδώ..."
          ></textarea>
          
          <div className="mt-2 text-xs bg-green-50 p-2 rounded-md border border-green-100 text-green-700">
            <p><strong>Συμβουλή:</strong> Για αυτόματους χαιρετισμούς ανάλογα με την ώρα, χρησιμοποιήστε αυτές τις μορφές:</p>
            <ul className="list-disc pl-5 mt-1">
              <li>Καλημέρα/Καλησπέρα!</li>
              <li>Καλημέρα/Καλησπέρα σας!</li>
            </ul>
            <p className="mt-1">Το σύστημα θα αντικαταστήσει αυτόματα με τον κατάλληλο χαιρετισμό ανάλογα με την ώρα της ημέρας.</p>
          </div>
        </div>
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="messageContentEN">
            English Content (for double-click)
          </label>
          <textarea 
            id="messageContentEN" 
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline h-32"
            value={contentEN}
            onChange={(e) => setContentEN(e.target.value)}
            placeholder="Enter English content here..."
          ></textarea>
          
          <div className="mt-2 text-xs bg-blue-50 p-2 rounded-md border border-blue-100 text-blue-700">
            <p><strong>Tip:</strong> For automatic time-based greetings, use any of these formats:</p>
            <ul className="list-disc pl-5 mt-1">
              <li>Good Morning/Good Evening!</li>
              <li>Good morning/Good evening!</li>
              <li>Good Morning/Evening!</li>
              <li>Good morning/evening!</li>
            </ul>
            <p className="mt-1">The system will automatically replace it with the appropriate greeting based on time of day.</p>
          </div>
        </div>
        <div className="flex justify-end gap-2">
          <button 
            id="cancelEditBtn" 
            className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded"
            onClick={onClose}
          >
            Cancel
          </button>
          <button 
            id="saveEditBtn" 
            className="bg-primary-600 hover:bg-primary-700 text-white font-bold py-2 px-4 rounded"
            onClick={handleSave}
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
};

export default EditModal;
