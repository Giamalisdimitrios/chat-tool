import { useChatTool } from '@/contexts/ChatToolContext';
import { useAuth } from '@/hooks/use-auth';
import { useState, useRef, useEffect, useCallback } from 'react';
import { ChatToolData } from '@/types';
import { useToast } from '@/hooks/use-toast';
import { ThemeToggle } from './ThemeToggle';
import { Button } from "@/components/ui/button";
import { FileDown, FileUp, LogOut, User, Crown, Calendar } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";

interface HeaderProps {
  onSaveAll: () => void;
}

const Header = ({ onSaveAll }: HeaderProps) => {
  const { exportData, importData } = useChatTool();
  const { user, logoutMutation, subscriptionStatus } = useAuth();
  const [showMenu, setShowMenu] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleExport = () => {
    exportData();
    setShowMenu(false);
  };

  const handleSaveAll = () => {
    onSaveAll();
    setShowMenu(false);
  };
  
  const handleImportClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
    setShowMenu(false);
  };
  
  const handleFileChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) {
      console.log("No file selected");
      return;
    }
    
    console.log("File selected:", file.name, file.type, file.size);
    
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        console.log("File read completed");
        const fileContent = e.target?.result as string;
        console.log("File content (first 100 chars):", fileContent.substring(0, 100));
        
        let parsedData: any;
        try {
          parsedData = JSON.parse(fileContent);
          console.log("JSON parsed successfully");
        } catch (parseError) {
          console.error("JSON parse error:", parseError);
          toast({
            title: "Error",
            description: "Failed to parse the imported file. Make sure it's a valid JSON file.",
            variant: "destructive"
          });
          return;
        }
        
        // Type check
        console.log("Checking file structure:", 
          "greeting" in parsedData, 
          "waiting" in parsedData, 
          "cases" in parsedData, 
          "closing" in parsedData, 
          "comments" in parsedData
        );
        
        if (
          !parsedData.greeting || 
          !parsedData.waiting || 
          !parsedData.cases || 
          !parsedData.closing || 
          !parsedData.comments
        ) {
          console.error("Missing required data sections");
          toast({
            title: "Error",
            description: "Invalid file format. Missing required data sections.",
            variant: "destructive"
          });
          return;
        }
        
        // Manually validate that each section is an array
        const arrayChecks = {
          greeting: Array.isArray(parsedData.greeting),
          waiting: Array.isArray(parsedData.waiting),
          cases: Array.isArray(parsedData.cases),
          closing: Array.isArray(parsedData.closing),
          comments: Array.isArray(parsedData.comments)
        };
        
        console.log("Array checks:", arrayChecks);
        
        if (!arrayChecks.greeting || !arrayChecks.waiting || !arrayChecks.cases || 
            !arrayChecks.closing || !arrayChecks.comments) {
          console.error("Invalid data structure");
          toast({
            title: "Error",
            description: "Invalid data structure. Expected arrays for each section.",
            variant: "destructive"
          });
          return;
        }
        
        console.log("Data validation passed, attempting to import...");
        const success = importData(parsedData);
        console.log("Import result:", success);
        
        if (success) {
          toast({
            title: "Success",
            description: "Data imported successfully! Refresh the page to see changes.",
            variant: "default"
          });
          
          // Create a direct localStorage update to ensure data persistence
          try {
            console.log("Directly updating localStorage with imported data");
            localStorage.setItem('chatToolData', JSON.stringify(parsedData));
            
            // Force a page reload to ensure the new data is loaded properly
            setTimeout(() => {
              console.log("Reloading page to reflect imported data");
              window.location.reload();
            }, 1500);
          } catch (storageError) {
            console.error("localStorage update error:", storageError);
          }
        } else {
          console.error("Import function returned false");
          toast({
            title: "Error",
            description: "Failed to import data. Please try again.",
            variant: "destructive"
          });
        }
      } catch (error) {
        console.error('Error during file processing:', error);
        toast({
          title: "Error",
          description: "Failed to process the imported file. Check console for details.",
          variant: "destructive"
        });
      }
    };
    
    reader.onerror = (error) => {
      console.error("FileReader error:", error);
      toast({
        title: "Error",
        description: "Failed to read the file. Please try again.",
        variant: "destructive"
      });
    };
    
    console.log("Starting file read...");
    reader.readAsText(file);
    
    // Reset the file input so the same file can be selected again if needed
    if (event.target) {
      event.target.value = '';
    }
  }, [importData, toast]);

  // Close menu when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setShowMenu(false);
      }
    }
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <header className="bg-white dark:bg-gray-800 rounded-lg shadow mb-2 p-3 max-w-4xl mx-auto mt-2 transition-colors">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="hidden sm:block w-8 h-8">
            <svg viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
              <rect width="512" height="512" rx="80" fill="#3498db"/>
              <path d="M160 232C160 204.4 182.4 182 210 182H302C329.6 182 352 204.4 352 232V318C352 345.6 329.6 368 302 368H210C182.4 368 160 345.6 160 318V232Z" fill="white"/>
              <path d="M135 182C107.4 182 85 204.4 85 232V318C85 345.6 107.4 368 135 368H145C152.7 368 159 374.3 159 382C159 389.7 152.7 396 145 396H135C92.4 396 58 361.6 58 319V231C58 188.4 92.4 154 135 154H377C419.6 154 454 188.4 454 231V319C454 361.6 419.6 396 377 396H367C359.3 396 353 389.7 353 382C353 374.3 359.3 368 367 368H377C404.6 368 427 345.6 427 318V232C427 204.4 404.6 182 377 182H135Z" fill="white"/>
              <circle cx="210" cy="275" r="20" fill="#3498db"/>
              <circle cx="256" cy="275" r="20" fill="#3498db"/>
              <circle cx="302" cy="275" r="20" fill="#3498db"/>
            </svg>
          </div>
          <div>
            <h1 className="text-lg font-bold text-primary-700 dark:text-primary-400">Chat Tool Pro</h1>
            <p className="text-xs text-gray-500 dark:text-gray-400 hidden sm:block">
              {user ? "Συγχρονίζεται αυτόματα με το cloud" : "Αποθηκεύεται αυτόματα στο browser σας"}
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          {/* Subscription Status */}
          {user && subscriptionStatus && (
            <div className="hidden md:flex items-center gap-2">
              {subscriptionStatus.subscriptionStatus === "trial" && (
                <Badge variant="outline" className="text-xs">
                  <Calendar className="w-3 h-3 mr-1" />
                  Δοκιμή: {Math.max(0, Math.ceil((new Date(subscriptionStatus.trialEndsAt).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)))} μέρες
                </Badge>
              )}
              {subscriptionStatus.subscriptionStatus === "active" && (
                <Badge className="text-xs bg-green-500">
                  <Crown className="w-3 h-3 mr-1" />
                  Pro
                </Badge>
              )}
              {user.isAdmin && (
                <Badge className="text-xs bg-purple-500">
                  <Crown className="w-3 h-3 mr-1" />
                  Admin
                </Badge>
              )}
            </div>
          )}
          
          <Button
            size="sm"
            variant="outline"
            onClick={handleSaveAll}
            title="Αποθήκευση όλων των αλλαγών (γίνεται επίσης αυτόματα)"
          >
            <i className="fas fa-save mr-1"></i>
            <span className="hidden sm:inline">Αποθήκευση</span>
          </Button>
          
          <Button
            size="sm"
            variant="outline"
            onClick={handleExport}
            title="Εξαγωγή δεδομένων σε αρχείο JSON (για backup)"
          >
            <FileDown className="w-4 h-4 mr-1" />
            <span className="hidden sm:inline">Εξαγωγή</span>
          </Button>
          
          <Button
            size="sm"
            variant="outline"
            onClick={handleImportClick}
            title="Εισαγωγή δεδομένων από αρχείο JSON (για επαναφορά)"
          >
            <FileUp className="w-4 h-4 mr-1" />
            <span className="hidden sm:inline">Εισαγωγή</span>
          </Button>
          
          <input 
            type="file" 
            ref={fileInputRef}
            className="hidden" 
            accept=".json" 
            onChange={handleFileChange}
          />
          
          <ThemeToggle />
          
          {/* User Menu */}
          {user && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <User className="w-4 h-4 mr-1" />
                  <span className="hidden sm:inline">{user.username}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem disabled>
                  <User className="w-4 h-4 mr-2" />
                  {user.email}
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => logoutMutation.mutate()}>
                  <LogOut className="w-4 h-4 mr-2" />
                  Αποσύνδεση
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </div>
      
      <div className="mt-2 bg-blue-50 dark:bg-blue-900/20 p-2 rounded text-xs text-blue-800 dark:text-blue-200 hidden sm:block">
        <div className="flex items-start gap-2">
          <i className="fas fa-info-circle mt-0.5"></i>
          <div>
            <p><strong>Συμβουλή:</strong> Οι αλλαγές σας αποθηκεύονται αυτόματα στον browser. Χρησιμοποιήστε το "Εξαγωγή" για να 
            δημιουργήσετε αντίγραφο ασφαλείας των δεδομένων σας, και το "Εισαγωγή" για να τα επαναφέρετε αν χρειαστεί.</p>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
