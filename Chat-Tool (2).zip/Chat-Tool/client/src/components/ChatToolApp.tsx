import { useState, useEffect, useRef } from 'react';
import { Link } from 'wouter';
import { useChatTool } from '@/contexts/ChatToolContext';
import TabNavigation from '@/components/TabNavigation';
import Header from '@/components/Header';
import EditModal from '@/components/EditModal';
import EditTitleModal from '@/components/EditTitleModal';
import CopyAlert from '@/components/CopyAlert';
import { TabNames, Response } from '@/types';
import ResponseItem from '@/components/ResponseItem';
import CaseItem from '@/components/CaseItem';
import CategoryItem from '@/components/CategoryItem';
import LineItem from '@/components/LineItem';
import CategoryManager from '@/components/CategoryManager';
import TabsManager from '@/components/TabsManager';
import { copyToClipboard } from '@/lib/utils';

// Import Font Awesome
import '@fortawesome/fontawesome-free/css/all.min.css';

const ChatToolApp = () => {
  const { 
    state, 
    addResponse, 
    updateResponse, 
    deleteResponse, 
    updateResponseTitle,
    addCase, 
    updateCase, 
    deleteCase, 
    addCategory,
    updateCategory,
    deleteCategory,
    addResponseToCase,
    deleteResponseFromCase,
    addLine,
    updateResponsesOrder,
    updateCasesOrder,
    updateTabsOrder,
    updateActiveTabs
  } = useChatTool();
  
  // Get the active tab from localStorage (if exists) or use the default GREETING tab
  const savedTab = localStorage.getItem('activeTab');
  const initialTab = savedTab ? (savedTab as TabNames) : TabNames.GREETING;
  const [activeTab, setActiveTab] = useState<TabNames | string>(initialTab);
  
  // Update localStorage when tab changes
  const handleTabChange = (tab: TabNames | string) => {
    localStorage.setItem('activeTab', tab);
    setActiveTab(tab as TabNames);
  };
  const [showCopyAlert, setShowCopyAlert] = useState(false);
  const [alertText, setAlertText] = useState('Text copied to clipboard!');
  
  // Edit modal state
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState({
    id: '',
    title: '',
    content: '',
    contentEN: '',
    type: '',
    category: ''
  });
  
  // Edit title modal state
  const [editTitleModalOpen, setEditTitleModalOpen] = useState(false);
  const [editingTitle, setEditingTitle] = useState<{
    id: string;
    title: string;
    type: string;
    customTab?: string;
  }>({
    id: '',
    title: '',
    type: ''
  });
  
  // Edit mode for reordering items
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentCategory, setCurrentCategory] = useState('');

  // Handle copy notification
  const showCopyNotification = (customText?: string) => {
    setAlertText(customText || 'Text copied to clipboard!');
    setShowCopyAlert(true);
    setTimeout(() => setShowCopyAlert(false), 2000);
  };
  
  // Function to copy text to clipboard
  const copyText = async (text: string) => {
    try {
      await copyToClipboard(text);
      showCopyNotification();
    } catch (error) {
      console.error('Failed to copy text:', error);
      showCopyNotification('Failed to copy text to clipboard');
    }
  };

  // Handle adding new items
  // Helper function to detect tab type
  const getTabType = (tabId: string) => {
    // Standard tabs
    if (['greeting', 'waiting', 'closing'].includes(tabId)) {
      return 'normal';
    } else if (tabId === 'cases') {
      return 'cases';
    } else if (tabId === 'comments') {
      return 'subcategories';
    } 
    
    // For custom tabs, check localStorage
    if (tabId.startsWith('custom_')) {
      const storedType = localStorage.getItem(`tab_type_${tabId}`);
      return storedType || 'normal'; // Default to normal if type not found
    }
    
    return 'normal';
  };

  const handleAddNewItem = (type: string) => {
    // For custom tabs, determine if it's normal or subcategories type
    const tabType = getTabType(type);
    
    // Get tab display name for UI
    let tabDisplayName = type;
    if (type.startsWith('custom_')) {
      tabDisplayName = localStorage.getItem(`tab_name_${type}`) || type;
    }
    
    if (tabType === 'normal' || ['greeting', 'waiting', 'closing'].includes(type)) {
      // Normal tab behavior (like greeting, waiting, closing)
      setEditingItem({
        id: '',
        title: `New ${tabDisplayName} response`,
        content: '',
        contentEN: '',
        type: type,
        category: type
      });
      setEditModalOpen(true);
    } else if (tabType === 'cases' || type === 'cases') {
      // Cases tab behavior
      setEditingTitle({
        id: '',
        title: 'New Case',
        type: 'case'
      });
      setEditTitleModalOpen(true);
    } else if (tabType === 'subcategories' || type === 'comments') {
      // Subcategories tab behavior (like comments)
      setEditingTitle({
        id: '',
        title: 'New Category',
        type: 'category',
        customTab: type // Pass the current tab ID to be used in addCategory
      });
      setEditTitleModalOpen(true);
    }
  };

  // Handle save from edit modal
  const handleSaveEdit = (title: string, content: string, contentEN: string) => {
    const { id, type, category } = editingItem;
    
    if (type === 'case-response') {
      // Adding new response to a case
      addResponseToCase(category, {
        id: Date.now().toString(),
        content, 
        contentEN
      });
      showCopyNotification('New response added to case successfully!');
    } else if (type === 'edit-case-response') {
      // Edit existing response in a case
      // Find the case
      const caseToUpdate = state.cases.find(c => c.id === category);
      if (caseToUpdate) {
        // Find the response
        const updatedResponses = caseToUpdate.responses.map(response => 
          response.id === id ? { ...response, content, contentEN } : response
        );
        
        // Update the case
        updateCase({
          ...caseToUpdate,
          responses: updatedResponses
        });
        showCopyNotification('Case response updated successfully!');
      }
    } else if (!id) {
      // Adding new regular response
      addResponse({
        id: Date.now().toString(),
        title,
        content,
        contentEN,
        category: type
      });
      showCopyNotification('New response added successfully!');
    } else {
      // Update existing regular response
      updateResponse({
        id,
        title,
        content,
        contentEN: contentEN || '',
        category
      });
      showCopyNotification('Response updated successfully!');
    }
    
    setEditModalOpen(false);
  };
  
  // Handle save from title modal
  const handleSaveTitleEdit = (title: string) => {
    const { id, type } = editingTitle;
    
    if (!id) {
      // Adding new item
      if (type === 'case') {
        addCase({
          id: Date.now().toString(),
          title,
          responses: []
        });
        showCopyNotification('New case added successfully!');
      } else if (type === 'category') {
        // Check if this is for a custom tab with subcategories
        const customTab = editingTitle.customTab;
        
        addCategory({
          id: Date.now().toString(),
          title,
          subcategories: [],
          ...(customTab ? { customTab } : {}) // Add customTab property if it exists
        });
        showCopyNotification('New category added successfully!');
      }
    } else {
      // Update existing item title
      if (type === 'response-title') {
        updateResponseTitle(id, title, editingItem.category || 'greeting');
        showCopyNotification('Response title updated successfully!');
      } else if (type === 'case-title') {
        const caseToUpdate = state.cases.find(c => c.id === id);
        if (caseToUpdate) {
          updateCase({
            ...caseToUpdate,
            title
          });
          showCopyNotification('Case title updated successfully!');
        }
      } else if (type === 'category-title') {
        const categoryToUpdate = state.comments.find(c => c.id === id);
        if (categoryToUpdate) {
          updateCategory({
            ...categoryToUpdate,
            title
          });
          showCopyNotification('Category title updated successfully!');
        }
      }
    }
    
    setEditTitleModalOpen(false);
  };
  
  // Handle adding a line after a response
  const handleAddLine = (responseId: string, category: string) => {
    addLine(category, responseId);
    showCopyNotification('Line added successfully!');
  };
  
  // Toggle edit mode (for reordering)
  const toggleEditMode = (category: string) => {
    setIsEditMode(!isEditMode);
    setCurrentCategory(category);
    
    // Turn off "add line" mode when toggling edit mode
    if (showAddLineButtons) {
      setShowAddLineButtons(false);
    }
    
    if (isEditMode) {
      // If turning off edit mode, show notification
      showCopyNotification('Changes saved!');
    }
  };
  
  // Toggle "add line" mode
  const [showAddLineButtons, setShowAddLineButtons] = useState(false);
  
  const toggleAddLineMode = (category: string) => {
    setShowAddLineButtons(!showAddLineButtons);
    setCurrentCategory(category);
    
    // Turn off edit mode when toggling "add line" mode
    if (isEditMode) {
      setIsEditMode(false);
    }
  };
  
  // Drag and drop handlers
  const dragItem = useRef<number | null>(null);
  const dragOverItem = useRef<number | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  
  const handleDragStart = (position: number) => {
    dragItem.current = position;
    setIsDragging(true);
    
    // Add a small delay to apply the dragging class (ensures the dragged element gets styled)
    setTimeout(() => {
      const draggableItems = document.querySelectorAll('.edit-mode > div');
      draggableItems.forEach((item, i) => {
        if (i === position) {
          item.classList.add('dragging');
        } else {
          item.classList.remove('dragging');
        }
      });
    }, 0);
  };
  
  const handleDragEnter = (position: number) => {
    dragOverItem.current = position;
    
    // Visual indication of where item will be placed
    const draggableItems = document.querySelectorAll('.edit-mode > div');
    draggableItems.forEach((item, i) => {
      if (i === position) {
        item.classList.add('drag-over-target');
      } else {
        item.classList.remove('drag-over-target');
      }
    });
  };
  
  const handleDragEnd = (category: string) => {
    setIsDragging(false);
    
    // Remove dragging class from all items
    const draggableItems = document.querySelectorAll('.edit-mode > div');
    draggableItems.forEach(item => {
      item.classList.remove('dragging');
      item.classList.remove('drag-over-target');
    });
    
    if (dragItem.current === null || dragOverItem.current === null) return;
    
    let items: Response[] = [];
    
    switch (category) {
      case 'greeting':
        items = [...state.greeting];
        break;
      case 'waiting':
        items = [...state.waiting];
        break;
      case 'closing':
        items = [...state.closing];
        break;
      default:
        return;
    }
    
    // Get the dragged item
    const draggedItem = items[dragItem.current];
    
    // Remove it from the array
    items.splice(dragItem.current, 1);
    
    // Add it at the new position
    items.splice(dragOverItem.current, 0, draggedItem);
    
    // Update the state with the new order
    const newOrder = items.map(item => item.id);
    updateResponsesOrder(category, newOrder);
    
    // Reset refs
    dragItem.current = null;
    dragOverItem.current = null;
  };
  
  // Handle drag end for cases
  const handleCasesDragEnd = () => {
    setIsDragging(false);
    
    // Remove dragging class from all items
    const draggableItems = document.querySelectorAll('.edit-mode > div');
    draggableItems.forEach(item => {
      item.classList.remove('dragging');
      item.classList.remove('drag-over-target');
    });
    
    if (dragItem.current === null || dragOverItem.current === null) return;
    
    // Get cases array
    const cases = [...state.cases];
    
    // Get the dragged item
    const draggedCase = cases[dragItem.current];
    
    // Remove it from the array
    cases.splice(dragItem.current, 1);
    
    // Add it at the new position
    cases.splice(dragOverItem.current, 0, draggedCase);
    
    // Update the state with the new order
    const newOrder = cases.map(c => c.id);
    updateCasesOrder(newOrder);
    
    // Reset refs
    dragItem.current = null;
    dragOverItem.current = null;
  };

  return (
    <div className="min-h-screen overflow-y-auto bg-gray-50 dark:bg-gray-900 transition-colors">
      <Header onSaveAll={() => showCopyNotification('All changes saved successfully!')} />
      
      <div className="max-w-4xl mx-auto p-2">
        {/* Tab Content Area */}
        <div className="mb-14">
          {/* Tabs Manager Tab */}
          {activeTab === TabNames.TABS_MANAGER && (
            <TabsManager />
          )}
          
          {/* Greeting Tab Content */}
          {activeTab === TabNames.GREETING && (
            <div>
              <div className="flex justify-between mb-2">
                <h2 className="text-base font-semibold text-primary-700 dark:text-primary-400">Άνοιγμα Responses</h2>
                <div className="flex gap-1">
                  <button 
                    className={`${isEditMode && currentCategory === 'greeting' ? 'bg-alert-500' : 'bg-primary-500 hover:bg-primary-600'} text-white py-1 px-2 rounded text-xs flex items-center gap-1`}
                    onClick={() => toggleEditMode('greeting')}
                  >
                    <i className="fas fa-edit"></i> {isEditMode && currentCategory === 'greeting' ? 'Save' : 'Edit'}
                  </button>
                  <button 
                    className={`${showAddLineButtons && currentCategory === 'greeting' ? 'bg-alert-500' : 'bg-primary-500 hover:bg-primary-600'} text-white py-1 px-2 rounded text-xs flex items-center gap-1`}
                    onClick={() => toggleAddLineMode('greeting')}
                  >
                    <i className="fas fa-grip-lines"></i> {showAddLineButtons && currentCategory === 'greeting' ? 'Done' : 'Add Line'}
                  </button>
                  <button 
                    className="bg-primary-500 hover:bg-primary-600 text-white py-1 px-2 rounded text-xs flex items-center gap-1"
                    onClick={() => handleAddNewItem('greeting')}
                  >
                    <i className="fas fa-plus"></i> Add New
                  </button>
                </div>
              </div>
              
              {state.greeting && state.greeting.length > 0 ? (
                <div className={isEditMode && currentCategory === 'greeting' ? 'edit-mode' : ''}>
                  {state.greeting.map((item, index) => (
                    item.type === 'line' ? (
                      <div
                        draggable={isEditMode && currentCategory === 'greeting'}
                        onDragStart={() => handleDragStart(index)}
                        onDragEnter={() => handleDragEnter(index)}
                        onDragEnd={() => handleDragEnd('greeting')}
                        onDragOver={(e) => e.preventDefault()}
                      >
                        <LineItem 
                          key={item.id} 
                          id={item.id} 
                          category="greeting" 
                          isEditMode={isEditMode && currentCategory === 'greeting'}
                          onDelete={() => {
                            if (window.confirm('Are you sure you want to delete this line?')) {
                              deleteResponse(item.id, 'greeting');
                              showCopyNotification('Line deleted successfully!');
                            }
                          }}
                        />
                      </div>
                    ) : (
                      <div 
                        key={item.id} 
                        className="relative"
                        draggable={isEditMode && currentCategory === 'greeting'}
                        onDragStart={() => handleDragStart(index)}
                        onDragEnter={() => handleDragEnter(index)}
                        onDragEnd={() => handleDragEnd('greeting')}
                        onDragOver={(e) => e.preventDefault()}
                      >
                        <ResponseItem 
                          response={item} 
                          onShowNotification={showCopyNotification}
                          onOpenEditModal={(item) => {
                            setEditingItem({
                              id: item.id,
                              title: item.title,
                              content: item.content,
                              contentEN: item.contentEN || '',
                              type: 'edit',
                              category: 'greeting'
                            });
                            setEditModalOpen(true);
                          }}
                          onOpenTitleModal={(item) => {
                            setEditingTitle({
                              id: item.id,
                              title: item.title,
                              type: 'response-title'
                            });
                            setEditTitleModalOpen(true);
                          }}
                        />
                        {!isEditMode && showAddLineButtons && currentCategory === 'greeting' && (
                          <button 
                            className="add-line-button absolute right-2 top-1/2 -translate-y-1/2 bg-primary-500 hover:bg-primary-600 text-white text-xs py-1 px-2 rounded"
                            onClick={() => handleAddLine(item.id, 'greeting')}
                            title="Add line after this response"
                          >
                            <i className="fas fa-plus"></i>
                          </button>
                        )}
                      </div>
                    )
                  ))}
                </div>
              ) : (
                <div className="bg-gray-100 dark:bg-gray-800 p-4 rounded text-center text-gray-700 dark:text-gray-300">
                  No greeting responses found. Add new ones with the button above.
                </div>
              )}
            </div>
          )}

          {/* Waiting Tab Content */}
          {activeTab === TabNames.WAITING && (
            <div>
              <div className="flex justify-between mb-2">
                <h2 className="text-base font-semibold text-primary-700 dark:text-primary-400">Αναμονή Responses</h2>
                <div className="flex gap-1">
                  <button 
                    className={`${isEditMode && currentCategory === 'waiting' ? 'bg-alert-500' : 'bg-primary-500 hover:bg-primary-600'} text-white py-1 px-2 rounded text-xs flex items-center gap-1`}
                    onClick={() => toggleEditMode('waiting')}
                  >
                    <i className="fas fa-edit"></i> {isEditMode && currentCategory === 'waiting' ? 'Save' : 'Edit'}
                  </button>
                  <button 
                    className={`${showAddLineButtons && currentCategory === 'waiting' ? 'bg-alert-500' : 'bg-primary-500 hover:bg-primary-600'} text-white py-1 px-2 rounded text-xs flex items-center gap-1`}
                    onClick={() => toggleAddLineMode('waiting')}
                  >
                    <i className="fas fa-grip-lines"></i> {showAddLineButtons && currentCategory === 'waiting' ? 'Done' : 'Add Line'}
                  </button>
                  <button 
                    className="bg-primary-500 hover:bg-primary-600 text-white py-1 px-2 rounded text-xs flex items-center gap-1"
                    onClick={() => handleAddNewItem('waiting')}
                  >
                    <i className="fas fa-plus"></i> Add New
                  </button>
                </div>
              </div>
              
              {state.waiting && state.waiting.length > 0 ? (
                <div className={isEditMode && currentCategory === 'waiting' ? 'edit-mode' : ''}>
                  {state.waiting.map((item, index) => (
                    item.type === 'line' ? (
                      <div
                        draggable={isEditMode && currentCategory === 'waiting'}
                        onDragStart={() => handleDragStart(index)}
                        onDragEnter={() => handleDragEnter(index)}
                        onDragEnd={() => handleDragEnd('waiting')}
                        onDragOver={(e) => e.preventDefault()}
                      >
                        <LineItem 
                          key={item.id} 
                          id={item.id} 
                          category="waiting" 
                          isEditMode={isEditMode && currentCategory === 'waiting'}
                          onDelete={() => {
                            if (window.confirm('Are you sure you want to delete this line?')) {
                              deleteResponse(item.id, 'waiting');
                              showCopyNotification('Line deleted successfully!');
                            }
                          }}
                        />
                      </div>
                    ) : (
                      <div 
                        key={item.id} 
                        className="relative"
                        draggable={isEditMode && currentCategory === 'waiting'}
                        onDragStart={() => handleDragStart(index)}
                        onDragEnter={() => handleDragEnter(index)}
                        onDragEnd={() => handleDragEnd('waiting')}
                        onDragOver={(e) => e.preventDefault()}
                      >
                        <ResponseItem 
                          response={item} 
                          onShowNotification={showCopyNotification}
                          onOpenEditModal={(item) => {
                            setEditingItem({
                              id: item.id,
                              title: item.title,
                              content: item.content,
                              contentEN: item.contentEN || '',
                              type: 'edit',
                              category: 'waiting'
                            });
                            setEditModalOpen(true);
                          }}
                          onOpenTitleModal={(item) => {
                            setEditingTitle({
                              id: item.id,
                              title: item.title,
                              type: 'response-title'
                            });
                            setEditTitleModalOpen(true);
                          }}
                        />
                        {!isEditMode && showAddLineButtons && currentCategory === 'waiting' && (
                          <button 
                            className="add-line-button absolute right-2 top-1/2 -translate-y-1/2 bg-primary-500 hover:bg-primary-600 text-white text-xs py-1 px-2 rounded"
                            onClick={() => handleAddLine(item.id, 'waiting')}
                            title="Add line after this response"
                          >
                            <i className="fas fa-plus"></i>
                          </button>
                        )}
                      </div>
                    )
                  ))}
                </div>
              ) : (
                <div className="bg-gray-100 dark:bg-gray-800 p-4 rounded text-center text-gray-700 dark:text-gray-300">
                  No waiting responses found. Add new ones with the button above.
                </div>
              )}
            </div>
          )}

          {/* Cases Tab Content */}
          {activeTab === TabNames.CASES && (
            <div>
              <div className="flex justify-between mb-2">
                <h2 className="text-base font-semibold text-primary-700 dark:text-primary-400">Cases</h2>
                <div className="flex gap-1">
                  <button 
                    className={`${isEditMode && currentCategory === 'cases' ? 'bg-alert-500' : 'bg-primary-500 hover:bg-primary-600'} text-white py-1 px-2 rounded text-xs flex items-center gap-1`}
                    onClick={() => toggleEditMode('cases')}
                  >
                    <i className="fas fa-edit"></i> {isEditMode && currentCategory === 'cases' ? 'Save' : 'Edit'}
                  </button>
                  <button 
                    className="bg-primary-500 hover:bg-primary-600 text-white py-1 px-2 rounded text-xs flex items-center gap-1"
                    onClick={() => handleAddNewItem('cases')}
                  >
                    <i className="fas fa-plus"></i> Add New Case
                  </button>
                </div>
              </div>
              
              {state.cases && state.cases.length > 0 ? (
                <div className={`grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2 ${isEditMode && currentCategory === 'cases' ? 'edit-mode' : ''}`}>
                  {state.cases.map((caseItem, index) => (
                    <div 
                      key={caseItem.id} 
                      className="case-item mb-2"
                      draggable={isEditMode && currentCategory === 'cases'}
                      onDragStart={() => handleDragStart(index)}
                      onDragEnter={() => handleDragEnter(index)}
                      onDragEnd={() => handleCasesDragEnd()}
                      onDragOver={(e) => e.preventDefault()}
                    >
                      <Link 
                        to={`/case/${caseItem.id}`}
                        className={`block w-full bg-white dark:bg-gray-800 shadow-sm hover:shadow-md transition-all rounded border border-gray-200 dark:border-gray-700 p-1.5 text-center ${isEditMode && currentCategory === 'cases' ? 'cursor-move' : ''}`}
                        onClick={(e) => {
                          if (isEditMode && currentCategory === 'cases') {
                            e.preventDefault();
                          }
                        }}
                      >
                        <div className="flex flex-col items-center justify-between h-full">
                          <div className="w-6 h-6 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center text-primary-600 dark:text-primary-400 text-xs transition-colors">
                            <i className="fas fa-briefcase"></i>
                          </div>
                          <h3 className="font-medium text-xs mt-1 mb-1.5 text-gray-800 dark:text-gray-200">{caseItem.title}</h3>
                          
                          <div className="mt-0.5 flex items-center gap-0">
                            <button 
                              className="text-gray-500 dark:text-gray-400 hover:text-primary-500 dark:hover:text-primary-400 p-0.5 transition-colors"
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                setEditingTitle({
                                  id: caseItem.id,
                                  title: caseItem.title,
                                  type: 'case-title'
                                });
                                setEditTitleModalOpen(true);
                              }}
                            >
                              <i className="fas fa-pencil-alt text-[10px]"></i>
                            </button>
                            <button 
                              className="text-gray-500 dark:text-gray-400 hover:text-alert-500 dark:hover:text-alert-400 p-0.5 transition-colors"
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                if (window.confirm(`Are you sure you want to delete "${caseItem.title}"?`)) {
                                  deleteCase(caseItem.id);
                                  showCopyNotification('Case deleted successfully!');
                                }
                              }}
                            >
                              <i className="fas fa-trash text-[10px]"></i>
                            </button>
                          </div>
                        </div>
                      </Link>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded text-center transition-colors">
                  <p className="text-gray-600 dark:text-gray-400">No cases found. Add new ones with the button above.</p>
                </div>
              )}
            </div>
          )}

          {/* Closing Tab Content */}
          {activeTab === TabNames.CLOSING && (
            <div>
              <div className="flex justify-between mb-2">
                <h2 className="text-base font-semibold text-primary-700 dark:text-primary-400">Κλείσιμο Responses</h2>
                <div className="flex gap-1">
                  <button 
                    className={`${isEditMode && currentCategory === 'closing' ? 'bg-alert-500' : 'bg-primary-500 hover:bg-primary-600'} text-white py-1 px-2 rounded text-xs flex items-center gap-1`}
                    onClick={() => toggleEditMode('closing')}
                  >
                    <i className="fas fa-edit"></i> {isEditMode && currentCategory === 'closing' ? 'Save' : 'Edit'}
                  </button>
                  <button 
                    className={`${showAddLineButtons && currentCategory === 'closing' ? 'bg-alert-500' : 'bg-primary-500 hover:bg-primary-600'} text-white py-1 px-2 rounded text-xs flex items-center gap-1`}
                    onClick={() => toggleAddLineMode('closing')}
                  >
                    <i className="fas fa-grip-lines"></i> {showAddLineButtons && currentCategory === 'closing' ? 'Done' : 'Add Line'}
                  </button>
                  <button 
                    className="bg-primary-500 hover:bg-primary-600 text-white py-1 px-2 rounded text-xs flex items-center gap-1"
                    onClick={() => handleAddNewItem('closing')}
                  >
                    <i className="fas fa-plus"></i> Add New
                  </button>
                </div>
              </div>
              
              {state.closing && state.closing.length > 0 ? (
                <div className={isEditMode && currentCategory === 'closing' ? 'edit-mode' : ''}>
                  {state.closing.map((item, index) => (
                    item.type === 'line' ? (
                      <div
                        draggable={isEditMode && currentCategory === 'closing'}
                        onDragStart={() => handleDragStart(index)}
                        onDragEnter={() => handleDragEnter(index)}
                        onDragEnd={() => handleDragEnd('closing')}
                        onDragOver={(e) => e.preventDefault()}
                      >
                        <LineItem 
                          key={item.id} 
                          id={item.id} 
                          category="closing" 
                          isEditMode={isEditMode && currentCategory === 'closing'}
                          onDelete={() => {
                            if (window.confirm('Are you sure you want to delete this line?')) {
                              deleteResponse(item.id, 'closing');
                              showCopyNotification('Line deleted successfully!');
                            }
                          }}
                        />
                      </div>
                    ) : (
                      <div 
                        key={item.id} 
                        className="relative"
                        draggable={isEditMode && currentCategory === 'closing'}
                        onDragStart={() => handleDragStart(index)}
                        onDragEnter={() => handleDragEnter(index)}
                        onDragEnd={() => handleDragEnd('closing')}
                        onDragOver={(e) => e.preventDefault()}
                      >
                        <ResponseItem 
                          response={item} 
                          onShowNotification={showCopyNotification}
                          onOpenEditModal={(item) => {
                            setEditingItem({
                              id: item.id,
                              title: item.title,
                              content: item.content,
                              contentEN: item.contentEN || '',
                              type: 'edit',
                              category: 'closing'
                            });
                            setEditModalOpen(true);
                          }}
                          onOpenTitleModal={(item) => {
                            setEditingTitle({
                              id: item.id,
                              title: item.title,
                              type: 'response-title'
                            });
                            setEditTitleModalOpen(true);
                          }}
                        />
                        {!isEditMode && showAddLineButtons && currentCategory === 'closing' && (
                          <button 
                            className="add-line-button absolute right-2 top-1/2 -translate-y-1/2 bg-primary-500 hover:bg-primary-600 text-white text-xs py-1 px-2 rounded"
                            onClick={() => handleAddLine(item.id, 'closing')}
                            title="Add line after this response"
                          >
                            <i className="fas fa-plus"></i>
                          </button>
                        )}
                      </div>
                    )
                  ))}
                </div>
              ) : (
                <div className="bg-gray-100 p-4 rounded text-center">
                  No closing responses found. Add new ones with the button above.
                </div>
              )}
            </div>
          )}

          {/* Comments Tab Content */}
          {activeTab === TabNames.COMMENTS && (
            <div>
              <div className="flex justify-between mb-2">
                <h2 className="text-base font-semibold text-primary-700 dark:text-primary-400">Σχόλια & Υποκατηγορίες</h2>
                <button 
                  className="bg-primary-500 hover:bg-primary-600 text-white py-1 px-2 rounded text-xs flex items-center gap-1"
                  onClick={() => handleAddNewItem('comments')}
                >
                  <i className="fas fa-plus"></i> Add Category
                </button>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {state.comments && state.comments.length > 0 ? state.comments.map(category => (
                  <CategoryItem 
                    key={category.id} 
                    category={category} 
                    onShowNotification={showCopyNotification}
                    onOpenTitleModal={(item) => {
                      setEditingTitle({
                        id: item.id,
                        title: item.title,
                        type: 'category-title'
                      });
                      setEditTitleModalOpen(true);
                    }}
                  />
                )) : (
                  <div className="bg-gray-100 p-2 rounded text-center text-sm col-span-2">
                    No categories found. Add new ones with the button above.
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Custom Tabs */}
          {typeof activeTab === 'string' && activeTab.startsWith('custom_') && (
            <div>
              <div className="flex justify-between mb-2">
                {/* Get the custom tab name from localStorage */}
                <h2 className="text-base font-semibold text-primary-700 dark:text-primary-400">
                  {localStorage.getItem(`tab_name_${activeTab}`) || activeTab.replace('custom_', '')}
                </h2>
                
                <div className="flex gap-1">
                  {/* Show appropriate buttons based on tab type */}
                  {getTabType(activeTab) === 'normal' && (
                    <>
                      <button 
                        className={`${isEditMode && currentCategory === activeTab ? 'bg-alert-500' : 'bg-primary-500 hover:bg-primary-600'} text-white py-1 px-2 rounded text-xs flex items-center gap-1`}
                        onClick={() => toggleEditMode(activeTab)}
                      >
                        <i className="fas fa-edit"></i> {isEditMode && currentCategory === activeTab ? 'Save' : 'Edit'}
                      </button>
                      <button 
                        className={`${showAddLineButtons && currentCategory === activeTab ? 'bg-alert-500' : 'bg-primary-500 hover:bg-primary-600'} text-white py-1 px-2 rounded text-xs flex items-center gap-1`}
                        onClick={() => toggleAddLineMode(activeTab)}
                      >
                        <i className="fas fa-grip-lines"></i> {showAddLineButtons && currentCategory === activeTab ? 'Done' : 'Add Line'}
                      </button>
                    </>
                  )}
                  {getTabType(activeTab) === 'subcategories' && (
                    <button 
                      className={`${isEditMode && currentCategory === activeTab ? 'bg-alert-500' : 'bg-primary-500 hover:bg-primary-600'} text-white py-1 px-2 rounded text-xs flex items-center gap-1`}
                      onClick={() => toggleEditMode(activeTab)}
                    >
                      <i className="fas fa-edit"></i> {isEditMode && currentCategory === activeTab ? 'Save' : 'Edit'}
                    </button>
                  )}
                  <button 
                    className="bg-primary-500 hover:bg-primary-600 text-white py-1 px-2 rounded text-xs flex items-center gap-1"
                    onClick={() => handleAddNewItem(activeTab)}
                  >
                    <i className="fas fa-plus"></i> Add New
                  </button>
                </div>
              </div>
              
              {/* Display content based on tab type */}
              {getTabType(activeTab) === 'normal' && state[activeTab] && Array.isArray(state[activeTab]) && (
                <div className={isEditMode && currentCategory === activeTab ? 'edit-mode' : ''}>
                  {state[activeTab].map((item, index) => (
                    item.type === 'line' ? (
                      <div
                        key={item.id}
                        draggable={isEditMode && currentCategory === activeTab}
                        onDragStart={() => handleDragStart(index)}
                        onDragEnter={() => handleDragEnter(index)}
                        onDragEnd={() => handleDragEnd(activeTab)}
                        onDragOver={(e) => e.preventDefault()}
                      >
                        <LineItem 
                          id={item.id} 
                          category={activeTab} 
                          isEditMode={isEditMode && currentCategory === activeTab}
                          onDelete={() => {
                            if (window.confirm('Are you sure you want to delete this line?')) {
                              deleteResponse(item.id, activeTab);
                              showCopyNotification('Line deleted successfully!');
                            }
                          }}
                        />
                      </div>
                    ) : (
                      <div 
                        key={item.id}
                        className="relative"
                        draggable={isEditMode && currentCategory === activeTab}
                        onDragStart={() => handleDragStart(index)}
                        onDragEnter={() => handleDragEnter(index)}
                        onDragEnd={() => handleDragEnd(activeTab)}
                        onDragOver={(e) => e.preventDefault()}
                      >
                        <ResponseItem 
                          response={item}
                          onShowNotification={showCopyNotification}
                          onOpenEditModal={(response) => {
                            setEditingItem({
                              id: response.id,
                              title: response.title,
                              content: response.content,
                              contentEN: response.contentEN || '',
                              type: 'response',
                              category: activeTab
                            });
                            setEditModalOpen(true);
                          }}
                          onOpenTitleModal={(response) => {
                            setEditingTitle({
                              id: response.id,
                              title: response.title,
                              type: 'response-title'
                            });
                            setEditingItem({
                              ...editingItem,
                              category: activeTab
                            });
                            setEditTitleModalOpen(true);
                          }}
                          onDelete={() => {
                            if (window.confirm('Are you sure you want to delete this response?')) {
                              deleteResponse(item.id, activeTab);
                              showCopyNotification('Response deleted successfully!');
                            }
                          }}
                        />
                        
                        {/* Show add line buttons if enabled */}
                        {showAddLineButtons && currentCategory === activeTab && (
                          <button 
                            className="add-line-button absolute right-2 top-1/2 -translate-y-1/2 bg-primary-500 hover:bg-primary-600 text-white text-xs py-1 px-2 rounded"
                            onClick={() => handleAddLine(item.id, activeTab)}
                            title="Add line after this response"
                          >
                            <i className="fas fa-plus"></i>
                          </button>
                        )}
                      </div>
                    )
                  ))}
                </div>
              )}
              
              {/* For subcategories tab (exactly like cases) */}
              {getTabType(activeTab) === 'subcategories' && state[activeTab] && Array.isArray(state[activeTab]) && (
                <div className={`grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2 ${isEditMode && currentCategory === activeTab ? 'edit-mode' : ''}`}>
                  {state[activeTab].map((category, index) => (
                    <div 
                      key={category.id} 
                      className="case-item mb-2"
                      draggable={isEditMode && currentCategory === activeTab}
                      onDragStart={() => handleDragStart(index)}
                      onDragEnter={() => handleDragEnter(index)}
                      onDragEnd={() => handleCasesDragEnd()}
                      onDragOver={(e) => e.preventDefault()}
                    >
                      <Link 
                        to={`/subcategory/${category.id}`}
                        className={`block w-full bg-white shadow-sm hover:shadow-md transition-shadow rounded border border-gray-200 p-1.5 text-center ${isEditMode && currentCategory === activeTab ? 'cursor-move' : ''}`}
                        onClick={(e) => {
                          if (isEditMode && currentCategory === activeTab) {
                            e.preventDefault();
                          }
                        }}
                      >
                        <div className="flex flex-col items-center justify-between h-full">
                          <div className="w-6 h-6 rounded-full bg-primary-100 flex items-center justify-center text-primary-600 text-xs">
                            <i className="fas fa-folder"></i>
                          </div>
                          <h3 className="font-medium text-xs mt-1 mb-1.5">{category.title}</h3>
                          
                          <div className="mt-0.5 flex items-center gap-0">
                            <button 
                              className="text-gray-500 hover:text-primary-500 p-0.5"
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                setEditingTitle({
                                  id: category.id,
                                  title: category.title,
                                  type: 'category-title'
                                });
                                setEditTitleModalOpen(true);
                              }}
                            >
                              <i className="fas fa-pencil-alt text-[10px]"></i>
                            </button>
                            <button 
                              className="text-gray-500 hover:text-alert-500 p-0.5"
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                if (window.confirm(`Are you sure you want to delete "${category.title}"?`)) {
                                  deleteCategory(category.id, activeTab);
                                  showCopyNotification('Category deleted successfully!');
                                }
                              }}
                            >
                              <i className="fas fa-trash text-[10px]"></i>
                            </button>
                          </div>
                        </div>
                      </Link>
                    </div>
                  ))}
                </div>
              )}
              
              {/* Empty state for subcategories */}
              {getTabType(activeTab) === 'subcategories' && (!state[activeTab] || !Array.isArray(state[activeTab]) || state[activeTab].length === 0) && (
                <div className="bg-gray-100 dark:bg-gray-800 p-4 rounded text-center text-gray-700 dark:text-gray-300">
                  No categories found. Add new ones with the button above.
                </div>
              )}
              
              {/* Empty state */}
              {getTabType(activeTab) === 'normal' && (!state[activeTab] || !Array.isArray(state[activeTab]) || state[activeTab].length === 0) && (
                <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                  <p>No items yet. Click "Add New" to create one.</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      <EditModal
        isOpen={editModalOpen}
        onClose={() => setEditModalOpen(false)}
        onSave={handleSaveEdit}
        title={editingItem.title}
        content={editingItem.content}
        contentEN={editingItem.contentEN}
      />
      
      <EditTitleModal
        isOpen={editTitleModalOpen}
        onClose={() => setEditTitleModalOpen(false)}
        onSave={handleSaveTitleEdit}
        title={editingTitle.title}
      />

      {/* Copy Notification */}
      <CopyAlert show={showCopyAlert} text={alertText} />

      {/* Bottom Navigation */}
      <TabNavigation activeTab={activeTab} onChangeTab={handleTabChange} />
    </div>
  );
};

export default ChatToolApp;
