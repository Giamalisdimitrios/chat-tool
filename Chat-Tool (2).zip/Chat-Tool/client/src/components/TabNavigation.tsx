import { TabNames } from '@/types';
import { useChatTool } from '@/contexts/ChatToolContext';

interface TabNavigationProps {
  activeTab: TabNames | string;
  onChangeTab: (tab: TabNames | string) => void;
}

const TabNavigation = ({ activeTab, onChangeTab }: TabNavigationProps) => {
  const { state } = useChatTool();
  const activeTabs = state.activeTabs || ["greeting", "waiting", "cases", "closing"];
  
  // Map TabNames to default icons and display names
  const defaultTabInfo: Record<string, { icon: string, name: string }> = {
    greeting: { icon: "fas fa-comment-dots", name: "Άνοιγμα" },
    waiting: { icon: "fas fa-clock", name: "Αναμονή" },
    cases: { icon: "fas fa-briefcase", name: "Cases" },
    closing: { icon: "fas fa-check-circle", name: "Κλείσιμο" },
    tabs_manager: { icon: "fas fa-cogs", name: "Ρυθμίσεις" },
  };
  
  // Initialize tabInfo with defaults, but check localStorage for custom settings
  const tabInfo: Record<string, { icon: string, name: string }> = {};
  
  // First initialize with default values
  Object.keys(defaultTabInfo).forEach(key => {
    // Check if there are custom values stored in localStorage
    const storedName = localStorage.getItem(`tab_name_${key}`);
    const storedIcon = localStorage.getItem(`tab_icon_${key}`);
    
    tabInfo[key] = { 
      icon: storedIcon || defaultTabInfo[key].icon, 
      name: storedName || defaultTabInfo[key].name 
    };
  });
  
  // Import the tab names from TAB_NAMES in TabsManager
  const TAB_NAMES: Record<string, string> = {
    greeting: "Άνοιγμα",
    waiting: "Αναμονή",
    cases: "Cases",
    closing: "Κλείσιμο",
    comments: "Σχόλια",
    tabs_manager: "Ρυθμίσεις"
  };
  
  // Add any custom tabs from state
  Object.keys(state).forEach(key => {
    if (key.startsWith('custom_') && !tabInfo[key]) {
      // Try to get stored name and icon from localStorage
      const storedName = localStorage.getItem(`tab_name_${key}`);
      const storedIcon = localStorage.getItem(`tab_icon_${key}`);
      
      // Default values if stored data not found
      const isSubcategories = state[key] && Array.isArray(state[key]) && state[key][0] && state[key][0].subcategories;
      const defaultIcon = isSubcategories ? "fas fa-folder" : "fas fa-list";
      
      tabInfo[key] = { 
        icon: storedIcon || defaultIcon, 
        name: storedName || TAB_NAMES[key] || key.replace('custom_', '').replace(/^\d+_?/, '')
      };
      
      // Update TAB_NAMES for other components to use
      if (storedName) {
        TAB_NAMES[key] = storedName;
      }
    }
  });
  
  const handleTabClick = (tab: string) => {
    console.log('Changing tab to:', tab);
    onChangeTab(tab);
  };

  // Υπολογισμός προσαρμοζόμενου μεγέθους κουμπιών βάσει του αριθμού των tabs
  const getTabWidth = () => {
    if (activeTabs.length <= 4) return 'w-[4.5rem]'; // Κανονικό μέγεθος έως 4 tabs
    if (activeTabs.length === 5) return 'w-[4.2rem]'; // Λίγο μικρότερο για 5 tabs
    return 'w-[3.8rem]'; // Ακόμα μικρότερο για 6 tabs
  };
  
  // Υπολογισμός μεγέθους εικονιδίων βάσει του αριθμού των tabs
  const getIconSize = () => {
    if (activeTabs.length <= 4) return 'text-xl';
    if (activeTabs.length === 5) return 'text-lg';
    return 'text-base';
  };
  
  const tabWidth = getTabWidth();
  const iconSize = getIconSize();

  return (
    <div className="fixed bottom-0 left-0 w-full bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 shadow-lg z-40 transition-colors">
      <div className="relative flex items-center max-w-screen overflow-hidden">
        {/* Main tabs container - Centered */}
        <div className="w-full flex justify-center items-center gap-[3px] px-10 py-1 overflow-visible">
          {/* Always show active tabs in defined order */}
          {activeTabs.map(tab => {
            const info = tabInfo[tab] || { icon: "fas fa-list", name: tab };
            return (
              <button 
                key={tab}
                className={`tablinks flex-shrink-0 flex flex-col items-center justify-center p-1.5 rounded hover:bg-primary-50 dark:hover:bg-gray-700 transition-colors duration-150 text-sm ${tabWidth} ${activeTab === tab ? 'text-primary-700 dark:text-primary-400' : 'text-gray-700 dark:text-gray-300'}`}
                onClick={() => handleTabClick(tab)}
              >
                <i className={`${info.icon} ${iconSize} mb-1`}></i>
                <span className="text-sm">{info.name}</span>
              </button>
            );
          })}
        </div>
        
        {/* Settings tab - Absolute positioned at the right edge */}
        <div className="absolute right-0 top-0 h-full flex items-center">
          <div className="h-10 border-l border-gray-300 dark:border-gray-600"></div>
          <button 
            className={`tablinks flex-shrink-0 flex items-center justify-center p-2 rounded-none hover:bg-primary-50 dark:hover:bg-gray-700 transition-colors duration-150 ${activeTab === TabNames.TABS_MANAGER ? 'text-primary-700 dark:text-primary-400' : 'text-gray-700 dark:text-gray-300'}`}
            onClick={() => handleTabClick(TabNames.TABS_MANAGER)}
            title="Ρυθμίσεις"
            style={{borderTopLeftRadius: '0.25rem', borderBottomLeftRadius: '0.25rem', width: '3rem'}}
          >
            <i className="fas fa-cogs text-xl"></i>
          </button>
        </div>
      </div>
    </div>
  );
};

export default TabNavigation;
