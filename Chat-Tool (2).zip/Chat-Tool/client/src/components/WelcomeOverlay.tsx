import { useState, useEffect } from 'react';

const WelcomeOverlay = () => {
  const [showOverlay, setShowOverlay] = useState(false);

  useEffect(() => {
    // Check if it's the first visit
    const hasVisitedBefore = localStorage.getItem('hasVisitedBefore');
    if (!hasVisitedBefore) {
      setShowOverlay(true);
      localStorage.setItem('hasVisitedBefore', 'true');
    }
  }, []);

  if (!showOverlay) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
      <div className="bg-white rounded-lg shadow-lg max-w-lg w-full p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-3">
            <div className="text-3xl text-blue-600">
              <svg viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-10 h-10">
                <rect width="512" height="512" rx="80" fill="#3498db"/>
                <path d="M160 232C160 204.4 182.4 182 210 182H302C329.6 182 352 204.4 352 232V318C352 345.6 329.6 368 302 368H210C182.4 368 160 345.6 160 318V232Z" fill="white"/>
                <path d="M135 182C107.4 182 85 204.4 85 232V318C85 345.6 107.4 368 135 368H145C152.7 368 159 374.3 159 382C159 389.7 152.7 396 145 396H135C92.4 396 58 361.6 58 319V231C58 188.4 92.4 154 135 154H377C419.6 154 454 188.4 454 231V319C454 361.6 419.6 396 377 396H367C359.3 396 353 389.7 353 382C353 374.3 359.3 368 367 368H377C404.6 368 427 345.6 427 318V232C427 204.4 404.6 182 377 182H135Z" fill="white"/>
                <circle cx="210" cy="275" r="20" fill="#3498db"/>
                <circle cx="256" cy="275" r="20" fill="#3498db"/>
                <circle cx="302" cy="275" r="20" fill="#3498db"/>
              </svg>
            </div>
            <h2 className="text-xl font-bold text-gray-800">Καλώς ήρθατε στο Chat Tool App!</h2>
          </div>
          <button 
            onClick={() => setShowOverlay(false)}
            className="text-gray-500 hover:text-gray-700"
          >
            <i className="fas fa-times"></i>
          </button>
        </div>
        
        <div className="mt-4 text-gray-700 space-y-4">
          <p>
            <strong>Το Chat Tool App</strong> είναι το εργαλείο σας για τη διαχείριση προκαθορισμένων απαντήσεων υποστήριξης πελατών. 
            Η εφαρμογή λειτουργεί απευθείας στον browser σας και αποθηκεύει όλες τις αλλαγές αυτόματα.
          </p>
          
          <div className="bg-blue-50 p-3 rounded-md border border-blue-100">
            <h3 className="font-semibold text-blue-800 mb-2">Βασικές λειτουργίες:</h3>
            <ul className="list-disc pl-5 space-y-1 text-blue-800 text-sm">
              <li><strong>Αντιγραφή κειμένου:</strong> Κλικ σε απάντηση για αντιγραφή</li>
              <li><strong>Εμφάνιση αγγλικών:</strong> Διπλό κλικ σε απάντηση με ένδειξη "EN"</li>
              <li><strong>Επεξεργασία:</strong> Χρησιμοποιήστε τα εικονίδια επεξεργασίας και διαγραφής</li>
              <li><strong>Προσθήκη:</strong> Κάντε κλικ στο "+" για νέες απαντήσεις</li>
              <li><strong>Αποθήκευση:</strong> Γίνεται αυτόματα στον browser σας</li>
            </ul>
          </div>
          
          <div className="bg-yellow-50 p-3 rounded-md border border-yellow-100">
            <h3 className="font-semibold text-yellow-800 mb-2">Σημαντική συμβουλή:</h3>
            <p className="text-yellow-800 text-sm">
              <i className="fas fa-exclamation-triangle mr-1"></i> Πατήστε τακτικά το κουμπί "Εξαγωγή" για να αποθηκεύσετε ένα αντίγραφο ασφαλείας των δεδομένων σας. 
              Αυτό θα σας επιτρέψει να τα επαναφέρετε εάν ο browser σας καθαρίσει την τοπική μνήμη.
            </p>
          </div>
        </div>
        
        <div className="mt-6 flex justify-end">
          <button
            onClick={() => setShowOverlay(false)}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            Ξεκινήστε τώρα <i className="fas fa-arrow-right ml-1"></i>
          </button>
        </div>
      </div>
    </div>
  );
};

export default WelcomeOverlay;