interface CopyAlertProps {
  show: boolean;
  text: string;
}

const CopyAlert = ({ show, text }: CopyAlertProps) => {
  if (!show) return null;
  
  return (
    <div 
      id="copy-alert" 
      className="fixed top-4 left-1/2 transform -translate-x-1/2 bg-success-500 text-white px-4 py-2 rounded shadow-lg transition-opacity duration-300 z-50"
    >
      {text}
    </div>
  );
};

export default CopyAlert;
