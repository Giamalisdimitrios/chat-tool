import { useState, useEffect } from 'react';
import { Category } from '@/types';
import { useChatTool } from '@/contexts/ChatToolContext';
import { useLocation } from 'wouter';

interface CategoryItemProps {
  category: Category;
  onShowNotification: (text?: string) => void;
  onOpenTitleModal: (category: Category) => void;
}

const CategoryItem = ({ 
  category, 
  onShowNotification,
  onOpenTitleModal
}: CategoryItemProps) => {
  const { deleteCategory, addSubcategory } = useChatTool();
  const [isAddingSubcategory, setIsAddingSubcategory] = useState(false);
  const [newSubcategoryTitle, setNewSubcategoryTitle] = useState('');
  
  // Handle delete
  const handleDelete = () => {
    if (window.confirm(`Are you sure you want to delete "${category.title}"?`)) {
      // Check if this category belongs to a custom tab
      if (category.customTab) {
        deleteCategory(category.id, category.customTab);
      } else {
        deleteCategory(category.id);
      }
      onShowNotification('Category deleted successfully!');
    }
  };
  
  // Handle add subcategory
  const handleAddSubcategory = () => {
    if (newSubcategoryTitle.trim()) {
      // Check if this category belongs to a custom tab
      if (category.customTab) {
        addSubcategory(
          category.id, 
          {
            id: Date.now().toString(),
            title: newSubcategoryTitle,
            responses: []
          },
          category.customTab
        );
      } else {
        addSubcategory(category.id, {
          id: Date.now().toString(),
          title: newSubcategoryTitle,
          responses: []
        });
      }
      setNewSubcategoryTitle('');
      setIsAddingSubcategory(false);
      onShowNotification('Subcategory added successfully!');
    }
  };
  
  // Handle open subcategory management
  const [, setLocation] = useLocation();
  const handleOpenSubcategory = (categoryId: string) => {
    // Store category ID in local storage for StatelessSubcategoryView to use
    localStorage.setItem('currentCategoryId', categoryId);
    // Navigate to subcategory management page
    setLocation(`/subcategory/${categoryId}`);
  };

  // State to track edit mode from CategoryManager
  const [isEditMode, setIsEditMode] = useState(false);
  
  // Effect to check for edit mode class in the DOM
  useEffect(() => {
    const checkEditMode = () => {
      const editModeElement = document.querySelector('.category-manager-mode-edit');
      setIsEditMode(editModeElement !== null);
    };
    
    // Check initially
    checkEditMode();
    
    // Set up mutation observer to watch for changes
    const observer = new MutationObserver(checkEditMode);
    observer.observe(document.body, { 
      childList: true, 
      subtree: true,
      attributes: true,
      attributeFilter: ['class']
    });
    
    return () => observer.disconnect();
  }, []);

  return (
    <div className="category-container bg-white dark:bg-gray-800 rounded border border-gray-200 dark:border-gray-700 overflow-hidden relative transition-colors">
      {/* X button for deletion - only shows when CategoryManager is in edit mode */}
      <button 
        className="category-delete-button"
        onClick={() => {
          if (window.confirm(`Are you sure you want to delete "${category.title}"?`)) {
            // Check if this category belongs to a custom tab
            if (category.customTab) {
              deleteCategory(category.id, category.customTab);
            } else {
              deleteCategory(category.id);
            }
            onShowNotification('Category deleted successfully!');
          }
        }}
      >
        <i className="fas fa-times"></i>
      </button>
      
      <div className="py-0 px-1 border-b border-gray-100 dark:border-gray-600 flex justify-between items-center bg-secondary-700 dark:bg-secondary-800 text-white h-5 transition-colors">
        <div className="flex items-center">
          <h4 className="font-normal text-xs editable-title truncate max-w-[150px]">{category.title}</h4>
        </div>
        <div className="flex items-center gap-0">
          <button 
            className="text-white hover:text-secondary-200 add-subcategory-btn py-0 px-1" 
            title="Add Subcategory"
            onClick={() => setIsAddingSubcategory(!isAddingSubcategory)}
          >
            <i className="fas fa-folder-plus text-[10px]"></i>
          </button>
          <button 
            className="text-white hover:text-alert-200 category-delete-btn py-0 px-1"
            onClick={handleDelete}
          >
            <i className="fas fa-trash text-[10px]"></i>
          </button>
        </div>
      </div>
      <div className="p-2">
        {isAddingSubcategory && (
          <div className="mb-2 p-2 bg-secondary-50 dark:bg-gray-700 rounded border border-secondary-200 dark:border-gray-600 transition-colors">
            <input
              type="text"
              className="w-full p-1 text-sm border border-secondary-300 dark:border-gray-600 rounded mb-1 bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200 transition-colors"
              placeholder="Enter subcategory title..."
              value={newSubcategoryTitle}
              onChange={(e) => setNewSubcategoryTitle(e.target.value)}
            />
            <div className="flex justify-end gap-1">
              <button 
                className="bg-gray-300 dark:bg-gray-600 hover:bg-gray-400 dark:hover:bg-gray-500 text-gray-800 dark:text-gray-200 px-2 py-1 rounded text-xs transition-colors"
                onClick={() => setIsAddingSubcategory(false)}
              >
                Cancel
              </button>
              <button 
                className="bg-primary-600 hover:bg-primary-700 text-white px-2 py-1 rounded text-xs"
                onClick={handleAddSubcategory}
              >
                Add
              </button>
            </div>
          </div>
        )}
        
        <button 
          className="w-full text-left bg-secondary-100 dark:bg-gray-700 hover:bg-secondary-200 dark:hover:bg-gray-600 active:bg-secondary-700 dark:active:bg-secondary-600 active:text-white transition-colors duration-150 p-2 rounded border border-secondary-300 dark:border-gray-600 mb-1 text-xs text-gray-800 dark:text-gray-200"
          onClick={() => handleOpenSubcategory(category.id)}
        >
          Διαχείριση υποκατηγοριών <i className="fas fa-chevron-right float-right mt-0.5"></i>
        </button>
        
        {(category.subcategories?.length || 0) > 0 && (
          <div className="text-xs text-gray-500 dark:text-gray-400">
            {category.subcategories?.length} subcategories
          </div>
        )}
      </div>
    </div>
  );
};

export default CategoryItem;
